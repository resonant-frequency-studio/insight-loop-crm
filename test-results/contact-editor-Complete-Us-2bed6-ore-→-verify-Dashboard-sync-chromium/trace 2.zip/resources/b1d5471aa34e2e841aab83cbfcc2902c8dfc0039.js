(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_915e0968._.js",
  "static/chunks/node_modules_@tanstack_44296181._.js"
],
    source: "dynamic"
});
