;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="222ae291-ec6b-fbad-4556-192298e5e396")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/hooks/useContact.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useContact",
    ()=>useContact
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
function useContact(userId, contactId) {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "contact",
            userId,
            contactId
        ],
        queryFn: {
            "useContact.useQuery": async ()=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}`);
                if (!response.ok) {
                    if (response.status === 404) {
                        return null;
                    }
                    const errorData = await response.json().catch({
                        "useContact.useQuery": ()=>({})
                    }["useContact.useQuery"]);
                    throw new Error(errorData.error || "Failed to fetch contact");
                }
                const data = await response.json();
                return data.contact;
            }
        }["useContact.useQuery"],
        staleTime: 0,
        enabled: !!userId && !!contactId,
        // ⭐ ONLY placeholderData — NO initialData
        // This ensures optimistic updates persist during refetches
        placeholderData: {
            "useContact.useQuery": ()=>{
                // First check if we have the individual contact query data (includes optimistic updates)
                const detail = queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]);
                if (detail) return detail;
                // Otherwise fall back to contacts list
                const list = queryClient.getQueryData([
                    "contacts",
                    userId
                ]);
                return list?.find({
                    "useContact.useQuery": (c)=>c.contactId === contactId
                }["useContact.useQuery"]);
            }
        }["useContact.useQuery"]
    });
}
_s(useContact, "BLZt64a2VVrVbN4W5DyNUDE4KQk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useActionItems.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useActionItems",
    ()=>useActionItems
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
function useActionItems(userId, contactId, initialData) {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const queryKey = contactId ? [
        "action-items",
        userId,
        contactId
    ] : [
        "action-items",
        userId
    ];
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey,
        queryFn: {
            "useActionItems.useQuery": async ()=>{
                if (contactId) {
                    const response = await fetch(`/api/action-items?contactId=${encodeURIComponent(contactId)}`);
                    if (!response.ok) {
                        const errorData = await response.json().catch({
                            "useActionItems.useQuery": ()=>({})
                        }["useActionItems.useQuery"]);
                        throw new Error(errorData.error || "Failed to fetch action items");
                    }
                    const data = await response.json();
                    return data.actionItems;
                } else {
                    const response = await fetch("/api/action-items/all");
                    if (!response.ok) {
                        const errorData = await response.json().catch({
                            "useActionItems.useQuery": ()=>({})
                        }["useActionItems.useQuery"]);
                        throw new Error(errorData.error || "Failed to fetch action items");
                    }
                    const data = await response.json();
                    return data.actionItems;
                }
            }
        }["useActionItems.useQuery"],
        enabled: !!userId,
        initialData,
        // If fetching single contact's action items, use all action items cache as placeholder
        // This is a valid optimization: show filtered items while fetching
        placeholderData: {
            "useActionItems.useQuery": ()=>{
                if (contactId) {
                    const allActionItems = queryClient.getQueryData([
                        "action-items",
                        userId
                    ]);
                    if (allActionItems) {
                        return allActionItems.filter({
                            "useActionItems.useQuery": (item)=>item.contactId === contactId
                        }["useActionItems.useQuery"]);
                    }
                }
                return undefined;
            }
        }["useActionItems.useQuery"]
    });
}
_s(useActionItems, "BLZt64a2VVrVbN4W5DyNUDE4KQk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/util/timestamp-utils-server.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Convert Firestore Timestamp to ISO string for JSON serialization
 * 
 * This function handles multiple timestamp formats:
 * - Firestore Timestamp objects (with toDate() or toMillis() methods)
 * - Serialized Firestore Timestamps (with _seconds/_nanoseconds or seconds/nanoseconds)
 * - JavaScript Date objects
 * - ISO string dates (returns as-is)
 * 
 * @param value - The timestamp value to convert
 * @returns ISO string representation or null if value is null/undefined/invalid
 */ __turbopack_context__.s([
    "convertTimestamp",
    ()=>convertTimestamp,
    "convertTimestampToISO",
    ()=>convertTimestampToISO
]);
function convertTimestampToISO(value) {
    if (!value) return null;
    // Handle Firestore Timestamp objects with toDate() method
    if (value && typeof value === "object" && "toDate" in value) {
        const timestamp = value;
        return timestamp.toDate().toISOString();
    }
    // Handle Firestore Timestamp objects with toMillis() method
    if (value && typeof value === "object" && "toMillis" in value) {
        const timestamp = value;
        return new Date(timestamp.toMillis()).toISOString();
    }
    // Handle Firestore Timestamp serialized format with underscores
    if (value && typeof value === "object" && "_seconds" in value && "_nanoseconds" in value) {
        const timestamp = value;
        return new Date(timestamp._seconds * 1000 + timestamp._nanoseconds / 1000000).toISOString();
    }
    // Handle Firestore Timestamp serialized format without underscores
    if (value && typeof value === "object" && "seconds" in value && "nanoseconds" in value) {
        const timestamp = value;
        return new Date(timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000).toISOString();
    }
    // Handle JavaScript Date objects
    if (value instanceof Date) {
        return value.toISOString();
    }
    // Handle ISO strings (return as-is)
    if (typeof value === "string") {
        return value;
    }
    return null;
}
function convertTimestamp(value) {
    const converted = convertTimestampToISO(value);
    return converted !== null ? converted : value;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ThemedSuspense.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ThemedSuspense
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
;
function ThemedSuspense({ children, fallback, variant = "default" }) {
    // If custom fallback provided, use it
    if (fallback !== undefined) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: fallback,
            children: children
        }, void 0, false, {
            fileName: "[project]/components/ThemedSuspense.tsx",
            lineNumber: 29,
            columnNumber: 12
        }, this);
    }
    // Default themed fallback based on variant
    let defaultFallback;
    switch(variant){
        case "simple":
            // Simple bar skeleton for small content
            defaultFallback = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-8 w-16 bg-theme-light rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 39,
                columnNumber: 9
            }, this);
            break;
        case "card":
            // Single card skeleton
            defaultFallback = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-card-highlight-light rounded-xl shadow p-4 animate-pulse",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-12 h-12 bg-theme-light rounded-full shrink-0"
                        }, void 0, false, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 48,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 space-y-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-5 bg-theme-light rounded w-2/3"
                                }, void 0, false, {
                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                    lineNumber: 50,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-4 bg-theme-light rounded w-1/2"
                                }, void 0, false, {
                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                    lineNumber: 51,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 49,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ThemedSuspense.tsx",
                    lineNumber: 47,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 46,
                columnNumber: 9
            }, this);
            break;
        case "list":
            // List skeleton without card wrapper
            defaultFallback = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: Array.from({
                    length: 3
                }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4 p-4 bg-card-highlight-light rounded-sm animate-pulse",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-12 h-12 bg-theme-light rounded-full shrink-0"
                            }, void 0, false, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 64,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-5 bg-theme-light rounded w-2/3"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 66,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-4 bg-theme-light rounded w-1/2"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 67,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 65,
                                columnNumber: 15
                            }, this)
                        ]
                    }, i, true, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 63,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 61,
                columnNumber: 9
            }, this);
            break;
        case "default":
        default:
            // Card-based list skeleton (default)
            defaultFallback = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-6 bg-card-highlight-light rounded w-32 mb-2 animate-pulse"
                    }, void 0, false, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 80,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 gap-3",
                        children: Array.from({
                            length: 5
                        }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-4 animate-pulse",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-12 h-12 bg-theme-light rounded-full shrink-0"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ThemedSuspense.tsx",
                                            lineNumber: 85,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1 space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "h-5 bg-theme-light rounded w-2/3"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                                    lineNumber: 87,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "h-4 bg-theme-light rounded w-1/2"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                                    lineNumber: 88,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/ThemedSuspense.tsx",
                                            lineNumber: 86,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                    lineNumber: 84,
                                    columnNumber: 17
                                }, this)
                            }, i, false, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 83,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 81,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 79,
                columnNumber: 9
            }, this);
            break;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: defaultFallback,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ThemedSuspense.tsx",
        lineNumber: 99,
        columnNumber: 10
    }, this);
}
_c = ThemedSuspense;
var _c;
__turbopack_context__.k.register(_c, "ThemedSuspense");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useContactMutations.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useArchiveContact",
    ()=>useArchiveContact,
    "useBulkArchiveContacts",
    ()=>useBulkArchiveContacts,
    "useBulkUpdateCompanies",
    ()=>useBulkUpdateCompanies,
    "useBulkUpdateSegments",
    ()=>useBulkUpdateSegments,
    "useBulkUpdateTags",
    ()=>useBulkUpdateTags,
    "useCreateContact",
    ()=>useCreateContact,
    "useDeleteContact",
    ()=>useDeleteContact,
    "useUpdateContact",
    ()=>useUpdateContact,
    "useUpdateTouchpointStatus",
    ()=>useUpdateTouchpointStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature();
"use client";
;
;
function useCreateContact() {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useCreateContact.useMutation": async (contactData)=>{
                const response = await fetch("/api/contacts", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(contactData)
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useCreateContact.useMutation": ()=>({})
                    }["useCreateContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to create contact");
                }
                const data = await response.json();
                return data.contactId;
            }
        }["useCreateContact.useMutation"],
        onSuccess: {
            "useCreateContact.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useCreateContact.useMutation"],
        onError: {
            "useCreateContact.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Creating contact",
                    tags: {
                        component: "useCreateContact"
                    }
                });
            }
        }["useCreateContact.useMutation"]
    });
}
_s(useCreateContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useUpdateContact(userId) {
    _s1();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    // Defensive contact matcher - handles contactId, id, or _id fields
    const isSameContact = (c, contactId)=>{
        return c.contactId === contactId || c.id === contactId || c._id === contactId;
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useUpdateContact.useMutation": async ({ contactId, updates })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(updates)
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useUpdateContact.useMutation": ()=>({})
                    }["useUpdateContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to update contact");
                }
                const data = await response.json();
                return data.contact; // API now returns { contact: Contact }
            }
        }["useUpdateContact.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update both detail and ALL list caches so UI feels instant
     */ onMutate: {
            "useUpdateContact.useMutation": async ({ contactId, updates })=>{
                // Cancel all related queries
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact"
                    ],
                    exact: false
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                });
                // Snapshot previous detail state (for this specific user+contact, if such a query exists)
                const prevDetail = userId ? queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]) : undefined;
                // Snapshot ALL contacts lists (regardless of key shape)
                const prevLists = {};
                queryClient.getQueryCache().findAll({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                }).forEach({
                    "useUpdateContact.useMutation": (q)=>{
                        const key = JSON.stringify(q.queryKey);
                        const data = q.state.data;
                        if (data) prevLists[key] = data;
                    }
                }["useUpdateContact.useMutation"]);
                // Optimistically update detail (if userId provided)
                if (userId) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        contactId
                    ], {
                        "useUpdateContact.useMutation": (old)=>old ? {
                                ...old,
                                ...updates
                            } : old
                    }["useUpdateContact.useMutation"]);
                }
                // Optimistically update ALL contacts lists (regardless of key shape)
                queryClient.setQueriesData({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                }, {
                    "useUpdateContact.useMutation": (old)=>{
                        if (!old || !Array.isArray(old)) return old;
                        return old.map({
                            "useUpdateContact.useMutation": (c)=>isSameContact(c, contactId) ? {
                                    ...c,
                                    ...updates
                                } : c
                        }["useUpdateContact.useMutation"]);
                    }
                }["useUpdateContact.useMutation"]);
                return {
                    prevDetail,
                    prevLists
                };
            }
        }["useUpdateContact.useMutation"],
        /**
     * SUCCESS — update detail only & delay list invalidation
     * Firestore eventual consistency means list queries might not see the update immediately
     * So we invalidate after a delay to let Firestore propagate the change
     */ onSuccess: {
            "useUpdateContact.useMutation": (updatedContact, variables)=>{
                const { contactId } = variables;
                // Update detail cache with actual server result
                if (userId) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        contactId
                    ], updatedContact);
                }
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                });
                // Invalidate dashboard stats to ensure consistency
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ],
                    exact: false
                });
            }
        }["useUpdateContact.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useUpdateContact.useMutation": (error, variables, context)=>{
                // Restore detail (if userId provided)
                if (userId && context?.prevDetail) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prevDetail);
                }
                // Restore ALL contacts lists
                if (context?.prevLists) {
                    for (const [key, data] of Object.entries(context.prevLists)){
                        queryClient.setQueryData(JSON.parse(key), data);
                    }
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating contact",
                    tags: {
                        component: "useUpdateContact"
                    }
                });
            }
        }["useUpdateContact.useMutation"]
    });
}
_s1(useUpdateContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useDeleteContact() {
    _s2();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useDeleteContact.useMutation": async (contactId)=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}`, {
                    method: "DELETE"
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useDeleteContact.useMutation": ()=>({})
                    }["useDeleteContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to delete contact");
                }
                return response.json();
            }
        }["useDeleteContact.useMutation"],
        onSuccess: {
            "useDeleteContact.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "action-items"
                    ]
                });
            }
        }["useDeleteContact.useMutation"],
        onError: {
            "useDeleteContact.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Deleting contact",
                    tags: {
                        component: "useDeleteContact"
                    }
                });
            }
        }["useDeleteContact.useMutation"]
    });
}
_s2(useDeleteContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useArchiveContact(userId) {
    _s3();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useArchiveContact.useMutation": async ({ contactId, archived })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}/archive`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        archived
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useArchiveContact.useMutation": ()=>({})
                    }["useArchiveContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to archive contact");
                }
                return response.json();
            }
        }["useArchiveContact.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update the cache so UI feels instant
     */ onMutate: {
            "useArchiveContact.useMutation": async ({ contactId, archived })=>{
                if (!userId) return;
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                // Snapshot previous value for rollback
                const prev = queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]);
                // Update cache immediately - UI updates instantly
                queryClient.setQueryData([
                    "contact",
                    userId,
                    contactId
                ], {
                    "useArchiveContact.useMutation": (old)=>{
                        if (!old) return old;
                        return {
                            ...old,
                            archived
                        };
                    }
                }["useArchiveContact.useMutation"]);
                // Also update in contacts list
                queryClient.setQueryData([
                    "contacts",
                    userId
                ], {
                    "useArchiveContact.useMutation": (old)=>{
                        if (!old) return old;
                        return old.map({
                            "useArchiveContact.useMutation": (c)=>c.contactId === contactId ? {
                                    ...c,
                                    archived
                                } : c
                        }["useArchiveContact.useMutation"]);
                    }
                }["useArchiveContact.useMutation"]);
                return {
                    prev
                };
            }
        }["useArchiveContact.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useArchiveContact.useMutation": (error, variables, context)=>{
                if (userId && context?.prev) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prev);
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Archiving contact",
                    tags: {
                        component: "useArchiveContact"
                    }
                });
            }
        }["useArchiveContact.useMutation"],
        onSettled: {
            "useArchiveContact.useMutation": ()=>{
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useArchiveContact.useMutation"]
    });
}
_s3(useArchiveContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useUpdateTouchpointStatus(userId) {
    _s4();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useUpdateTouchpointStatus.useMutation": async ({ contactId, status, reason })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}/touchpoint-status`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        status,
                        reason
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useUpdateTouchpointStatus.useMutation": ()=>({})
                    }["useUpdateTouchpointStatus.useMutation"]);
                    // Throw user-friendly error message - will be extracted by component
                    const errorMessage = errorData.error || "Failed to update touchpoint status. Please try again.";
                    throw new Error(errorMessage);
                }
                const data = await response.json();
                return {
                    ...data,
                    contactId,
                    status,
                    reason
                };
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update the cache so UI feels instant
     */ onMutate: {
            "useUpdateTouchpointStatus.useMutation": async ({ contactId, status, reason })=>{
                if (!userId) return;
                // Cancel outgoing refetches to avoid overwriting optimistic update
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact",
                        userId,
                        contactId
                    ]
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts",
                        userId
                    ]
                });
                // Snapshot previous value for rollback
                const prev = queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]);
                // Update cache immediately - UI updates instantly
                queryClient.setQueryData([
                    "contact",
                    userId,
                    contactId
                ], {
                    "useUpdateTouchpointStatus.useMutation": (old)=>{
                        if (!old) return old;
                        return {
                            ...old,
                            touchpointStatus: status,
                            touchpointStatusUpdatedAt: status !== null ? new Date().toISOString() : null,
                            touchpointStatusReason: reason !== undefined ? reason : old.touchpointStatusReason
                        };
                    }
                }["useUpdateTouchpointStatus.useMutation"]);
                // Also update in contacts list
                queryClient.setQueryData([
                    "contacts",
                    userId
                ], {
                    "useUpdateTouchpointStatus.useMutation": (old)=>{
                        if (!old) return old;
                        return old.map({
                            "useUpdateTouchpointStatus.useMutation": (contact)=>contact.contactId === contactId ? {
                                    ...contact,
                                    touchpointStatus: status,
                                    touchpointStatusUpdatedAt: status !== null ? new Date().toISOString() : null,
                                    touchpointStatusReason: reason !== undefined ? reason : contact.touchpointStatusReason
                                } : contact
                        }["useUpdateTouchpointStatus.useMutation"]);
                    }
                }["useUpdateTouchpointStatus.useMutation"]);
                return {
                    prev
                };
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useUpdateTouchpointStatus.useMutation": (error, variables, context)=>{
                if (userId && context?.prev) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prev);
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating touchpoint status",
                    tags: {
                        component: "useUpdateTouchpointStatus"
                    }
                });
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * Invalidate after success to ensure server consistency
     */ onSettled: {
            "useUpdateTouchpointStatus.useMutation": (_data, _error, vars)=>{
                if (!userId) return;
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact",
                        userId,
                        vars.contactId
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts",
                        userId
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useUpdateTouchpointStatus.useMutation"]
    });
}
_s4(useUpdateTouchpointStatus, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkArchiveContacts() {
    _s5();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkArchiveContacts.useMutation": async ({ contactIds, archived })=>{
                const response = await fetch("/api/contacts/bulk-archive", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        archived
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkArchiveContacts.useMutation": ()=>({})
                    }["useBulkArchiveContacts.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk archive contacts");
                }
                return response.json();
            }
        }["useBulkArchiveContacts.useMutation"],
        onSuccess: {
            "useBulkArchiveContacts.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkArchiveContacts.useMutation"],
        onError: {
            "useBulkArchiveContacts.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk archiving contacts",
                    tags: {
                        component: "useBulkArchiveContacts"
                    }
                });
            }
        }["useBulkArchiveContacts.useMutation"]
    });
}
_s5(useBulkArchiveContacts, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateSegments() {
    _s6();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateSegments.useMutation": async ({ contactIds, segment })=>{
                const response = await fetch("/api/contacts/bulk-segment", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        segment
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateSegments.useMutation": ()=>({})
                    }["useBulkUpdateSegments.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update segments");
                }
                return response.json();
            }
        }["useBulkUpdateSegments.useMutation"],
        onSuccess: {
            "useBulkUpdateSegments.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateSegments.useMutation"],
        onError: {
            "useBulkUpdateSegments.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact segments",
                    tags: {
                        component: "useBulkUpdateSegments"
                    }
                });
            }
        }["useBulkUpdateSegments.useMutation"]
    });
}
_s6(useBulkUpdateSegments, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateTags() {
    _s7();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateTags.useMutation": async ({ contactIds, tags })=>{
                const response = await fetch("/api/contacts/bulk-tags", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        tags
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateTags.useMutation": ()=>({})
                    }["useBulkUpdateTags.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update tags");
                }
                return response.json();
            }
        }["useBulkUpdateTags.useMutation"],
        onSuccess: {
            "useBulkUpdateTags.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateTags.useMutation"],
        onError: {
            "useBulkUpdateTags.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact tags",
                    tags: {
                        component: "useBulkUpdateTags"
                    }
                });
            }
        }["useBulkUpdateTags.useMutation"]
    });
}
_s7(useBulkUpdateTags, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateCompanies() {
    _s8();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateCompanies.useMutation": async ({ contactIds, company })=>{
                const response = await fetch("/api/contacts/bulk-company", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        company
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateCompanies.useMutation": ()=>({})
                    }["useBulkUpdateCompanies.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update companies");
                }
                return response.json();
            }
        }["useBulkUpdateCompanies.useMutation"],
        onSuccess: {
            "useBulkUpdateCompanies.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateCompanies.useMutation"],
        onError: {
            "useBulkUpdateCompanies.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact companies",
                    tags: {
                        component: "useBulkUpdateCompanies"
                    }
                });
            }
        }["useBulkUpdateCompanies.useMutation"]
    });
}
_s8(useBulkUpdateCompanies, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useDebouncedSave.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDebouncedSave",
    ()=>useDebouncedSave
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
function useDebouncedSave(saveFn, delay = 500) {
    _s();
    const timeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const debouncedSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDebouncedSave.useCallback[debouncedSave]": (...args)=>{
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }
            timeoutRef.current = setTimeout({
                "useDebouncedSave.useCallback[debouncedSave]": ()=>{
                    saveFn(...args);
                }
            }["useDebouncedSave.useCallback[debouncedSave]"], delay);
        }
    }["useDebouncedSave.useCallback[debouncedSave]"], [
        saveFn,
        delay
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDebouncedSave.useEffect": ()=>{
            return ({
                "useDebouncedSave.useEffect": ()=>{
                    if (timeoutRef.current) {
                        clearTimeout(timeoutRef.current);
                    }
                }
            })["useDebouncedSave.useEffect"];
        }
    }["useDebouncedSave.useEffect"], []);
    return debouncedSave;
}
_s(useDebouncedSave, "X3uSMQJhxUwhE2dwZk/WczrvLAk=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Card
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Card({ children, className = "", padding = "md", hover = false }) {
    const paddingClasses = {
        none: "",
        sm: "p-3",
        md: "p-6",
        lg: "p-8",
        xl: "p-12",
        responsive: "p-3 xl:p-6"
    };
    const baseClasses = "bg-card-light rounded-sm shadow-[rgba(34,32,29,0.1)_0px_2px_4px] border border-theme-lighter";
    const paddingClass = padding === "none" || className.includes("p-") ? "" : paddingClasses[padding];
    const hoverClasses = hover ? "hover:shadow-[0px_6px_16px_rgba(0,0,0,0.15)] transition-shadow duration-200" : "";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${baseClasses} ${paddingClass} ${hoverClasses} ${className}`.trim(),
        children: children
    }, void 0, false, {
        fileName: "[project]/components/Card.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
_c = Card;
var _c;
__turbopack_context__.k.register(_c, "Card");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SavingIndicator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function SavingIndicator({ status }) {
    if (status === "idle") {
        return null;
    }
    if (status === "saving") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-1.5 text-blue-600",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    className: "w-4 h-4 animate-spin",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
                        lineNumber: 23,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-xs font-medium",
                    children: "Saving..."
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
                    lineNumber: 30,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
            lineNumber: 16,
            columnNumber: 7
        }, this);
    }
    if (status === "saved") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-1.5 text-green-600",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    className: "w-4 h-4",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M5 13l4 4L19 7"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
                        lineNumber: 44,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
                    lineNumber: 38,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-xs font-medium",
                    children: "Saved"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
                    lineNumber: 51,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
            lineNumber: 37,
            columnNumber: 7
        }, this);
    }
    if (status === "error") {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-1.5 text-red-600",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    className: "w-4 h-4",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M6 18L18 6M6 6l12 12"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
                        lineNumber: 65,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
                    lineNumber: 59,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-xs font-medium",
                    children: "Error"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
                    lineNumber: 72,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx",
            lineNumber: 58,
            columnNumber: 7
        }, this);
    }
    return null;
}
_c = SavingIndicator;
var _c;
__turbopack_context__.k.register(_c, "SavingIndicator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Reusable Input component with consistent styling
 * Provides consistent styling across all text input elements in the application
 */ __turbopack_context__.s([
    "default",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Input({ className = "", ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        ...props,
        className: `w-full px-4 py-2 border border-theme-darker placeholder:text-foreground rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 ${className}`
    }, void 0, false, {
        fileName: "[project]/components/Input.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = Input;
var _c;
__turbopack_context__.k.register(_c, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BasicInfoCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useDebouncedSave.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$SavingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/SavingStateContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function BasicInfoCard({ contactId, userId }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const updateMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"])(userId);
    const { registerSaveStatus, unregisterSaveStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"])();
    const cardId = `basic-info-${contactId}`;
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Initialize form state from contact using lazy initialization
    const [firstName, setFirstName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [lastName, setLastName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [company, setCompany] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [saveStatus, setSaveStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    // Register/unregister save status with context
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BasicInfoCard.useEffect": ()=>{
            registerSaveStatus(cardId, saveStatus);
            return ({
                "BasicInfoCard.useEffect": ()=>{
                    unregisterSaveStatus(cardId);
                }
            })["BasicInfoCard.useEffect"];
        }
    }["BasicInfoCard.useEffect"], [
        saveStatus,
        cardId,
        registerSaveStatus,
        unregisterSaveStatus
    ]);
    //   Reset form state when contactId changes (different contact loaded)
    //   Using contactId prop as dependency ensures we only update when switching contacts
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BasicInfoCard.useEffect": ()=>{
            if (!contact) return;
            if (prevContactIdRef.current !== contact) {
                prevContactIdRef.current = contact;
                // Batch state updates to avoid cascading renders
                setFirstName(contact.firstName ?? "");
                setLastName(contact.lastName ?? "");
                setCompany(contact.company ?? "");
                setSaveStatus("idle");
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["BasicInfoCard.useEffect"], [
        contact?.contactId,
        contact?.updatedAt
    ]); // Only depend on contactId prop, not contact object
    // Track changes using useMemo instead of useEffect
    const hasChanges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BasicInfoCard.useMemo[hasChanges]": ()=>{
            if (!contact) return false;
            const firstNameChanged = firstName !== (contact.firstName ?? "");
            const lastNameChanged = lastName !== (contact.lastName ?? "");
            const companyChanged = company !== (contact.company ?? "");
            return firstNameChanged || lastNameChanged || companyChanged;
        }
    }["BasicInfoCard.useMemo[hasChanges]"], [
        firstName,
        lastName,
        company,
        contact
    ]);
    const saveChanges = ()=>{
        if (!hasChanges || !contact) return;
        setSaveStatus("saving");
        updateMutation.mutate({
            contactId,
            updates: {
                firstName: firstName || null,
                lastName: lastName || null,
                company: company || null
            }
        }, {
            onSuccess: ()=>{
                setSaveStatus("saved");
                setTimeout(()=>setSaveStatus("idle"), 2000);
            },
            onError: (error)=>{
                setSaveStatus("error");
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Saving basic info in BasicInfoCard",
                    tags: {
                        component: "BasicInfoCard",
                        contactId
                    }
                });
                setTimeout(()=>setSaveStatus("idle"), 3000);
            }
        });
    };
    const debouncedSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedSave"])(saveChanges, 500);
    const handleBlur = ()=>{
        if (hasChanges) {
            debouncedSave();
        }
    };
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-32 bg-gray-200 rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                lineNumber: 108,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
            lineNumber: 107,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-lg font-semibold text-theme-darkest flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-5 h-5 text-gray-400",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                    lineNumber: 123,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 117,
                                columnNumber: 11
                            }, this),
                            "Basic Information"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                        lineNumber: 116,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$SavingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        status: saveStatus
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                        lineNumber: 132,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                lineNumber: 115,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                        children: "First Name"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                        lineNumber: 137,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        id: "contact-first-name",
                                        name: "contact-first-name",
                                        value: firstName,
                                        onChange: (e)=>setFirstName(e.target.value),
                                        onBlur: handleBlur,
                                        placeholder: "First Name"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                        lineNumber: 140,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 136,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                        children: "Last Name"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                        lineNumber: 150,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        id: "contact-last-name",
                                        name: "contact-last-name",
                                        value: lastName,
                                        onChange: (e)=>setLastName(e.target.value),
                                        onBlur: handleBlur,
                                        placeholder: "Last Name"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                        lineNumber: 153,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 149,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                        lineNumber: 135,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Company"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 164,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "contact-company",
                                name: "contact-company",
                                value: company,
                                onChange: (e)=>setCompany(e.target.value),
                                onBlur: handleBlur,
                                placeholder: "Company"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 167,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                        lineNumber: 163,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Email"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 177,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                type: "email",
                                id: "contact-email",
                                name: "contact-email",
                                disabled: true,
                                className: "bg-theme-lighter text-[#8d8a85] cursor-not-allowed",
                                value: contact.primaryEmail
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 180,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                lineNumber: 134,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
        lineNumber: 114,
        columnNumber: 5
    }, this);
}
_s(BasicInfoCard, "pePo/RP7TnDz8p9EoG807FBgz2k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedSave"]
    ];
});
_c = BasicInfoCard;
var _c;
__turbopack_context__.k.register(_c, "BasicInfoCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/InfoPopover.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InfoPopover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function InfoPopover({ content }) {
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [positionRight, setPositionRight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const buttonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const popoverRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InfoPopover.useEffect": ()=>{
            if (!isOpen || !buttonRef.current || !popoverRef.current) return;
            const checkPosition = {
                "InfoPopover.useEffect.checkPosition": ()=>{
                    const buttonRect = buttonRef.current.getBoundingClientRect();
                    const popoverWidth = 256; // w-64 = 16rem = 256px
                    const spaceOnRight = window.innerWidth - buttonRect.right;
                    const spaceOnLeft = buttonRect.left;
                    // If there's not enough space on the right (less than popover width + some padding)
                    // and there's more space on the left, position to the right
                    if (spaceOnRight < popoverWidth + 16 && spaceOnLeft > spaceOnRight) {
                        setPositionRight(true);
                    } else {
                        setPositionRight(false);
                    }
                }
            }["InfoPopover.useEffect.checkPosition"];
            checkPosition();
            window.addEventListener("resize", checkPosition);
            window.addEventListener("scroll", checkPosition, true);
            return ({
                "InfoPopover.useEffect": ()=>{
                    window.removeEventListener("resize", checkPosition);
                    window.removeEventListener("scroll", checkPosition, true);
                }
            })["InfoPopover.useEffect"];
        }
    }["InfoPopover.useEffect"], [
        isOpen
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative inline-block",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                ref: buttonRef,
                type: "button",
                onMouseEnter: ()=>setIsOpen(true),
                onMouseLeave: ()=>setIsOpen(false),
                onClick: ()=>setIsOpen(!isOpen),
                className: "inline-flex items-center justify-center w-5 h-5 rounded-full bg-card-highlight-light border border-gray-200 text-theme-darkest hover:bg-theme-medium transition-colors",
                "aria-label": "More information",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-xs font-bold leading-none",
                    children: "i"
                }, void 0, false, {
                    fileName: "[project]/components/InfoPopover.tsx",
                    lineNumber: 54,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/InfoPopover.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: popoverRef,
                className: `absolute bottom-full mb-2 w-64 p-3 bg-card-highlight-light border border-gray-200 text-foreground text-[14px] rounded-sm shadow-xl z-50 ${positionRight ? "right-0" : "left-0"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "leading-relaxed lowercase",
                        children: content
                    }, void 0, false, {
                        fileName: "[project]/components/InfoPopover.tsx",
                        lineNumber: 63,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `absolute top-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-white ${positionRight ? "right-4" : "left-4"}`
                    }, void 0, false, {
                        fileName: "[project]/components/InfoPopover.tsx",
                        lineNumber: 64,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `absolute top-full -mt-px w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-200 ${positionRight ? "right-4" : "left-4"}`
                    }, void 0, false, {
                        fileName: "[project]/components/InfoPopover.tsx",
                        lineNumber: 69,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/InfoPopover.tsx",
                lineNumber: 57,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/InfoPopover.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_s(InfoPopover, "oLKBiRZdtEa2yMMBfmC8qGKMsLM=");
_c = InfoPopover;
var _c;
__turbopack_context__.k.register(_c, "InfoPopover");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/SegmentSelect.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SegmentSelect
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function SegmentSelect({ value, onChange, existingSegments, placeholder = "Enter or select segment...", className = "" }) {
    _s();
    const [inputValue, setInputValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(value || "");
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [highlightedIndex, setHighlightedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const dropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const isUserTypingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const previousValueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(value);
    const inputValueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(inputValue);
    // Keep ref in sync with state
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SegmentSelect.useEffect": ()=>{
            inputValueRef.current = inputValue;
        }
    }["SegmentSelect.useEffect"], [
        inputValue
    ]);
    // Function to sync input value from prop changes (called from effect)
    // This follows React's recommendation to call a function instead of setState directly
    const syncInputFromProp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SegmentSelect.useCallback[syncInputFromProp]": (newValue)=>{
            const valueToSet = newValue || "";
            // Use ref to check current value without causing re-renders
            if (inputValueRef.current !== valueToSet) {
                setInputValue(valueToSet);
            }
        }
    }["SegmentSelect.useCallback[syncInputFromProp]"], []);
    // Update input value when prop value changes (only if changed externally, not from user input)
    // This is necessary to sync controlled input state with prop changes while allowing user typing
    // We defer the state update by calling the sync function asynchronously to avoid cascading renders
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SegmentSelect.useEffect": ()=>{
            if (previousValueRef.current !== value && !isUserTypingRef.current) {
                previousValueRef.current = value;
                // Defer the function call to avoid synchronous setState in effect
                queueMicrotask({
                    "SegmentSelect.useEffect": ()=>{
                        syncInputFromProp(value);
                    }
                }["SegmentSelect.useEffect"]);
            }
            // Reset typing flag after a short delay
            if (isUserTypingRef.current) {
                const timer = setTimeout({
                    "SegmentSelect.useEffect.timer": ()=>{
                        isUserTypingRef.current = false;
                    }
                }["SegmentSelect.useEffect.timer"], 100);
                return ({
                    "SegmentSelect.useEffect": ()=>clearTimeout(timer)
                })["SegmentSelect.useEffect"];
            }
        }
    }["SegmentSelect.useEffect"], [
        value,
        syncInputFromProp
    ]);
    // Filter segments based on input
    const filteredSegments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SegmentSelect.useMemo[filteredSegments]": ()=>{
            if (!inputValue.trim()) {
                return existingSegments;
            }
            const searchLower = inputValue.toLowerCase();
            return existingSegments.filter({
                "SegmentSelect.useMemo[filteredSegments]": (segment)=>segment.toLowerCase().includes(searchLower)
            }["SegmentSelect.useMemo[filteredSegments]"]);
        }
    }["SegmentSelect.useMemo[filteredSegments]"], [
        inputValue,
        existingSegments
    ]);
    // Check if current input matches an existing segment
    const isExistingSegment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SegmentSelect.useMemo[isExistingSegment]": ()=>{
            return existingSegments.includes(inputValue.trim());
        }
    }["SegmentSelect.useMemo[isExistingSegment]"], [
        inputValue,
        existingSegments
    ]);
    const handleInputChange = (e)=>{
        const newValue = e.target.value;
        isUserTypingRef.current = true;
        setInputValue(newValue);
        setHighlightedIndex(-1);
        setIsOpen(true);
        // Update parent immediately so user can type freely
        onChange(newValue.trim() || null);
    };
    const handleInputFocus = ()=>{
        setIsOpen(true);
    };
    const handleInputBlur = (e)=>{
        // Check if the newly focused element is within the dropdown
        const relatedTarget = e.relatedTarget;
        if (dropdownRef.current?.contains(relatedTarget)) {
            // User is clicking on dropdown item, don't close
            return;
        }
        // Delay closing to allow clicking on dropdown items
        setTimeout(()=>{
            if (!dropdownRef.current?.contains(document.activeElement)) {
                setIsOpen(false);
                setHighlightedIndex(-1);
                // If input doesn't match existing segment, keep it (allow new segments)
                // If input is empty, clear it
                if (!inputValue.trim()) {
                    onChange(null);
                }
            }
        }, 150);
    };
    const handleSelectSegment = (segment, e)=>{
        // Prevent blur from interfering with selection
        e?.preventDefault();
        e?.stopPropagation();
        setInputValue(segment);
        onChange(segment);
        setIsOpen(false);
        setHighlightedIndex(-1);
        // Use setTimeout to ensure the selection happens before blur
        setTimeout(()=>{
            inputRef.current?.blur();
        }, 0);
    };
    const handleClear = ()=>{
        setInputValue("");
        onChange(null);
        setIsOpen(false);
        inputRef.current?.focus();
    };
    const handleKeyDown = (e)=>{
        if (!isOpen && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
            setIsOpen(true);
            return;
        }
        if (e.key === "ArrowDown") {
            e.preventDefault();
            setHighlightedIndex((prev)=>prev < filteredSegments.length - 1 ? prev + 1 : prev);
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setHighlightedIndex((prev)=>prev > 0 ? prev - 1 : -1);
        } else if (e.key === "Enter" && highlightedIndex >= 0) {
            e.preventDefault();
            handleSelectSegment(filteredSegments[highlightedIndex]);
        } else if (e.key === "Escape") {
            setIsOpen(false);
            setHighlightedIndex(-1);
            inputRef.current?.blur();
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `relative ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: inputRef,
                        type: "text",
                        value: inputValue,
                        onChange: handleInputChange,
                        onFocus: handleInputFocus,
                        onBlur: handleInputBlur,
                        onKeyDown: handleKeyDown,
                        placeholder: placeholder,
                        "data-no-autofocus": true,
                        className: "w-full px-4 py-2 border border-gray-200 rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 pr-10 text-foreground placeholder:text-gray-400"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 167,
                        columnNumber: 9
                    }, this),
                    inputValue && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleClear,
                        className: "absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-theme-dark transition-colors",
                        tabIndex: -1,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-5 h-5",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M6 18L18 6M6 6l12 12"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 192,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                            lineNumber: 186,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 180,
                        columnNumber: 11
                    }, this),
                    !inputValue && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-5 h-5 text-gray-400",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M19 9l-7 7-7-7"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 209,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                            lineNumber: 203,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 202,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this),
            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "fixed inset-0 z-10",
                        onClick: ()=>setIsOpen(false)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 223,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: dropdownRef,
                        className: "absolute z-20 w-full mt-1 bg-card-highlight-light border border-gray-200 rounded-sm shadow-lg max-h-60 overflow-y-auto",
                        children: filteredSegments.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                filteredSegments.map((segment, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onMouseDown: (e)=>{
                                            e.preventDefault(); // Prevent input blur
                                            handleSelectSegment(segment, e);
                                        },
                                        className: `w-full text-left px-4 py-2 text-sm text-foreground rounded-sm hover:bg-theme-darker hover:text-theme-lightest transition-colors ${index === highlightedIndex ? "bg-theme-darker text-theme-lightest" : ""} ${segment === value ? "bg-theme-darker text-theme-lightest font-bold" : ""}`,
                                        children: segment
                                    }, segment, false, {
                                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                        lineNumber: 234,
                                        columnNumber: 19
                                    }, this)),
                                !isExistingSegment && inputValue.trim() && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-t border-gray-200",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onMouseDown: (e)=>{
                                            e.preventDefault(); // Prevent input blur
                                            handleSelectSegment(inputValue.trim(), e);
                                        },
                                        className: "w-full text-left px-4 py-2 text-sm text-foreground rounded-sm hover:bg-theme-darker hover:text-theme-lightest transition-colors",
                                        children: [
                                            '+ Create "',
                                            inputValue.trim(),
                                            '"'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                        lineNumber: 252,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                    lineNumber: 251,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: inputValue.trim() ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onMouseDown: (e)=>{
                                    e.preventDefault(); // Prevent input blur
                                    handleSelectSegment(inputValue.trim(), e);
                                },
                                className: "w-full text-left px-4 py-2 text-sm text-foreground rounded-sm hover:bg-theme-darker hover:text-theme-lightest transition-colors",
                                children: [
                                    '+ Create new segment: "',
                                    inputValue.trim(),
                                    '"'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 268,
                                columnNumber: 19
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "px-4 py-2 text-sm text-gray-500",
                                children: "No segments available"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 279,
                                columnNumber: 19
                            }, this)
                        }, void 0, false)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 227,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
        lineNumber: 165,
        columnNumber: 5
    }, this);
}
_s(SegmentSelect, "mXhLx9Yc2+h+4KO3C+zJadMZEPU=");
_c = SegmentSelect;
var _c;
__turbopack_context__.k.register(_c, "SegmentSelect");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TagsClassificationCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useDebouncedSave.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/InfoPopover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$SavingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$SegmentSelect$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/SegmentSelect.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/SavingStateContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
function TagsClassificationCard({ contactId, userId, uniqueSegments = [] }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const updateMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"])(userId);
    const { registerSaveStatus, unregisterSaveStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"])();
    const cardId = `tags-classification-${contactId}`;
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Initialize form state from contact using lazy initialization
    const [tagsInput, setTagsInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(""); // Raw input string for free typing
    const [tags, setTags] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]); // Parsed tags array
    const [segment, setSegment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [leadSource, setLeadSource] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [saveStatus, setSaveStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    // Register/unregister save status with context
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TagsClassificationCard.useEffect": ()=>{
            registerSaveStatus(cardId, saveStatus);
            return ({
                "TagsClassificationCard.useEffect": ()=>{
                    unregisterSaveStatus(cardId);
                }
            })["TagsClassificationCard.useEffect"];
        }
    }["TagsClassificationCard.useEffect"], [
        saveStatus,
        cardId,
        registerSaveStatus,
        unregisterSaveStatus
    ]);
    // Reset form state when contactId changes (different contact loaded)
    // Using contactId prop as dependency ensures we only update when switching contacts
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TagsClassificationCard.useEffect": ()=>{
            if (!contact) return;
            if (prevContactIdRef.current !== contact.contactId) {
                prevContactIdRef.current = contact.contactId;
                // Batch state updates to avoid cascading renders
                const contactTags = contact.tags ?? [];
                setTags(contactTags);
                setTagsInput(contactTags.join(", ")); // Initialize input with tags joined by comma
                setSegment(contact.segment ?? null);
                setLeadSource(contact.leadSource ?? "");
                setSaveStatus("idle");
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["TagsClassificationCard.useEffect"], [
        contact?.contactId
    ]);
    // Track changes using useMemo instead of useEffect
    const hasUnsavedChanges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TagsClassificationCard.useMemo[hasUnsavedChanges]": ()=>{
            if (!contact) return false;
            const tagsChanged = JSON.stringify([
                ...tags
            ].sort()) !== JSON.stringify([
                ...contact.tags ?? []
            ].sort());
            const segmentChanged = segment !== (contact.segment ?? null);
            const leadSourceChanged = leadSource !== (contact.leadSource ?? "");
            return tagsChanged || segmentChanged || leadSourceChanged;
        }
    }["TagsClassificationCard.useMemo[hasUnsavedChanges]"], [
        tags,
        segment,
        leadSource,
        contact
    ]);
    const saveChanges = ()=>{
        if (!hasUnsavedChanges || !contact) return;
        setSaveStatus("saving");
        updateMutation.mutate({
            contactId,
            updates: {
                tags: tags.length > 0 ? tags : [],
                segment: segment || null,
                leadSource: leadSource || null
            }
        }, {
            onSuccess: ()=>{
                setSaveStatus("saved");
                setTimeout(()=>setSaveStatus("idle"), 2000);
            },
            onError: (error)=>{
                setSaveStatus("error");
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Saving tags & classification in TagsClassificationCard",
                    tags: {
                        component: "TagsClassificationCard",
                        contactId
                    }
                });
                setTimeout(()=>setSaveStatus("idle"), 3000);
            }
        });
    };
    const debouncedSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedSave"])(saveChanges, 500);
    // Parse tags input string into tags array
    const parseTags = (input)=>{
        return input.split(",").map((s)=>s.trim()).filter(Boolean);
    };
    const handleTagsInputChange = (e)=>{
        const value = e.target.value;
        setTagsInput(value); // Allow free typing
        const parsedTags = parseTags(value);
        setTags(parsedTags); // Update tags array for comparison
    };
    const handleTagsBlur = ()=>{
        // Normalize the input on blur (remove extra spaces, etc.)
        const normalized = tags.join(", ");
        setTagsInput(normalized);
        if (hasUnsavedChanges) {
            debouncedSave();
        }
    };
    const handleBlur = ()=>{
        if (hasUnsavedChanges) {
            debouncedSave();
        }
    };
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-48 bg-gray-200 rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                lineNumber: 139,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
            lineNumber: 138,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-lg font-semibold text-theme-darkest flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-5 h-5 text-gray-400",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                    lineNumber: 154,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 148,
                                columnNumber: 11
                            }, this),
                            "Tags & Classification"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                        lineNumber: 147,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$SavingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        status: saveStatus
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                        lineNumber: 163,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                lineNumber: 146,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-theme-dark mb-4",
                children: "Organize and categorize your contacts using tags, segments, and lead sources to better track relationships and tailor your communication strategies."
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                lineNumber: 165,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex items-center gap-1.5 text-sm font-medium text-theme-darker mb-2",
                                children: [
                                    "Tags",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        content: "Tags are labels you can assign to contacts to organize and categorize them. Use tags to group contacts by characteristics like industry, role, project, or any custom classification that helps you manage your relationships."
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 172,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 170,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "contact-tags",
                                name: "contact-tags",
                                value: tagsInput,
                                onChange: handleTagsInputChange,
                                onBlur: handleTagsBlur,
                                placeholder: "tag1, tag2, tag3"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 174,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-xs text-theme-dark",
                                children: 'Enter tags separated by commas. Spaces within tags are allowed (e.g., "School of Hard Knocks, Referral, VIP").'
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 182,
                                columnNumber: 11
                            }, this),
                            tags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap gap-2 mt-3",
                                children: tags.map((tag, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "inline-flex items-center gap-1 px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm font-medium",
                                        children: tag
                                    }, idx, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 188,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 186,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                        lineNumber: 169,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "flex items-center gap-1.5 text-sm font-medium text-theme-darker mb-2",
                                        children: [
                                            "Segment",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                content: "A segment categorizes contacts into distinct groups based on shared characteristics such as company size, industry, customer type, or market segment. This helps you tailor your communication and sales strategies to different groups."
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                                lineNumber: 202,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 200,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        onBlur: handleBlur,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$SegmentSelect$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            value: segment,
                                            onChange: (value)=>setSegment(value),
                                            existingSegments: uniqueSegments,
                                            placeholder: "Enter or select segment..."
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                            lineNumber: 205,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 204,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 199,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "flex items-center gap-1.5 text-sm font-medium text-theme-darker mb-2",
                                        children: [
                                            "Lead Source",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                content: "The original source or channel where this contact was first acquired. This helps track which marketing channels or referral sources are most effective for your business."
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                                lineNumber: 216,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 214,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        type: "text",
                                        id: "contact-lead-source",
                                        name: "contact-lead-source",
                                        value: leadSource,
                                        onChange: (e)=>setLeadSource(e.target.value),
                                        onBlur: handleBlur,
                                        placeholder: "Enter lead source..."
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 218,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 213,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                        lineNumber: 198,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                lineNumber: 168,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
        lineNumber: 145,
        columnNumber: 5
    }, this);
}
_s(TagsClassificationCard, "1EFlYt6GYtpB/xHglBFRdk+2EP8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedSave"]
    ];
});
_c = TagsClassificationCard;
var _c;
__turbopack_context__.k.register(_c, "TagsClassificationCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/util/contact-utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatContactDate",
    ()=>formatContactDate,
    "getDisplayName",
    ()=>getDisplayName,
    "getInitials",
    ()=>getInitials
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [app-client] (ecmascript)");
;
function getInitials(contact) {
    if (contact.firstName && contact.lastName) {
        return `${contact.firstName[0]}${contact.lastName[0]}`.toUpperCase();
    }
    if (contact.firstName) {
        return contact.firstName[0].toUpperCase();
    }
    if (contact.primaryEmail) {
        return contact.primaryEmail[0].toUpperCase();
    }
    return "?";
}
function getDisplayName(contact) {
    if (contact.firstName || contact.lastName) {
        return `${contact.firstName || ""} ${contact.lastName || ""}`.trim();
    }
    if (contact.company) {
        return contact.company;
    }
    return contact.primaryEmail;
}
function formatContactDate(date, options) {
    if (!date) return "N/A";
    let dateObj = null;
    // Handle ISO date strings (from API - timestamps converted to ISO strings)
    if (typeof date === "string") {
        dateObj = new Date(date);
        if (isNaN(dateObj.getTime())) {
            return "N/A";
        }
    } else if (date instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"] || typeof date === "object" && date !== null && "toDate" in date) {
        dateObj = date.toDate();
    } else if (typeof date === "object" && date !== null && "seconds" in date && "nanoseconds" in date) {
        const timestamp = date;
        dateObj = new Date(timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000);
    } else if (typeof date === "object" && date !== null && "_seconds" in date && "_nanoseconds" in date) {
        const timestamp = date;
        dateObj = new Date(timestamp._seconds * 1000 + timestamp._nanoseconds / 1000000);
    } else if (date instanceof Date) {
        dateObj = date;
    } else if (typeof date === "number") {
        dateObj = new Date(date);
        if (isNaN(dateObj.getTime())) {
            return "N/A";
        }
    }
    if (!dateObj) return "N/A";
    // Relative time option (handles both past and future dates)
    if (options?.relative) {
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const dateToCompare = new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate());
        // Calculate difference in calendar days (positive = past, negative = future)
        const diffMs = today.getTime() - dateToCompare.getTime();
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        // Handle future dates (negative diffDays)
        if (diffDays < 0) {
            const absDays = Math.abs(diffDays);
            if (absDays === 0) {
                return "Today";
            } else if (absDays === 1) {
                return "Tomorrow";
            } else if (absDays < 7) {
                return `in ${absDays} days`;
            } else if (absDays < 30) {
                const weeks = Math.floor(absDays / 7);
                return `in ${weeks} ${weeks === 1 ? "week" : "weeks"}`;
            } else if (absDays < 365) {
                const months = Math.floor(absDays / 30);
                return `in ${months} ${months === 1 ? "month" : "months"}`;
            } else {
                const years = Math.floor(absDays / 365);
                return `in ${years} ${years === 1 ? "year" : "years"}`;
            }
        }
        // Handle past dates (positive diffDays)
        if (diffDays === 0) {
            return "Today";
        } else if (diffDays === 1) {
            return "Yesterday";
        } else if (diffDays < 7) {
            return `${diffDays} days ago`;
        } else if (diffDays < 30) {
            const weeks = Math.floor(diffDays / 7);
            return `${weeks} ${weeks === 1 ? "week" : "weeks"} ago`;
        } else if (diffDays < 365) {
            const months = Math.floor(diffDays / 30);
            return `${months} ${months === 1 ? "month" : "months"} ago`;
        } else {
            const years = Math.floor(diffDays / 365);
            return `${years} ${years === 1 ? "year" : "years"} ago`;
        }
    }
    // Standard formatting
    if (options?.includeTime) {
        return dateObj.toLocaleString("en-US", {
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: "numeric",
            minute: "2-digit"
        });
    }
    return dateObj.toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric"
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ActionItemCheckbox.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActionItemCheckbox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function ActionItemCheckbox({ checked, onChange, disabled = false, label }) {
    const defaultLabel = checked ? "Complete" : "Mark Complete";
    const displayLabel = label ?? defaultLabel;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
        className: "flex items-center gap-2 cursor-pointer",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "checkbox",
                checked: checked,
                onChange: onChange,
                disabled: disabled,
                onClick: (e)=>e.stopPropagation(),
                className: "w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed",
                title: displayLabel,
                "aria-label": displayLabel
            }, void 0, false, {
                fileName: "[project]/components/ActionItemCheckbox.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm text-theme-darker select-none",
                children: displayLabel
            }, void 0, false, {
                fileName: "[project]/components/ActionItemCheckbox.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ActionItemCheckbox.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_c = ActionItemCheckbox;
var _c;
__turbopack_context__.k.register(_c, "ActionItemCheckbox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Textarea.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Textarea
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Textarea({ className = "", ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
        ...props,
        className: `w-full px-4 py-3 border text-foreground placeholder:text-foreground border-gray-300 rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 resize-none ${className}`
    }, void 0, false, {
        fileName: "[project]/components/Textarea.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_c = Textarea;
var _c;
__turbopack_context__.k.register(_c, "Textarea");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ActionItemCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActionItemCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ActionItemCheckbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ActionItemCheckbox.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function ActionItemCard({ actionItem, contactId, contactName, contactEmail, contactFirstName, contactLastName, onComplete, onDelete, onEdit, disabled = false, compact = false, isOverdue: preComputedIsOverdue, displayName: preComputedDisplayName, initials: preComputedInitials, contactLoading = false }) {
    _s();
    // Use pre-computed values if provided, otherwise compute on client (for backward compatibility)
    const isOverdue = preComputedIsOverdue !== undefined ? preComputedIsOverdue : actionItem.status === "pending" && actionItem.dueDate ? (()=>{
        const dueDate = actionItem.dueDate;
        if (!dueDate) return false;
        if (dueDate instanceof Date) return dueDate < new Date();
        if (typeof dueDate === "string") return new Date(dueDate) < new Date();
        if (typeof dueDate === "object" && "toDate" in dueDate) {
            return dueDate.toDate() < new Date();
        }
        return false;
    })() : false;
    const [isEditing, setIsEditing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [editText, setEditText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(actionItem.text);
    const [editDueDate, setEditDueDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(actionItem.dueDate ? typeof actionItem.dueDate === "string" ? actionItem.dueDate.split("T")[0] : actionItem.dueDate instanceof Date ? actionItem.dueDate.toISOString().split("T")[0] : "" : "");
    // Use pre-computed values if provided, otherwise compute on client
    const displayName = preComputedDisplayName !== undefined ? preComputedDisplayName : contactName || (()=>{
        const contactForUtils = {
            contactId: contactId,
            firstName: contactFirstName,
            lastName: contactLastName,
            primaryEmail: contactEmail || "",
            createdAt: new Date(),
            updatedAt: new Date()
        };
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contactForUtils);
    })();
    const initials = preComputedInitials !== undefined ? preComputedInitials : (()=>{
        const contactForUtils = {
            contactId: contactId,
            firstName: contactFirstName,
            lastName: contactLastName,
            primaryEmail: contactEmail || "",
            createdAt: new Date(),
            updatedAt: new Date()
        };
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(contactForUtils);
    })();
    const email = contactEmail || "";
    const getVariantStyles = ()=>{
        if (actionItem.status === "completed") {
            return "bg-card-highlight-light border border-gray-200";
        }
        if (isOverdue) {
            return "bg-card-overdue border border-card-overdue-dark";
        }
        return "bg-transparent border border-gray-200";
    };
    const getAvatarStyles = ()=>{
        if (actionItem.status === "completed") {
            return "bg-gradient-to-br from-gray-400 to-gray-500";
        }
        if (isOverdue) {
            return "bg-gradient-to-br from-red-600 to-red-700";
        }
        return "bg-gradient-to-br from-blue-500 to-purple-600";
    };
    const handleSaveEdit = ()=>{
        onEdit(editText, editDueDate || null);
        setIsEditing(false);
    };
    const handleCancelEdit = ()=>{
        setEditText(actionItem.text);
        setEditDueDate(actionItem.dueDate ? typeof actionItem.dueDate === "string" ? actionItem.dueDate.split("T")[0] : "" : "");
        setIsEditing(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `rounded-sm p-3 sm:p-4 transition-all duration-200 min-w-0 overflow-hidden ${getVariantStyles()}`,
        children: isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-3",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    id: `action-item-edit-text-${actionItem.actionItemId}`,
                    name: `action-item-edit-text-${actionItem.actionItemId}`,
                    value: editText,
                    onChange: (e)=>setEditText(e.target.value),
                    className: "px-3 py-2",
                    rows: 2,
                    disabled: disabled
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 154,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    type: "date",
                    value: editDueDate,
                    onChange: (e)=>setEditDueDate(e.target.value),
                    className: "px-3 py-2",
                    disabled: disabled
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 163,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            onClick: handleSaveEdit,
                            disabled: disabled || !editText.trim(),
                            variant: "primary",
                            size: "sm",
                            children: "Save"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 171,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            onClick: handleCancelEdit,
                            disabled: disabled,
                            variant: "secondary",
                            size: "sm",
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 179,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 170,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
            lineNumber: 153,
            columnNumber: 9
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-3 min-w-0 overflow-hidden",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ActionItemCheckbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            checked: actionItem.status === "completed",
                            onChange: onComplete,
                            disabled: disabled
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 194,
                            columnNumber: 13
                        }, this),
                        actionItem.status === "pending" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-1 shrink-0 ml-auto",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>setIsEditing(true),
                                    disabled: disabled,
                                    variant: "ghost",
                                    size: "sm",
                                    className: "p-1 text-gray-400 hover:text-blue-600",
                                    title: "Edit",
                                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 217,
                                            columnNumber: 23
                                        }, void 0)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 211,
                                        columnNumber: 21
                                    }, void 0),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "sr-only",
                                        children: "Edit"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 226,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                    lineNumber: 203,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: onDelete,
                                    disabled: disabled,
                                    variant: "ghost",
                                    size: "sm",
                                    className: "p-1 text-gray-400 hover:text-red-600",
                                    title: "Delete",
                                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 242,
                                            columnNumber: 23
                                        }, void 0)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 236,
                                        columnNumber: 21
                                    }, void 0),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "sr-only",
                                        children: "Delete"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 251,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                    lineNumber: 228,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 202,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 192,
                    columnNumber: 11
                }, this),
                !compact && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: `/contacts/${contactId}`,
                    className: "flex items-center gap-2 group border border-gray-300 rounded-sm px-3 py-2 hover:border-gray-400 transition-colors",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "shrink-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `w-8 h-8 ${getAvatarStyles()} rounded-full flex items-center justify-center text-white font-semibold text-xs shadow-sm`,
                                children: initials
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                lineNumber: 265,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 264,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 min-w-0",
                            children: contactLoading || displayName === null ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-[38px] bg-gray-200 rounded w-24 animate-pulse"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                lineNumber: 273,
                                columnNumber: 19
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: `text-sm font-semibold group-hover:text-theme-darker transition-colors truncate ${actionItem.status === "completed" ? "text-gray-500" : "text-theme-darkest"}`,
                                        children: displayName || ""
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 276,
                                        columnNumber: 21
                                    }, this),
                                    email && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: `text-xs truncate mt-0.5 ${actionItem.status === "completed" ? "text-gray-400" : "text-gray-500"}`,
                                        children: email
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 282,
                                        columnNumber: 23
                                    }, this)
                                ]
                            }, void 0, true)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 271,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 259,
                    columnNumber: 13
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "min-w-0",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: `text-sm font-medium wrap-break-word mb-2 ${actionItem.status === "completed" ? "text-gray-500 line-through" : "text-theme-darkest"}`,
                            children: actionItem.text
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 296,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap gap-x-4 gap-y-1",
                            children: [
                                actionItem.status === "pending" && actionItem.dueDate ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: `text-xs flex items-center gap-1 ${isOverdue ? "text-red-600 font-medium" : "text-gray-500"}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-3.5 h-3.5 shrink-0",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                                lineNumber: 318,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 312,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                "Due: ",
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(actionItem.dueDate, {
                                                    relative: true
                                                }),
                                                isOverdue ? " (Overdue)" : null
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 325,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                    lineNumber: 309,
                                    columnNumber: 19
                                }, this) : null,
                                actionItem.status === "completed" && actionItem.completedAt ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-500 flex items-center gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-3.5 h-3.5 shrink-0",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                                lineNumber: 339,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 333,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                "Completed: ",
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(actionItem.completedAt, {
                                                    relative: true
                                                })
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 346,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                    lineNumber: 332,
                                    columnNumber: 19
                                }, this) : null,
                                actionItem.createdAt != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-400 flex items-center gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-3.5 h-3.5 shrink-0",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                                lineNumber: 359,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 353,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                "Created: ",
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(actionItem.createdAt, {
                                                    relative: true
                                                })
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 366,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                    lineNumber: 352,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 307,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 295,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
            lineNumber: 190,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
        lineNumber: 151,
        columnNumber: 5
    }, this);
}
_s(ActionItemCard, "O8K2FZRfxTS2h5RUyDtwakPWgPk=");
_c = ActionItemCard;
var _c;
__turbopack_context__.k.register(_c, "ActionItemCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Modal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Modal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function Modal({ isOpen, onClose, children, title, showBackdrop = true, closeOnBackdropClick = true }) {
    _s();
    const modalRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const titleId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const previousActiveElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Get all focusable elements within the modal
    const getFocusableElements = ()=>{
        if (!modalRef.current) return [];
        const focusableSelectors = [
            'a[href]',
            'button:not([disabled])',
            'textarea:not([disabled])',
            'input:not([disabled])',
            'select:not([disabled])',
            '[tabindex]:not([tabindex="-1"])'
        ].join(', ');
        return Array.from(modalRef.current.querySelectorAll(focusableSelectors));
    };
    // Focus trap: keep focus within modal
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (!isOpen || !modalRef.current) return;
            const handleTabKey = {
                "Modal.useEffect.handleTabKey": (e)=>{
                    if (e.key !== 'Tab') return;
                    const focusableElements = getFocusableElements();
                    if (focusableElements.length === 0) return;
                    const firstElement = focusableElements[0];
                    const lastElement = focusableElements[focusableElements.length - 1];
                    if (e.shiftKey) {
                        // Shift + Tab
                        if (document.activeElement === firstElement) {
                            e.preventDefault();
                            lastElement.focus();
                        }
                    } else {
                        // Tab
                        if (document.activeElement === lastElement) {
                            e.preventDefault();
                            firstElement.focus();
                        }
                    }
                }
            }["Modal.useEffect.handleTabKey"];
            document.addEventListener('keydown', handleTabKey);
            return ({
                "Modal.useEffect": ()=>{
                    document.removeEventListener('keydown', handleTabKey);
                }
            })["Modal.useEffect"];
        }
    }["Modal.useEffect"], [
        isOpen
    ]);
    // Handle escape key
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (!isOpen) return;
            const handleEscape = {
                "Modal.useEffect.handleEscape": (e)=>{
                    if (e.key === "Escape") {
                        onClose();
                    }
                }
            }["Modal.useEffect.handleEscape"];
            document.addEventListener("keydown", handleEscape);
            return ({
                "Modal.useEffect": ()=>{
                    document.removeEventListener("keydown", handleEscape);
                }
            })["Modal.useEffect"];
        }
    }["Modal.useEffect"], [
        isOpen,
        onClose
    ]);
    // Focus management: move focus to modal on open, return on close
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (isOpen) {
                // Store the previously focused element
                previousActiveElementRef.current = document.activeElement;
                // Move focus to modal after a brief delay to ensure it's rendered
                // Skip inputs that have data-no-autofocus attribute
                setTimeout({
                    "Modal.useEffect": ()=>{
                        const focusableElements = getFocusableElements().filter({
                            "Modal.useEffect.focusableElements": (el)=>!el.hasAttribute('data-no-autofocus')
                        }["Modal.useEffect.focusableElements"]);
                        if (focusableElements.length > 0) {
                            focusableElements[0].focus();
                        } else if (modalRef.current) {
                            modalRef.current.focus();
                        }
                    }
                }["Modal.useEffect"], 0);
            } else {
                // Return focus to the previously focused element
                if (previousActiveElementRef.current) {
                    previousActiveElementRef.current.focus();
                    previousActiveElementRef.current = null;
                }
            }
        }
    }["Modal.useEffect"], [
        isOpen
    ]);
    // Prevent body scroll when modal is open
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (isOpen) {
                document.body.style.overflow = "hidden";
            } else {
                document.body.style.overflow = "";
            }
            return ({
                "Modal.useEffect": ()=>{
                    document.body.style.overflow = "";
                }
            })["Modal.useEffect"];
        }
    }["Modal.useEffect"], [
        isOpen
    ]);
    if (!isOpen) return null;
    const handleBackdropClick = (e)=>{
        if (closeOnBackdropClick && e.target === e.currentTarget) {
            onClose();
        }
    };
    const modalContent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-200 flex items-center justify-center",
        onClick: handleBackdropClick,
        role: "presentation",
        children: [
            showBackdrop && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-black/20",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/components/Modal.tsx",
                lineNumber: 148,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: modalRef,
                role: "dialog",
                "aria-modal": "true",
                "aria-labelledby": title ? titleId : undefined,
                tabIndex: -1,
                className: "relative bg-background rounded-xl shadow-xl p-6 max-w-md w-full mx-4 z-10 border border-theme-light focus:outline-none",
                onClick: (e)=>e.stopPropagation(),
                children: [
                    title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        id: titleId,
                        className: "text-lg font-semibold text-foreground mb-4",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/components/Modal.tsx",
                        lineNumber: 160,
                        columnNumber: 11
                    }, this),
                    children
                ]
            }, void 0, true, {
                fileName: "[project]/components/Modal.tsx",
                lineNumber: 150,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/Modal.tsx",
        lineNumber: 142,
        columnNumber: 5
    }, this);
    // Use portal to render modal at document body level
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(modalContent, document.body);
}
_s(Modal, "Al4JN5XtBcZZvMhrMN2+23NTASM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = Modal;
var _c;
__turbopack_context__.k.register(_c, "Modal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useActionItemMutations.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCreateActionItem",
    ()=>useCreateActionItem,
    "useDeleteActionItem",
    ()=>useDeleteActionItem,
    "useUpdateActionItem",
    ()=>useUpdateActionItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
"use client";
;
;
function useCreateActionItem() {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useCreateActionItem.useMutation": async ({ contactId, text, dueDate })=>{
                const response = await fetch("/api/action-items", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactId,
                        text,
                        dueDate
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useCreateActionItem.useMutation": ()=>({})
                    }["useCreateActionItem.useMutation"]);
                    throw new Error(errorData.error || "Failed to create action item");
                }
                return response.json();
            }
        }["useCreateActionItem.useMutation"],
        onSuccess: {
            "useCreateActionItem.useMutation": ()=>{
                // Invalidate and refetch all action items queries (both specific contact and all items)
                queryClient.invalidateQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
                queryClient.refetchQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
            }
        }["useCreateActionItem.useMutation"],
        onError: {
            "useCreateActionItem.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Creating action item",
                    tags: {
                        component: "useCreateActionItem"
                    }
                });
            }
        }["useCreateActionItem.useMutation"]
    });
}
_s(useCreateActionItem, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useUpdateActionItem() {
    _s1();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useUpdateActionItem.useMutation": async ({ contactId, actionItemId, updates })=>{
                const url = new URL("/api/action-items", window.location.origin);
                url.searchParams.set("contactId", contactId);
                url.searchParams.set("actionItemId", actionItemId);
                const response = await fetch(url.toString(), {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(updates)
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useUpdateActionItem.useMutation": ()=>({})
                    }["useUpdateActionItem.useMutation"]);
                    throw new Error(errorData.error || "Failed to update action item");
                }
                return response.json();
            }
        }["useUpdateActionItem.useMutation"],
        onSuccess: {
            "useUpdateActionItem.useMutation": ()=>{
                // Invalidate and refetch all action items queries (both specific contact and all items)
                queryClient.invalidateQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
                queryClient.refetchQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
            }
        }["useUpdateActionItem.useMutation"],
        onError: {
            "useUpdateActionItem.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating action item",
                    tags: {
                        component: "useUpdateActionItem"
                    }
                });
            }
        }["useUpdateActionItem.useMutation"]
    });
}
_s1(useUpdateActionItem, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useDeleteActionItem() {
    _s2();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useDeleteActionItem.useMutation": async ({ contactId, actionItemId })=>{
                const url = new URL("/api/action-items", window.location.origin);
                url.searchParams.set("contactId", contactId);
                url.searchParams.set("actionItemId", actionItemId);
                const response = await fetch(url.toString(), {
                    method: "DELETE"
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useDeleteActionItem.useMutation": ()=>({})
                    }["useDeleteActionItem.useMutation"]);
                    throw new Error(errorData.error || "Failed to delete action item");
                }
                return response.json();
            }
        }["useDeleteActionItem.useMutation"],
        onSuccess: {
            "useDeleteActionItem.useMutation": ()=>{
                // Invalidate and refetch all action items queries (both specific contact and all items)
                queryClient.invalidateQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
                queryClient.refetchQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
            }
        }["useDeleteActionItem.useMutation"],
        onError: {
            "useDeleteActionItem.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Deleting action item",
                    tags: {
                        component: "useDeleteActionItem"
                    }
                });
            }
        }["useDeleteActionItem.useMutation"]
    });
}
_s2(useDeleteActionItem, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ActionItemsList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActionItemsList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ActionItemCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ActionItemCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useActionItems.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useActionItemMutations.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
function ActionItemsList({ userId, contactId, contactEmail, contactFirstName, contactLastName, contactCompany, onActionItemUpdate, initialActionItems, initialContact }) {
    _s();
    const { data: actionItems = [], isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"])(userId, contactId, initialActionItems);
    const createActionItemMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCreateActionItem"])();
    const updateActionItemMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateActionItem"])();
    const deleteActionItemMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeleteActionItem"])();
    const [filterStatus, setFilterStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    const [isAdding, setIsAdding] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [newText, setNewText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [newDueDate, setNewDueDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [updating, setUpdating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [addError, setAddError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [updateError, setUpdateError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [deleteConfirmItemId, setDeleteConfirmItemId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleAdd = async ()=>{
        if (!newText.trim()) return;
        setSaving(true);
        setAddError(null);
        const textToSave = newText.trim();
        const dueDateToSave = newDueDate;
        setNewText("");
        setNewDueDate("");
        setIsAdding(false);
        try {
            await createActionItemMutation.mutateAsync({
                contactId,
                text: textToSave,
                dueDate: dueDateToSave || null
            });
            setAddError(null);
            onActionItemUpdate?.();
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                context: "Adding action item",
                tags: {
                    component: "ActionItemsList",
                    contactId
                }
            });
            setAddError((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
            // Restore the form state so user can try again
            setNewText(textToSave);
            setNewDueDate(dueDateToSave);
            setIsAdding(true);
        } finally{
            setSaving(false);
        }
    };
    const handleComplete = async (actionItemId)=>{
        setUpdating(actionItemId);
        setUpdateError(null);
        const currentItem = actionItems.find((item)=>item.actionItemId === actionItemId);
        if (!currentItem) return;
        const newStatus = currentItem.status === "completed" ? "pending" : "completed";
        try {
            await updateActionItemMutation.mutateAsync({
                contactId,
                actionItemId,
                updates: {
                    status: newStatus
                }
            });
            setUpdateError(null);
            onActionItemUpdate?.();
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                context: "Completing action item",
                tags: {
                    component: "ActionItemsList",
                    contactId,
                    actionItemId
                }
            });
            setUpdateError((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
        } finally{
            setUpdating(null);
        }
    };
    const handleDeleteClick = (actionItemId)=>{
        setDeleteConfirmItemId(actionItemId);
        setUpdateError(null);
    };
    const handleDeleteConfirm = async ()=>{
        if (!deleteConfirmItemId) return;
        setUpdating(deleteConfirmItemId);
        setUpdateError(null);
        try {
            await deleteActionItemMutation.mutateAsync({
                contactId,
                actionItemId: deleteConfirmItemId
            });
            setUpdateError(null);
            setDeleteConfirmItemId(null);
            onActionItemUpdate?.();
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                context: "Deleting action item",
                tags: {
                    component: "ActionItemsList",
                    contactId
                }
            });
            setUpdateError((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
        } finally{
            setUpdating(null);
        }
    };
    const handleEdit = async (actionItemId, text, dueDate)=>{
        setUpdating(actionItemId);
        setUpdateError(null);
        try {
            await updateActionItemMutation.mutateAsync({
                contactId,
                actionItemId,
                updates: {
                    text: text.trim(),
                    dueDate: dueDate || null
                }
            });
            setUpdateError(null);
            onActionItemUpdate?.();
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                context: "Updating action item",
                tags: {
                    component: "ActionItemsList",
                    contactId,
                    actionItemId
                }
            });
            setUpdateError((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
        } finally{
            setUpdating(null);
        }
    };
    const filteredItems = actionItems.filter((item)=>{
        if (filterStatus === "all") return true;
        return item.status === filterStatus;
    });
    const pendingCount = actionItems.filter((i)=>i.status === "pending").length;
    const completedCount = actionItems.filter((i)=>i.status === "completed").length;
    if (isLoading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center py-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-500",
                children: "Loading action items..."
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                lineNumber: 197,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
            lineNumber: 196,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: deleteConfirmItemId !== null,
                onClose: ()=>{
                    if (!deleteActionItemMutation.isPending) {
                        setDeleteConfirmItemId(null);
                        setUpdateError(null);
                    }
                },
                title: "Delete Action Item",
                closeOnBackdropClick: !deleteActionItemMutation.isPending,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-theme-dark mb-6",
                        children: "Are you sure you want to delete this action item? This action cannot be undone."
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 216,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>{
                                    setDeleteConfirmItemId(null);
                                    setUpdateError(null);
                                },
                                disabled: deleteActionItemMutation.isPending,
                                variant: "secondary",
                                size: "sm",
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 220,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: handleDeleteConfirm,
                                disabled: deleteActionItemMutation.isPending,
                                loading: deleteActionItemMutation.isPending,
                                variant: "danger",
                                size: "sm",
                                error: updateError,
                                children: "Delete"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 231,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 219,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                lineNumber: 205,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4 min-w-0 overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-sm font-semibold text-theme-darkest",
                                    children: "Action Items"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                    lineNumber: 248,
                                    columnNumber: 11
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 247,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap gap-2",
                                role: "tablist",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setFilterStatus("all"),
                                        role: "tab",
                                        "aria-selected": filterStatus === "all",
                                        className: `cursor-pointer px-3 py-1.5 text-xs sm:text-sm text-foreground font-medium rounded-sm transition-all duration-200 border border-theme-medium ${filterStatus === "all" ? "bg-theme-light" : "hover:bg-theme-light hover:bg-opacity-10"}`,
                                        children: [
                                            "All",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `ml-1 ${filterStatus === "all" ? "text-theme-dark" : "text-gray-400"}`,
                                                children: [
                                                    "(",
                                                    actionItems.length,
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                                lineNumber: 266,
                                                columnNumber: 13
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                        lineNumber: 255,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setFilterStatus("pending"),
                                        role: "tab",
                                        "aria-selected": filterStatus === "pending",
                                        className: `cursor-pointer px-3 py-1.5 text-xs sm:text-sm text-foreground font-medium rounded-sm transition-all duration-200 border border-theme-medium ${filterStatus === "pending" ? "bg-theme-light" : "hover:bg-theme-light hover:bg-opacity-10"}`,
                                        children: [
                                            "Pending",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `ml-1 ${filterStatus === "pending" ? "text-theme-dark" : "text-gray-400"}`,
                                                children: [
                                                    "(",
                                                    pendingCount,
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                                lineNumber: 283,
                                                columnNumber: 13
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                        lineNumber: 272,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setFilterStatus("completed"),
                                        role: "tab",
                                        "aria-selected": filterStatus === "completed",
                                        className: `cursor-pointer px-3 py-1.5 text-xs sm:text-sm text-foreground font-medium rounded-sm transition-all duration-200 border border-theme-medium ${filterStatus === "completed" ? "bg-theme-light" : "hover:bg-theme-light hover:bg-opacity-10"}`,
                                        children: [
                                            "Completed",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `ml-1 ${filterStatus === "completed" ? "text-theme-dark" : "text-gray-400"}`,
                                                children: [
                                                    "(",
                                                    completedCount,
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                                lineNumber: 300,
                                                columnNumber: 13
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                        lineNumber: 289,
                                        columnNumber: 11
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 254,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 246,
                        columnNumber: 7
                    }, this),
                    isAdding ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-3 rounded-sm border border-gray-200 space-y-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "action-item-new-text",
                                name: "action-item-new-text",
                                value: newText,
                                onChange: (e)=>setNewText(e.target.value),
                                placeholder: "Enter action item...",
                                className: "px-3 py-2",
                                rows: 2,
                                disabled: saving
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 312,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                type: "date",
                                value: newDueDate,
                                onChange: (e)=>setNewDueDate(e.target.value),
                                placeholder: "Due date (optional)",
                                className: "px-3 py-2",
                                disabled: saving
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 322,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            onClick: handleAdd,
                                            disabled: saving || !newText.trim(),
                                            loading: saving,
                                            variant: "success",
                                            size: "sm",
                                            error: addError,
                                            children: "Add"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                            lineNumber: 332,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            onClick: ()=>{
                                                setIsAdding(false);
                                                setNewText("");
                                                setNewDueDate("");
                                                setAddError(null);
                                            },
                                            disabled: saving,
                                            variant: "outline",
                                            size: "sm",
                                            children: "Cancel"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                            lineNumber: 342,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                    lineNumber: 331,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 330,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 311,
                        columnNumber: 9
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>setIsAdding(true),
                        size: "sm",
                        fullWidth: true,
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M12 4v16m8-8H4"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 370,
                                columnNumber: 15
                            }, void 0)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                            lineNumber: 364,
                            columnNumber: 13
                        }, void 0),
                        children: "Add Action Item"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 359,
                        columnNumber: 9
                    }, this),
                    updateError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                            message: updateError,
                            dismissible: true,
                            onDismiss: ()=>setUpdateError(null)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                            lineNumber: 384,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 383,
                        columnNumber: 9
                    }, this),
                    filteredItems.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-theme-medium text-center py-4",
                        children: filterStatus === "all" ? "No action items yet" : `No ${filterStatus} action items`
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 390,
                        columnNumber: 9
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2 min-w-0 overflow-hidden",
                        children: filteredItems.map((item)=>{
                            // Pre-compute values if we have initialContact, otherwise let ActionItemCard compute
                            const contactForUtils = initialContact || {
                                contactId: contactId,
                                firstName: contactFirstName,
                                lastName: contactLastName,
                                company: contactCompany,
                                primaryEmail: contactEmail || "",
                                createdAt: new Date(),
                                updatedAt: new Date()
                            };
                            const displayName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contactForUtils);
                            const initials = (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(contactForUtils);
                            // Compute isOverdue on client (ActionItemCard will also compute if not provided)
                            const isOverdue = item.status === "pending" && item.dueDate ? (()=>{
                                const dueDate = item.dueDate;
                                if (!dueDate) return false;
                                if (dueDate instanceof Date) return dueDate < new Date();
                                if (typeof dueDate === "string") return new Date(dueDate) < new Date();
                                if (typeof dueDate === "object" && "toDate" in dueDate) {
                                    return dueDate.toDate() < new Date();
                                }
                                return false;
                            })() : false;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ActionItemCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                actionItem: item,
                                contactId: contactId,
                                contactEmail: contactEmail,
                                contactFirstName: contactFirstName,
                                contactLastName: contactLastName,
                                onComplete: ()=>handleComplete(item.actionItemId),
                                onDelete: ()=>handleDeleteClick(item.actionItemId),
                                onEdit: (text, dueDate)=>handleEdit(item.actionItemId, text, dueDate ?? null),
                                disabled: updating === item.actionItemId,
                                compact: true,
                                isOverdue: isOverdue,
                                displayName: displayName,
                                initials: initials
                            }, item.actionItemId, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 427,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 396,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                lineNumber: 244,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(ActionItemsList, "MCszRBJ5fP84h8WbhGHvIICl7mw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCreateActionItem"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateActionItem"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeleteActionItem"]
    ];
});
_c = ActionItemsList;
var _c;
__turbopack_context__.k.register(_c, "ActionItemsList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActionItemsCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ActionItemsList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ActionItemsList.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ActionItemsCard({ contactId, userId, initialActionItems, initialContact }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const displayContact = contact || initialContact;
    if (!displayContact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-96 bg-gray-200 rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
                lineNumber: 27,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold text-theme-darkest mb-2",
                children: "Action Items"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-theme-dark mb-6",
                children: "Track tasks and follow-ups for this contact. Create action items with due dates to stay organized and never miss an important next step in your relationship."
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ActionItemsList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                userId: userId,
                contactId: contactId,
                contactEmail: displayContact.primaryEmail,
                contactFirstName: displayContact.firstName || undefined,
                contactLastName: displayContact.lastName || undefined,
                contactCompany: displayContact.company || undefined,
                onActionItemUpdate: ()=>{
                // Trigger a refresh if needed
                },
                initialActionItems: initialActionItems,
                initialContact: displayContact
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_s(ActionItemsCard, "RMraLUiYNjzSbpembo7KgOc4sVs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"]
    ];
});
_c = ActionItemsCard;
var _c;
__turbopack_context__.k.register(_c, "ActionItemsCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/NotesCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NotesCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useDebouncedSave.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$SavingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/SavingStateContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function NotesCard({ contactId, userId }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const updateMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"])(userId);
    const { registerSaveStatus, unregisterSaveStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"])();
    const cardId = `notes-${contactId}`;
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Initialize form state from contact using lazy initialization
    const [notes, setNotes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [saveStatus, setSaveStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    // Register/unregister save status with context
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NotesCard.useEffect": ()=>{
            registerSaveStatus(cardId, saveStatus);
            return ({
                "NotesCard.useEffect": ()=>{
                    unregisterSaveStatus(cardId);
                }
            })["NotesCard.useEffect"];
        }
    }["NotesCard.useEffect"], [
        saveStatus,
        cardId,
        registerSaveStatus,
        unregisterSaveStatus
    ]);
    // Reset form state when contactId changes (different contact loaded)
    // Using contactId prop as dependency ensures we only update when switching contacts
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NotesCard.useEffect": ()=>{
            if (!contact) return;
            if (prevContactIdRef.current !== contact) {
                prevContactIdRef.current = contact;
                // Batch state updates to avoid cascading renders
                setNotes(contact.notes ?? "");
                setSaveStatus("idle");
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["NotesCard.useEffect"], [
        contact?.contactId,
        contact?.updatedAt
    ]);
    // Track changes using useMemo instead of useEffect
    const hasUnsavedChanges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NotesCard.useMemo[hasUnsavedChanges]": ()=>{
            if (!contact) return false;
            return notes !== (contact.notes ?? "");
        }
    }["NotesCard.useMemo[hasUnsavedChanges]"], [
        notes,
        contact
    ]);
    const saveChanges = ()=>{
        if (!hasUnsavedChanges || !contact) return;
        setSaveStatus("saving");
        updateMutation.mutate({
            contactId,
            updates: {
                notes: notes || null
            }
        }, {
            onSuccess: ()=>{
                setSaveStatus("saved");
                setTimeout(()=>setSaveStatus("idle"), 2000);
            },
            onError: (error)=>{
                setSaveStatus("error");
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Saving notes in NotesCard",
                    tags: {
                        component: "NotesCard",
                        contactId
                    }
                });
                setTimeout(()=>setSaveStatus("idle"), 3000);
            }
        });
    };
    const debouncedSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedSave"])(saveChanges, 500);
    const handleBlur = ()=>{
        if (hasUnsavedChanges) {
            debouncedSave();
        }
    };
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-32 bg-gray-200 rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                lineNumber: 99,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
            lineNumber: 98,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-lg font-semibold text-theme-darkest flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-5 h-5 text-gray-400",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                                    lineNumber: 114,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                                lineNumber: 108,
                                columnNumber: 11
                            }, this),
                            "Notes"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$SavingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        status: saveStatus
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                        lineNumber: 123,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "contact-notes",
                name: "contact-notes",
                rows: 6,
                value: notes,
                onChange: (e)=>setNotes(e.target.value),
                onBlur: handleBlur,
                placeholder: "Add notes about this contact..."
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                lineNumber: 125,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
        lineNumber: 105,
        columnNumber: 5
    }, this);
}
_s(NotesCard, "g8Kv76MUv3AQppowovSQnMBX4Wo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedSave"]
    ];
});
_c = NotesCard;
var _c;
__turbopack_context__.k.register(_c, "NotesCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/TouchpointStatusActions.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TouchpointStatusActions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useAuth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function TouchpointStatusActions({ contactId, contactName, userId, onStatusUpdate, compact = false, currentStatus: fallbackStatus }) {
    _s();
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    // Use userId prop if provided, otherwise fall back to user?.uid
    const effectiveUserId = userId || user?.uid || "";
    // Read contact directly from React Query cache for optimistic updates
    // Fall back to prop if contact isn't in cache (e.g., in ContactCard list view)
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(effectiveUserId, contactId);
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [currentStatus, setCurrentStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(contact?.touchpointStatus ?? fallbackStatus ?? null);
    const [showCancelModal, setShowCancelModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showCompleteModal, setShowCompleteModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reason, setReason] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const mutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateTouchpointStatus"])(effectiveUserId);
    // Reset state ONLY when contactId changes (switching to a different contact)
    // We don't update when updatedAt changes because that would reset our local state
    // during optimistic updates and refetches. The local state is the source of truth
    // until we switch to a different contact.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TouchpointStatusActions.useEffect": ()=>{
            if (!contact && !fallbackStatus) return;
            // Only update if we're switching to a different contact
            if (prevContactIdRef.current !== contactId) {
                prevContactIdRef.current = contactId;
                const statusToUse = contact?.touchpointStatus ?? fallbackStatus ?? null;
                // Batch state updates to avoid cascading renders
                setCurrentStatus(statusToUse);
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["TouchpointStatusActions.useEffect"], [
        contactId,
        fallbackStatus
    ]);
    const handleUpdateStatus = async (status, reason)=>{
        setError(null);
        setCurrentStatus(status);
        mutation.mutate({
            contactId,
            status,
            reason: reason || null
        }, {
            onSuccess: ()=>{
                setShowCancelModal(false);
                setShowCompleteModal(false);
                setReason("");
                onStatusUpdate?.();
            },
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating touchpoint status in TouchpointStatusActions",
                    tags: {
                        component: "TouchpointStatusActions",
                        contactId
                    }
                });
                setError((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
            }
        });
    };
    if (compact) {
        // Compact view for dashboard cards
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-2",
                    children: [
                        currentStatus !== "completed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "success",
                            onClick: ()=>setShowCompleteModal(true),
                            disabled: mutation.isPending,
                            className: "flex-1 cursor-pointer sm:flex-none px-3 py-2 sm:px-2 sm:py-1 text-xs disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 sm:gap-1",
                            title: "I've contacted this person",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-3.5 h-3.5 shrink-0",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M5 13l4 4L19 7"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 114,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 108,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "whitespace-nowrap",
                                    children: "Mark as Contacted"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 121,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 101,
                            columnNumber: 13
                        }, this),
                        currentStatus !== "cancelled" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "outline",
                            onClick: ()=>setShowCancelModal(true),
                            disabled: mutation.isPending,
                            className: "flex-1 sm:flex-none px-3 py-2 sm:px-2 sm:py-1 text-xs font-medium text-foreground border border-theme-medium rounded hover:bg-theme-medium cursor-pointer transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 sm:gap-1",
                            title: "Skip this touchpoint - no action needed",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-3.5 h-3.5 shrink-0",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M6 18L18 6M6 6l12 12"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 138,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 132,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "whitespace-nowrap",
                                    children: "Skip Touchpoint"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 145,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 125,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 99,
                    columnNumber: 9
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                    message: error,
                    dismissible: true,
                    onDismiss: ()=>setError(null)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 150,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    isOpen: showCompleteModal,
                    onClose: ()=>{
                        if (!mutation.isPending) {
                            setShowCompleteModal(false);
                            setReason("");
                            setError(null);
                        }
                    },
                    title: "Mark as Contacted",
                    closeOnBackdropClick: !mutation.isPending,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-theme-dark mb-4",
                            children: [
                                "Mark the touchpoint for ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: contactName
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 169,
                                    columnNumber: 37
                                }, this),
                                " as contacted? This indicates you've reached out to them."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 168,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    htmlFor: "touchpoint-complete-note-compact",
                                    className: "block text-sm font-medium text-theme-darker mb-2",
                                    children: [
                                        "Note (optional)",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs text-gray-500 font-normal ml-1",
                                            children: "— This will be saved and displayed on the contact page"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                            lineNumber: 174,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 172,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "touchpoint-complete-note-compact",
                                    name: "touchpoint-complete-note-compact",
                                    value: reason,
                                    onChange: (e)=>setReason(e.target.value),
                                    placeholder: "e.g., Discussed proposal, scheduled follow-up, sent quote...",
                                    className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                    rows: 3,
                                    disabled: mutation.isPending,
                                    autoComplete: "off",
                                    "data-form-type": "other",
                                    "data-lpignore": "true",
                                    "data-1p-ignore": "true"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 178,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 171,
                            columnNumber: 11
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                                message: error,
                                dismissible: true,
                                onDismiss: ()=>setError(null)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 195,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 194,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-3 justify-end",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>{
                                        setShowCompleteModal(false);
                                        setReason("");
                                        setError(null);
                                    },
                                    disabled: mutation.isPending,
                                    variant: "outline",
                                    size: "sm",
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 203,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>handleUpdateStatus("completed", reason),
                                    disabled: mutation.isPending,
                                    loading: mutation.isPending,
                                    variant: "success",
                                    size: "sm",
                                    children: "Mark as Contacted"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 215,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 202,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 156,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    isOpen: showCancelModal,
                    onClose: ()=>{
                        if (!mutation.isPending) {
                            setShowCancelModal(false);
                            setReason("");
                            setError(null);
                        }
                    },
                    title: "Skip Touchpoint",
                    closeOnBackdropClick: !mutation.isPending,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-theme-dark mb-4",
                            children: [
                                "Skip the touchpoint for ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: contactName
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 239,
                                    columnNumber: 37
                                }, this),
                                "? This indicates no action is needed at this time."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 238,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    htmlFor: "touchpoint-skip-reason-compact",
                                    className: "block text-sm font-medium text-theme-darker mb-2",
                                    children: [
                                        "Reason (optional)",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs text-gray-500 font-normal ml-1",
                                            children: "— This will be saved and displayed on the contact page"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                            lineNumber: 244,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 242,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "touchpoint-skip-reason-compact",
                                    name: "touchpoint-skip-reason-compact",
                                    value: reason,
                                    onChange: (e)=>setReason(e.target.value),
                                    placeholder: "e.g., Not relevant, contact inactive, wrong contact...",
                                    className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                    rows: 3,
                                    disabled: mutation.isPending,
                                    autoComplete: "off",
                                    "data-form-type": "other",
                                    "data-lpignore": "true",
                                    "data-1p-ignore": "true"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 248,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 241,
                            columnNumber: 11
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                                message: error,
                                dismissible: true,
                                onDismiss: ()=>setError(null)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 265,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 264,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-3 justify-end",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>{
                                        setShowCancelModal(false);
                                        setReason("");
                                        setError(null);
                                    },
                                    disabled: mutation.isPending,
                                    size: "sm",
                                    children: "Keep Touchpoint"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 273,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>handleUpdateStatus("cancelled", reason),
                                    disabled: mutation.isPending,
                                    loading: mutation.isPending,
                                    variant: "outline",
                                    size: "sm",
                                    children: "Skip Touchpoint"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 284,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 272,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 226,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
            lineNumber: 98,
            columnNumber: 7
        }, this);
    }
    // Full view for contact detail page
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    currentStatus === "completed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "px-3 py-1 text-sm font-medium text-green-700 bg-green-50 border border-green-200 rounded-full",
                        children: "✓ Contacted"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 304,
                        columnNumber: 11
                    }, this),
                    currentStatus === "cancelled" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "px-3 py-1 text-sm font-medium text-[#eeeeec] bg-theme-medium rounded-full",
                        children: "✕ Skipped"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 309,
                        columnNumber: 11
                    }, this),
                    (!currentStatus || currentStatus === "pending") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "px-3 py-1 text-sm font-medium text-blue-700 bg-blue-50 border border-blue-200 rounded-full",
                        children: "Pending"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 314,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 302,
                columnNumber: 7
            }, this),
            (!currentStatus || currentStatus === "pending") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>setShowCompleteModal(true),
                        disabled: mutation.isPending,
                        variant: "success",
                        size: "sm",
                        children: "Mark as Contacted"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 322,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>setShowCancelModal(true),
                        disabled: mutation.isPending,
                        variant: "outline",
                        size: "sm",
                        children: "Skip Touchpoint"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 330,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 321,
                columnNumber: 9
            }, this),
            (currentStatus === "completed" || currentStatus === "cancelled") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                onClick: ()=>handleUpdateStatus(null),
                disabled: mutation.isPending,
                loading: mutation.isPending,
                variant: "outline",
                size: "sm",
                className: "text-blue-700 bg-blue-50 hover:bg-blue-100",
                children: "Restore to Pending"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 342,
                columnNumber: 9
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                message: error,
                dismissible: true,
                onDismiss: ()=>setError(null)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 355,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showCompleteModal,
                onClose: ()=>{
                    if (!mutation.isPending) {
                        setShowCompleteModal(false);
                        setReason("");
                        setError(null);
                    }
                },
                title: "Mark as Contacted",
                closeOnBackdropClick: !mutation.isPending,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-theme-dark mb-4",
                        children: [
                            "Mark the touchpoint for ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: contactName
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 376,
                                columnNumber: 35
                            }, this),
                            " as contacted? This indicates you've reached out to them."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 375,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "touchpoint-complete-note",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: [
                                    "Note (optional)",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-500 font-normal ml-1",
                                        children: "— This will be saved and displayed on the contact page"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 381,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 379,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "touchpoint-complete-note",
                                name: "touchpoint-complete-note",
                                value: reason,
                                onChange: (e)=>setReason(e.target.value),
                                placeholder: "e.g., Discussed proposal, scheduled follow-up, sent quote...",
                                className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                rows: 3,
                                disabled: mutation.isPending,
                                autoComplete: "off",
                                "data-form-type": "other",
                                "data-lpignore": "true",
                                "data-1p-ignore": "true"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 385,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 378,
                        columnNumber: 9
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                            message: error,
                            dismissible: true,
                            onDismiss: ()=>setError(null)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 402,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 401,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>{
                                    setShowCompleteModal(false);
                                    setReason("");
                                    setError(null);
                                },
                                disabled: mutation.isPending,
                                variant: "secondary",
                                size: "sm",
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 410,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>handleUpdateStatus("completed", reason),
                                disabled: mutation.isPending,
                                loading: mutation.isPending,
                                variant: "success",
                                size: "sm",
                                children: "Mark Completed"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 422,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 409,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 363,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showCancelModal,
                onClose: ()=>{
                    if (!mutation.isPending) {
                        setShowCancelModal(false);
                        setReason("");
                        setError(null);
                    }
                },
                title: "Skip Touchpoint",
                closeOnBackdropClick: !mutation.isPending,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-theme-dark mb-4",
                        children: [
                            "Skip the touchpoint for ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: contactName
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 447,
                                columnNumber: 35
                            }, this),
                            "? This indicates no action is needed at this time."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 446,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "touchpoint-skip-reason",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: [
                                    "Reason (optional)",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-500 font-normal ml-1",
                                        children: "— This will be saved and displayed on the contact page"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 452,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 450,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "touchpoint-skip-reason",
                                name: "touchpoint-skip-reason",
                                value: reason,
                                onChange: (e)=>setReason(e.target.value),
                                placeholder: "e.g., Not relevant, contact inactive, wrong contact...",
                                className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                rows: 3,
                                disabled: mutation.isPending,
                                autoComplete: "off",
                                "data-form-type": "other",
                                "data-lpignore": "true",
                                "data-1p-ignore": "true"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 456,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 449,
                        columnNumber: 9
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                            message: error,
                            dismissible: true,
                            onDismiss: ()=>setError(null)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 473,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 472,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>{
                                    setShowCancelModal(false);
                                    setReason("");
                                    setError(null);
                                },
                                disabled: mutation.isPending,
                                size: "sm",
                                children: "Keep Touchpoint"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 481,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>handleUpdateStatus("cancelled", reason),
                                disabled: mutation.isPending,
                                loading: mutation.isPending,
                                variant: "outline",
                                size: "sm",
                                children: "Skip Touchpoint"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 492,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 480,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 434,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
        lineNumber: 301,
        columnNumber: 5
    }, this);
}
_s(TouchpointStatusActions, "1Jh2UPZgvdtuvTUSRXwI+3BTGhA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateTouchpointStatus"]
    ];
});
_c = TouchpointStatusActions;
var _c;
__turbopack_context__.k.register(_c, "TouchpointStatusActions");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NextTouchpointCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useDebouncedSave.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$SavingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$TouchpointStatusActions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/TouchpointStatusActions.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/SavingStateContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
function NextTouchpointCard({ contactId, userId }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const updateMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"])(userId);
    const { registerSaveStatus, unregisterSaveStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"])();
    const cardId = `next-touchpoint-${contactId}`;
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Initialize form state from contact using lazy initialization
    const [nextTouchpointDate, setNextTouchpointDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [nextTouchpointMessage, setNextTouchpointMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [saveStatus, setSaveStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    // Register/unregister save status with context
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NextTouchpointCard.useEffect": ()=>{
            registerSaveStatus(cardId, saveStatus);
            return ({
                "NextTouchpointCard.useEffect": ()=>{
                    unregisterSaveStatus(cardId);
                }
            })["NextTouchpointCard.useEffect"];
        }
    }["NextTouchpointCard.useEffect"], [
        saveStatus,
        cardId,
        registerSaveStatus,
        unregisterSaveStatus
    ]);
    // Reset form state ONLY when contactId changes (switching to a different contact)
    // We don't update when updatedAt changes because that would reset our local state
    // during optimistic updates and refetches. The local state is the source of truth
    // until we switch to a different contact.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NextTouchpointCard.useEffect": ()=>{
            if (!contact) return;
            // Only update if we're switching to a different contact
            if (prevContactIdRef.current !== contact.contactId) {
                prevContactIdRef.current = contact.contactId;
                // Batch state updates to avoid cascading renders
                const dateValue = contact.nextTouchpointDate instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"] ? contact.nextTouchpointDate.toDate().toISOString().split("T")[0] : typeof contact.nextTouchpointDate === "string" ? contact.nextTouchpointDate.split("T")[0] : "";
                setNextTouchpointDate(dateValue);
                setNextTouchpointMessage(contact.nextTouchpointMessage ?? "");
                setSaveStatus("idle");
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["NextTouchpointCard.useEffect"], [
        contact?.contactId
    ]);
    // Track changes using useMemo instead of useEffect
    const hasUnsavedChanges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NextTouchpointCard.useMemo[hasUnsavedChanges]": ()=>{
            if (!contact) return false;
            const contactDate = contact.nextTouchpointDate instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"] ? contact.nextTouchpointDate.toDate().toISOString().split("T")[0] : typeof contact.nextTouchpointDate === "string" ? contact.nextTouchpointDate.split("T")[0] : "";
            const dateChanged = nextTouchpointDate !== contactDate;
            const messageChanged = nextTouchpointMessage !== (contact.nextTouchpointMessage ?? "");
            return dateChanged || messageChanged;
        }
    }["NextTouchpointCard.useMemo[hasUnsavedChanges]"], [
        nextTouchpointDate,
        nextTouchpointMessage,
        contact
    ]);
    const saveChanges = ()=>{
        if (!hasUnsavedChanges || !contact) return;
        setSaveStatus("saving");
        updateMutation.mutate({
            contactId,
            updates: {
                nextTouchpointDate: nextTouchpointDate || null,
                nextTouchpointMessage: nextTouchpointMessage || null
            }
        }, {
            onSuccess: ()=>{
                setSaveStatus("saved");
                setTimeout(()=>setSaveStatus("idle"), 2000);
            },
            onError: (error)=>{
                setSaveStatus("error");
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Saving next touchpoint in NextTouchpointCard",
                    tags: {
                        component: "NextTouchpointCard",
                        contactId
                    }
                });
                setTimeout(()=>setSaveStatus("idle"), 3000);
            }
        });
    };
    const debouncedSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedSave"])(saveChanges, 500);
    const handleBlur = ()=>{
        if (hasUnsavedChanges) {
            debouncedSave();
        }
    };
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-48 bg-gray-200 rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 126,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
            lineNumber: 125,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-lg font-semibold text-theme-darkest flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-5 h-5 text-gray-400",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                    lineNumber: 141,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 135,
                                columnNumber: 11
                            }, this),
                            "Next Touchpoint"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 134,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$SavingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        status: saveStatus
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 150,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 133,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-theme-dark mb-4",
                children: "Schedule and plan your next interaction with this contact. Set a date and add notes about what to discuss to maintain consistent, meaningful engagement."
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 152,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "next-touchpoint-date",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Date"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 157,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                id: "next-touchpoint-date",
                                type: "date",
                                className: "w-full px-4 py-2 border border-gray-300 rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200",
                                value: nextTouchpointDate,
                                onChange: (e)=>{
                                    const dateValue = e.target.value;
                                    if (dateValue && dateValue.match(/^\d{4}-\d{2}-\d{2}$/)) {
                                        setNextTouchpointDate(dateValue);
                                    } else if (!dateValue) {
                                        setNextTouchpointDate("");
                                    }
                                },
                                onBlur: handleBlur
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 160,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 156,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "next-touchpoint-message",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Message"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 177,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "next-touchpoint-message",
                                name: "next-touchpoint-message",
                                rows: 3,
                                value: nextTouchpointMessage,
                                onChange: (e)=>setNextTouchpointMessage(e.target.value),
                                onBlur: handleBlur,
                                placeholder: "What should you discuss in the next touchpoint?"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 180,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 155,
                columnNumber: 7
            }, this),
            (nextTouchpointDate || contact.touchpointStatus) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 pt-4 border-t border-gray-200",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$TouchpointStatusActions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        contactId: contactId,
                        contactName: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contact),
                        userId: userId,
                        onStatusUpdate: ()=>{
                        // No-op: React Query will automatically update the contact data
                        }
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 195,
                        columnNumber: 11
                    }, this),
                    contact.touchpointStatusUpdatedAt != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-2",
                        children: [
                            "Status updated:",
                            " ",
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(contact.touchpointStatusUpdatedAt, {
                                relative: true
                            })
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 204,
                        columnNumber: 13
                    }, this),
                    contact.touchpointStatusReason && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3 p-3 bg-theme-lighter border border-gray-200 rounded-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs font-medium text-gray-500 uppercase tracking-wide mb-1",
                                children: contact.touchpointStatus === "completed" ? "Note" : "Reason"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 213,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-theme-darker",
                                children: contact.touchpointStatusReason
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 216,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 212,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 194,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
        lineNumber: 132,
        columnNumber: 5
    }, this);
}
_s(NextTouchpointCard, "Ies7cjt9H++iVopbU4AmE7T4Azo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedSave"]
    ];
});
_c = NextTouchpointCard;
var _c;
__turbopack_context__.k.register(_c, "NextTouchpointCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OutreachDraftCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useDebouncedSave.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$SavingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/SavingIndicator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/SavingStateContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
function OutreachDraftCard({ contactId, userId }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const updateMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"])(userId);
    const { registerSaveStatus, unregisterSaveStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"])();
    const cardId = `outreach-draft-${contactId}`;
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [localDraft, setLocalDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [saveStatus, setSaveStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    const [modalContent, setModalContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Register/unregister save status with context
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OutreachDraftCard.useEffect": ()=>{
            registerSaveStatus(cardId, saveStatus);
            return ({
                "OutreachDraftCard.useEffect": ()=>{
                    unregisterSaveStatus(cardId);
                }
            })["OutreachDraftCard.useEffect"];
        }
    }["OutreachDraftCard.useEffect"], [
        saveStatus,
        cardId,
        registerSaveStatus,
        unregisterSaveStatus
    ]);
    // Reset form state when contactId changes (different contact loaded)
    // Using contactId prop as dependency ensures we only update when switching contacts
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OutreachDraftCard.useEffect": ()=>{
            if (!contact) return;
            if (prevContactIdRef.current !== contact) {
                prevContactIdRef.current = contact;
                // Batch state updates to avoid cascading renders
                setLocalDraft(contact.outreachDraft ?? "");
                setSaveStatus("idle");
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["OutreachDraftCard.useEffect"], [
        contact?.contactId,
        contact?.updatedAt
    ]);
    // Track changes using useMemo instead of useEffect
    const hasUnsavedChanges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "OutreachDraftCard.useMemo[hasUnsavedChanges]": ()=>{
            if (!contact) return false;
            return localDraft !== (contact.outreachDraft ?? "");
        }
    }["OutreachDraftCard.useMemo[hasUnsavedChanges]"], [
        localDraft,
        contact
    ]);
    const saveChanges = ()=>{
        if (!hasUnsavedChanges || !contact) return;
        setSaveStatus("saving");
        updateMutation.mutate({
            contactId,
            updates: {
                outreachDraft: localDraft || null
            }
        }, {
            onSuccess: ()=>{
                setSaveStatus("saved");
                setTimeout(()=>setSaveStatus("idle"), 2000);
            },
            onError: (error)=>{
                setSaveStatus("error");
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Saving outreach draft in OutreachDraftCard",
                    tags: {
                        component: "OutreachDraftCard",
                        contactId
                    }
                });
                setTimeout(()=>setSaveStatus("idle"), 3000);
            }
        });
    };
    const debouncedSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedSave"])(saveChanges, 500);
    const handleBlur = ()=>{
        if (hasUnsavedChanges) {
            debouncedSave();
        }
    };
    const openGmailCompose = ()=>{
        if (!contact?.primaryEmail) {
            setModalContent("no-email");
            return;
        }
        if (!localDraft.trim()) {
            setModalContent("no-draft");
            return;
        }
        // Auto-save the draft before opening Gmail (if there are unsaved changes)
        if (hasUnsavedChanges) {
            setSaveStatus("saving");
            updateMutation.mutate({
                contactId,
                updates: {
                    outreachDraft: localDraft || null
                }
            }, {
                onSuccess: ()=>{
                    setSaveStatus("saved");
                    // Open Gmail after save completes
                    const email = encodeURIComponent(contact.primaryEmail);
                    const body = encodeURIComponent(localDraft);
                    const subject = encodeURIComponent("Follow up");
                    const gmailUrl = `https://mail.google.com/mail/?view=cm&to=${email}&body=${body}&su=${subject}`;
                    window.open(gmailUrl, "_blank");
                    setTimeout(()=>setSaveStatus("idle"), 2000);
                },
                onError: (error)=>{
                    setSaveStatus("error");
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                        context: "Auto-saving outreach draft before opening Gmail in OutreachDraftCard",
                        tags: {
                            component: "OutreachDraftCard",
                            contactId
                        }
                    });
                    // Continue anyway - don't block user from opening Gmail
                    const email = encodeURIComponent(contact.primaryEmail);
                    const body = encodeURIComponent(localDraft);
                    const subject = encodeURIComponent("Follow up");
                    const gmailUrl = `https://mail.google.com/mail/?view=cm&to=${email}&body=${body}&su=${subject}`;
                    window.open(gmailUrl, "_blank");
                    setTimeout(()=>setSaveStatus("idle"), 3000);
                }
            });
        } else {
            // No changes, just open Gmail
            const email = encodeURIComponent(contact.primaryEmail);
            const body = encodeURIComponent(localDraft);
            const subject = encodeURIComponent("Follow up");
            const gmailUrl = `https://mail.google.com/mail/?view=cm&to=${email}&body=${body}&su=${subject}`;
            window.open(gmailUrl, "_blank");
        }
    };
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-32 bg-gray-200 rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                lineNumber: 158,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
            lineNumber: 157,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: modalContent !== null,
                onClose: ()=>setModalContent(null),
                title: modalContent === "no-email" ? "No Email Address" : "No Draft Message",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-theme-dark mb-6",
                        children: modalContent === "no-email" ? "This contact does not have an email address." : "Please add a draft message before continuing in Gmail."
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                        lineNumber: 171,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            onClick: ()=>setModalContent(null),
                            variant: "secondary",
                            size: "sm",
                            children: "OK"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                            lineNumber: 177,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                padding: "md",
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-6 right-6 xl:hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$SavingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            status: saveStatus
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                            lineNumber: 190,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                        lineNumber: 189,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col xl:flex-row xl:items-center xl:justify-between gap-3 mb-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-lg font-semibold text-theme-darkest flex items-center gap-2 pr-20 xl:pr-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-5 h-5 text-gray-400 shrink-0",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                            lineNumber: 201,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                        lineNumber: 195,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "truncate",
                                        children: "Outreach Draft"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                        lineNumber: 208,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                lineNumber: 194,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3 shrink-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "hidden xl:block",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$SavingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            status: saveStatus
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                            lineNumber: 213,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                        lineNumber: 212,
                                        columnNumber: 13
                                    }, this),
                                    localDraft.trim() && contact.primaryEmail && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        onClick: openGmailCompose,
                                        variant: "link",
                                        size: "sm",
                                        "aria-label": "Open this draft in Gmail",
                                        className: "whitespace-nowrap",
                                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-4 h-4 shrink-0",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            "aria-hidden": "true",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                                lineNumber: 230,
                                                columnNumber: 21
                                            }, void 0)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                            lineNumber: 223,
                                            columnNumber: 19
                                        }, void 0),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "hidden sm:inline",
                                                children: "Continue in Gmail"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                                lineNumber: 239,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "sm:hidden",
                                                children: "Gmail"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                                lineNumber: 240,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                        lineNumber: 216,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                lineNumber: 210,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                        lineNumber: 193,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-theme-dark mb-4",
                        children: "Draft and refine your email messages before sending. Your draft is automatically saved and can be opened directly in Gmail when ready to send."
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                        lineNumber: 245,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        id: "outreach-draft",
                        name: "outreach-draft",
                        value: localDraft,
                        onChange: (e)=>setLocalDraft(e.target.value),
                        onBlur: handleBlur,
                        placeholder: "Write your outreach draft here...",
                        className: "min-h-[120px] text-foreground resize-y font-sans text-sm leading-relaxed"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                        lineNumber: 248,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                lineNumber: 187,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(OutreachDraftCard, "MexYDLYnpsnzy8V4OcjLNvASYF0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedSave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedSave"]
    ];
});
_c = OutreachDraftCard;
var _c;
__turbopack_context__.k.register(_c, "OutreachDraftCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactInsightsCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/InfoPopover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ContactInsightsCard({ contactId, userId, initialContact }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const displayContact = contact || initialContact;
    if (!displayContact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-96 bg-gray-200 rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                lineNumber: 26,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
            lineNumber: 25,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold text-theme-darkest mb-6",
                children: "Contact Insights"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: [
                    displayContact.summary && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-l-4 border-indigo-500 pl-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-indigo-600",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 45,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 39,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                        children: "AI Summary"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 52,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 38,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-theme-darkest whitespace-pre-wrap leading-relaxed",
                                children: displayContact.summary
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 56,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                        lineNumber: 37,
                        columnNumber: 11
                    }, this),
                    (()=>{
                        const engagementScore = Number(displayContact.engagementScore);
                        const isValidScore = !isNaN(engagementScore) && engagementScore !== null && engagementScore !== undefined;
                        return isValidScore ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "border-l-4 border-teal-500 pl-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2 mb-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-4 h-4 text-teal-600",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                                lineNumber: 78,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 72,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                            children: "Engagement Score"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 85,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            content: "A numerical score (0-100) that measures how actively engaged this contact is with your communications. Higher scores indicate more frequent interactions, email opens, responses, and overall engagement with your content."
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 88,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                    lineNumber: 71,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1 bg-gray-200 rounded-full h-2",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-teal-600 h-2 rounded-full",
                                                style: {
                                                    width: `${Math.min(engagementScore, 100)}%`
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                                lineNumber: 92,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 91,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-sm font-semibold text-theme-darkest",
                                            children: Math.round(engagementScore)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 97,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                    lineNumber: 90,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                            lineNumber: 70,
                            columnNumber: 13
                        }, this) : null;
                    })(),
                    displayContact.threadCount && displayContact.threadCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-l-4 border-cyan-500 pl-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-cyan-600",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 115,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 109,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                        children: "Email Threads"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 122,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 108,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm font-semibold text-theme-darkest",
                                children: displayContact.threadCount
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 126,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                        lineNumber: 107,
                        columnNumber: 11
                    }, this),
                    displayContact.lastEmailDate != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-l-4 border-blue-500 pl-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-blue-600",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 142,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 136,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                        children: "Last Email Date"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 149,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 135,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm font-semibold text-theme-darkest",
                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(displayContact.lastEmailDate, {
                                    relative: true
                                })
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 153,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-500 mt-1",
                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(displayContact.lastEmailDate, {
                                    includeTime: true
                                })
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 156,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                        lineNumber: 134,
                        columnNumber: 11
                    }, this),
                    displayContact.painPoints && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-l-4 border-red-500 pl-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-red-600",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 172,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 166,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                        children: "Pain Points"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 179,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 165,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-theme-darkest whitespace-pre-wrap leading-relaxed",
                                children: displayContact.painPoints
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 183,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                        lineNumber: 164,
                        columnNumber: 11
                    }, this),
                    displayContact.sentiment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-l-4 border-purple-500 pl-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-purple-600",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 198,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 192,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                        children: "Sentiment"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 205,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 191,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `inline-block px-2 py-1 rounded-full text-xs font-medium ${displayContact.sentiment.toLowerCase().includes("positive") ? "bg-green-100 text-green-800" : displayContact.sentiment.toLowerCase().includes("negative") ? "bg-red-100 text-red-800" : "bg-gray-100 text-theme-darker"}`,
                                children: displayContact.sentiment
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 209,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                        lineNumber: 190,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_s(ContactInsightsCard, "RMraLUiYNjzSbpembo7KgOc4sVs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"]
    ];
});
_c = ContactInsightsCard;
var _c;
__turbopack_context__.k.register(_c, "ContactInsightsCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActivityCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ActivityCard({ contactId, userId }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-32 bg-gray-200 rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                lineNumber: 18,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
            lineNumber: 17,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-lg font-semibold text-theme-darkest mb-4",
                children: "Activity"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3 text-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-start gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-2 h-2 bg-blue-500 rounded-full mt-1.5"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                lineNumber: 28,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-medium text-theme-darkest",
                                        children: "Last updated"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                        lineNumber: 30,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-500",
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(contact.updatedAt, {
                                            includeTime: true
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                        lineNumber: 31,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                lineNumber: 29,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, this),
                    contact.createdAt != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-start gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-2 h-2 bg-green-500 rounded-full mt-1.5"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                lineNumber: 38,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-medium text-theme-darkest",
                                        children: "Created"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                        lineNumber: 40,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-500",
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(contact.createdAt, {
                                            includeTime: true
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                        lineNumber: 41,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                lineNumber: 39,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                        lineNumber: 37,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
_s(ActivityCard, "RMraLUiYNjzSbpembo7KgOc4sVs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"]
    ];
});
_c = ActivityCard;
var _c;
__turbopack_context__.k.register(_c, "ActivityCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/ArchiveContactCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ArchiveContactCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/SavingStateContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function ArchiveContactCard({ contactId, userId }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const archiveContactMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useArchiveContact"])(userId);
    const [archiveError, setArchiveError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { registerSaveStatus, unregisterSaveStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"])();
    const cardId = `archive-${contactId}`;
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isArchived, setIsArchived] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [saveStatus, setSaveStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    // Register/unregister save status with context
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ArchiveContactCard.useEffect": ()=>{
            registerSaveStatus(cardId, saveStatus);
            return ({
                "ArchiveContactCard.useEffect": ()=>{
                    unregisterSaveStatus(cardId);
                }
            })["ArchiveContactCard.useEffect"];
        }
    }["ArchiveContactCard.useEffect"], [
        saveStatus,
        cardId,
        registerSaveStatus,
        unregisterSaveStatus
    ]);
    // Reset state ONLY when contactId changes (switching to a different contact)
    // We don't update when updatedAt changes because that would reset our local state
    // during optimistic updates and refetches. The local state is the source of truth
    // until we switch to a different contact.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ArchiveContactCard.useEffect": ()=>{
            if (!contact) return;
            // Only update if we're switching to a different contact
            if (prevContactIdRef.current !== contact.contactId) {
                prevContactIdRef.current = contact.contactId;
                // Batch state updates to avoid cascading renders
                setIsArchived(contact.archived === true);
                setSaveStatus("idle");
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["ArchiveContactCard.useEffect"], [
        contact?.contactId
    ]);
    const archiveContact = (archived)=>{
        setIsArchived(archived);
        setArchiveError(null);
        archiveContactMutation.mutate({
            contactId,
            archived
        }, {
            onSuccess: ()=>{
                setSaveStatus("saved");
                setTimeout(()=>setSaveStatus("idle"), 2000);
            },
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Archiving contact in ArchiveContactCard",
                    tags: {
                        component: "ArchiveContactCard",
                        contactId
                    }
                });
                setArchiveError((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
            }
        });
    };
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-16 bg-gray-200 rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ArchiveContactCard.tsx",
                lineNumber: 84,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/ArchiveContactCard.tsx",
            lineNumber: 83,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
            onClick: ()=>{
                archiveContact(!isArchived);
            },
            disabled: archiveContactMutation.isPending,
            loading: archiveContactMutation.isPending,
            variant: "outline",
            fullWidth: true,
            error: archiveError,
            icon: isArchived ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: "w-4 h-4",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/ArchiveContactCard.tsx",
                    lineNumber: 108,
                    columnNumber: 15
                }, void 0)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ArchiveContactCard.tsx",
                lineNumber: 102,
                columnNumber: 13
            }, void 0) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: "w-4 h-4",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/ArchiveContactCard.tsx",
                    lineNumber: 122,
                    columnNumber: 15
                }, void 0)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ArchiveContactCard.tsx",
                lineNumber: 116,
                columnNumber: 13
            }, void 0),
            className: "mb-3",
            children: isArchived ? "Unarchive Contact" : "Archive Contact"
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/ArchiveContactCard.tsx",
            lineNumber: 91,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/_components/contact-cards/ArchiveContactCard.tsx",
        lineNumber: 90,
        columnNumber: 5
    }, this);
}
_s(ArchiveContactCard, "383d8kFmAnPMDqghtOwt5W7xRxw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useArchiveContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$SavingStateContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSavingState"]
    ];
});
_c = ArchiveContactCard;
var _c;
__turbopack_context__.k.register(_c, "ArchiveContactCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DeleteContactCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function DeleteContactCard({ contactId }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const deleteContactMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeleteContact"])();
    const [showDeleteConfirm, setShowDeleteConfirm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [deleteError, setDeleteError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const deleteContact = ()=>{
        setDeleteError(null);
        deleteContactMutation.mutate(contactId, {
            onSuccess: ()=>{
                router.push("/contacts");
            },
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Deleting contact in DeleteContactCard",
                    tags: {
                        component: "DeleteContactCard",
                        contactId
                    }
                });
                setDeleteError((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
            }
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showDeleteConfirm,
                onClose: ()=>setShowDeleteConfirm(false),
                title: "Delete Contact",
                closeOnBackdropClick: !deleteContactMutation.isPending,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-theme-dark mb-6",
                        children: "Are you sure? Deleting this contact is final and cannot be undone."
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>setShowDeleteConfirm(false),
                                disabled: deleteContactMutation.isPending,
                                variant: "secondary",
                                size: "sm",
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx",
                                lineNumber: 53,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: deleteContact,
                                disabled: deleteContactMutation.isPending,
                                loading: deleteContactMutation.isPending,
                                variant: "danger",
                                size: "sm",
                                error: deleteError,
                                children: "Delete"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx",
                                lineNumber: 61,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx",
                        lineNumber: 52,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                padding: "md",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>setShowDeleteConfirm(true),
                        disabled: deleteContactMutation.isPending || showDeleteConfirm,
                        variant: "danger",
                        fullWidth: true,
                        error: deleteError,
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx",
                                lineNumber: 88,
                                columnNumber: 15
                            }, void 0)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx",
                            lineNumber: 82,
                            columnNumber: 13
                        }, void 0),
                        children: "Delete Contact"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx",
                        lineNumber: 75,
                        columnNumber: 9
                    }, this),
                    deleteError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                            message: deleteError,
                            dismissible: true,
                            onDismiss: ()=>setDeleteError(null)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx",
                            lineNumber: 101,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx",
                        lineNumber: 100,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(DeleteContactCard, "z/3re13TqJZT5aJW4AkhdgZk2CA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeleteContact"]
    ];
});
_c = DeleteContactCard;
var _c;
__turbopack_context__.k.register(_c, "DeleteContactCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ContactEditor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$BasicInfoCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$TagsClassificationCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ActionItemsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$NotesCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/NotesCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$NextTouchpointCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$OutreachDraftCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ContactInsightsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ActivityCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ArchiveContactCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/ArchiveContactCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$DeleteContactCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/DeleteContactCard.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
function ContactEditor({ contactDocumentId, userId, initialActionItems, initialContact, uniqueSegments = [] }) {
    _s();
    // Read contact directly from React Query cache for optimistic updates
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactDocumentId);
    // Show loading state if contact is not available
    if (!contact && !initialContact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-96 bg-gray-200 rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                lineNumber: 38,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
            lineNumber: 37,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-1 xl:grid-cols-3 gap-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "xl:col-span-2 space-y-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$BasicInfoCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$TagsClassificationCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId,
                            uniqueSegments: uniqueSegments
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 49,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ActionItemsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId,
                            initialActionItems: initialActionItems,
                            initialContact: contact || undefined
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 54,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$NextTouchpointCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 60,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$OutreachDraftCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 61,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$NotesCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 62,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                    lineNumber: 47,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-6 xl:sticky xl:top-6 xl:self-start",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ContactInsightsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId,
                            initialContact: initialContact
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ActivityCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 72,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ArchiveContactCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 73,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$DeleteContactCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 74,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                    lineNumber: 66,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
            lineNumber: 45,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_s(ContactEditor, "RMraLUiYNjzSbpembo7KgOc4sVs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"]
    ];
});
_c = ContactEditor;
var _c;
__turbopack_context__.k.register(_c, "ContactEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ContactsLink.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactsLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
function ContactsLink({ variant = "default", className = "", children = "Back to Contacts" }) {
    const baseClasses = "transition-colors duration-200 font-medium cursor-pointer";
    const variantClasses = {
        default: "flex items-center gap-2 px-4 py-2 text-theme-darkest hover:text-theme-medium rounded-sm",
        error: "inline-block px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-sm"
    };
    const iconSvg = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        className: "w-5 h-5",
        fill: "none",
        stroke: "currentColor",
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 2,
            d: "M10 19l-7-7m0 0l7-7m-7 7h18"
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/ContactsLink.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/_components/ContactsLink.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: "/contacts",
        className: `${baseClasses} ${variantClasses[variant]} ${className}`,
        children: [
            variant !== "error" && iconSvg,
            children
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/ContactsLink.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
}
_c = ContactsLink;
var _c;
__turbopack_context__.k.register(_c, "ContactsLink");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactDetailPageClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ThemedSuspense$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ThemedSuspense.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ContactEditor.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactsLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ContactsLink.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useActionItems.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function ContactDetailContent({ contactDocumentId, userId, initialActionItems, uniqueSegments }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactDocumentId);
    const { data: actionItems = initialActionItems || [] } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"])(userId, contactDocumentId, initialActionItems);
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-20 bg-gray-200 rounded animate-pulse"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                    lineNumber: 39,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-96 bg-gray-200 rounded animate-pulse"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                    lineNumber: 40,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
            lineNumber: 38,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col xl:flex-row xl:items-start xl:justify-between gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4 min-w-0 flex-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-16 h-16 bg-linear-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold text-2xl shadow-lg shrink-0",
                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(contact)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                lineNumber: 50,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-w-0 flex-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "text-3xl font-bold text-theme-darkest mb-1 truncate",
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contact)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                        lineNumber: 54,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-500 flex items-center gap-2 min-w-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-4 h-4 shrink-0",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                                    lineNumber: 64,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                                lineNumber: 58,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "truncate",
                                                children: contact.primaryEmail
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                                lineNumber: 71,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                        lineNumber: 57,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                lineNumber: 53,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hidden xl:block",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactsLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "default"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                        lineNumber: 75,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                contactDocumentId: contactDocumentId,
                userId: userId,
                initialActionItems: actionItems,
                uniqueSegments: uniqueSegments
            }, void 0, false, {
                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(ContactDetailContent, "O2scNxGYdEyGpFgjTxPX2u9HyAY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"]
    ];
});
_c = ContactDetailContent;
function ContactDetailPageClient({ contactDocumentId, userId, initialActionItems, uniqueSegments }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "xl:hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactsLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "default"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                    lineNumber: 101,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ThemedSuspense$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-16 h-16 bg-theme-light rounded-full animate-pulse"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                    lineNumber: 109,
                                    columnNumber: 15
                                }, void 0),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-8 bg-theme-light rounded w-48 animate-pulse"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                            lineNumber: 111,
                                            columnNumber: 17
                                        }, void 0),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-5 bg-theme-light rounded w-64 animate-pulse"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                            lineNumber: 112,
                                            columnNumber: 17
                                        }, void 0)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                    lineNumber: 110,
                                    columnNumber: 15
                                }, void 0)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                            lineNumber: 108,
                            columnNumber: 13
                        }, void 0),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-96 bg-theme-light rounded animate-pulse"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                            lineNumber: 115,
                            columnNumber: 13
                        }, void 0)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                    lineNumber: 107,
                    columnNumber: 11
                }, void 0),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContactDetailContent, {
                    contactDocumentId: contactDocumentId,
                    userId: userId,
                    initialActionItems: initialActionItems,
                    uniqueSegments: uniqueSegments
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                    lineNumber: 119,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
        lineNumber: 98,
        columnNumber: 5
    }, this);
}
_c1 = ContactDetailPageClient;
var _c, _c1;
__turbopack_context__.k.register(_c, "ContactDetailContent");
__turbopack_context__.k.register(_c1, "ContactDetailPageClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/contacts/[contactId]/_components/ContactDetailPageClientWrapper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactDetailPageClientWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useActionItems.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useAuth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$timestamp$2d$utils$2d$server$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/timestamp-utils-server.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f5b$contactId$5d2f$ContactDetailPageClient$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function ContactDetailPageClientWrapper({ contactId, userId }) {
    _s();
    const { user, loading: authLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    // Use userId prop if provided (from SSR), otherwise get from client auth (for E2E mode or if SSR didn't have it)
    // In production, userId prop should always be provided from SSR
    // In E2E mode, it might be empty, so we wait for auth to load and use user?.uid
    const effectiveUserId = userId || (authLoading ? "" : user?.uid || "");
    // React Query automatically uses prefetched data from HydrationBoundary
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(effectiveUserId, contactId);
    const { data: actionItems = [] } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"])(effectiveUserId, contactId);
    const { data: uniqueSegments = [] } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "unique-segments",
            effectiveUserId
        ],
        queryFn: {
            "ContactDetailPageClientWrapper.useQuery": async ()=>{
                // For now, we'll fetch all contacts and extract unique segments
                // TODO: Create an API route for this if needed
                const response = await fetch("/api/contacts");
                if (!response.ok) {
                    return [];
                }
                const data = await response.json();
                const contacts = data.contacts || [];
                const segments = new Set();
                contacts.forEach({
                    "ContactDetailPageClientWrapper.useQuery": (contact)=>{
                        if (contact.segment?.trim()) {
                            segments.add(contact.segment.trim());
                        }
                    }
                }["ContactDetailPageClientWrapper.useQuery"]);
                return Array.from(segments).sort();
            }
        }["ContactDetailPageClientWrapper.useQuery"],
        staleTime: 5 * 60 * 1000
    });
    if (!contact) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notFound"])();
    }
    // Action items are already converted to ISO strings on the server
    // This is just a safety check in case any timestamps slipped through
    const serializedActionItems = actionItems.map((item)=>({
            ...item,
            dueDate: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$timestamp$2d$utils$2d$server$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertTimestampToISO"])(item.dueDate),
            completedAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$timestamp$2d$utils$2d$server$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertTimestampToISO"])(item.completedAt),
            createdAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$timestamp$2d$utils$2d$server$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertTimestampToISO"])(item.createdAt) || new Date().toISOString(),
            updatedAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$timestamp$2d$utils$2d$server$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertTimestampToISO"])(item.updatedAt) || new Date().toISOString()
        }));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f5b$contactId$5d2f$ContactDetailPageClient$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        contactDocumentId: contactId,
        userId: userId,
        initialActionItems: serializedActionItems,
        uniqueSegments: uniqueSegments
    }, void 0, false, {
        fileName: "[project]/app/(crm)/contacts/[contactId]/_components/ContactDetailPageClientWrapper.tsx",
        lineNumber: 66,
        columnNumber: 5
    }, this);
}
_s(ContactDetailPageClientWrapper, "SqT1u70I/V/FKOxKlon495+vMEw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c = ContactDetailPageClientWrapper;
var _c;
__turbopack_context__.k.register(_c, "ContactDetailPageClientWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=222ae291-ec6b-fbad-4556-192298e5e396
//# sourceMappingURL=_de984734._.js.map