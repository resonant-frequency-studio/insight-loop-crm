;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="e31ad9fa-3368-d0e2-534a-848e55500893")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@tanstack/query-devtools/build/DevtoolsComponent/7HGFFDPC.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@tanstack_query-devtools_build_c0c20d5f._.js",
  "static/chunks/node_modules_@tanstack_query-devtools_build_DevtoolsComponent_7HGFFDPC_bfc93cf9.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@tanstack/query-devtools/build/DevtoolsComponent/7HGFFDPC.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/@tanstack/query-devtools/build/DevtoolsPanelComponent/ONXD5SSW.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@tanstack_query-devtools_build_bb366ef2._.js",
  "static/chunks/d4b1c_modules_@tanstack_query-devtools_build_DevtoolsPanelComponent_ONXD5SSW_bfc93cf9.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@tanstack/query-devtools/build/DevtoolsPanelComponent/ONXD5SSW.js [app-client] (ecmascript)");
    });
});
}),
]);

//# debugId=e31ad9fa-3368-d0e2-534a-848e55500893