(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_ae37e258._.js",
  "static/chunks/node_modules_@tanstack_c3a0887b._.js"
],
    source: "dynamic"
});
