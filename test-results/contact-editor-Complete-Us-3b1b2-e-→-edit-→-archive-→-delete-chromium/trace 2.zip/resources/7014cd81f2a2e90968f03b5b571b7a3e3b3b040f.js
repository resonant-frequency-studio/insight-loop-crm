;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="bb2253e9-db81-86a6-8fcd-e4e744dd3c2c")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/(crm)/_components/ExportContactsButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ExportContactsButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$papaparse$2f$papaparse$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/papaparse/papaparse.min.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
"use client";
;
;
;
function ExportContactsButton({ contacts, disabled = false }) {
    const exportToCSV = ()=>{
        if (contacts.length === 0) {
            alert("No contacts to export");
            return;
        }
        // Map contacts to CSV format matching the import format
        const csvData = contacts.map((contact)=>{
            // Format tags array as comma-separated string
            const tagsString = contact.tags && contact.tags.length > 0 ? contact.tags.join(", ") : "";
            // Format dates if they exist
            const formatDate = (date)=>{
                if (!date) return "";
                if (date instanceof Date) {
                    return date.toISOString().split("T")[0];
                }
                if (typeof date === "object" && "toDate" in date) {
                    // Firestore Timestamp
                    return date.toDate().toISOString().split("T")[0];
                }
                if (typeof date === "string") {
                    return date.split("T")[0];
                }
                return "";
            };
            return {
                Email: contact.primaryEmail || "",
                FirstName: contact.firstName || "",
                LastName: contact.lastName || "",
                Summary: contact.summary || "",
                Notes: contact.notes || "",
                Tags: tagsString,
                Segment: contact.segment || "",
                LeadSource: contact.leadSource || "",
                EngagementScore: contact.engagementScore?.toString() || "",
                NextTouchpointDate: formatDate(contact.nextTouchpointDate),
                NextTouchpointMessage: contact.nextTouchpointMessage || ""
            };
        });
        // Convert to CSV
        const csv = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$papaparse$2f$papaparse$2e$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].unparse(csvData, {
            header: true,
            skipEmptyLines: false
        });
        // Create blob and download
        const blob = new Blob([
            csv
        ], {
            type: "text/csv;charset=utf-8;"
        });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", `contacts_export_${new Date().toISOString().split("T")[0]}.csv`);
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
        onClick: exportToCSV,
        disabled: disabled || contacts.length === 0,
        variant: "secondary",
        size: "sm",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: "w-5 h-5",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/ExportContactsButton.tsx",
                lineNumber: 96,
                columnNumber: 11
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/ExportContactsButton.tsx",
            lineNumber: 90,
            columnNumber: 9
        }, void 0),
        className: "w-full sm:w-auto shadow-[rgba(34,32,29,0.1)_0px_2px_4px]",
        children: [
            "Export ",
            contacts.length > 0 ? `(${contacts.length})` : ""
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/ExportContactsButton.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
_c = ExportContactsButton;
var _c;
__turbopack_context__.k.register(_c, "ExportContactsButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Card
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Card({ children, className = "", padding = "md", hover = false }) {
    const paddingClasses = {
        none: "",
        sm: "p-3",
        md: "p-6",
        lg: "p-8",
        xl: "p-12",
        responsive: "p-3 xl:p-6"
    };
    const baseClasses = "bg-card-light rounded-sm shadow-[rgba(34,32,29,0.1)_0px_2px_4px] border border-theme-lighter";
    const paddingClass = padding === "none" || className.includes("p-") ? "" : paddingClasses[padding];
    const hoverClasses = hover ? "hover:shadow-[0px_6px_16px_rgba(0,0,0,0.15)] transition-shadow duration-200" : "";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${baseClasses} ${paddingClass} ${hoverClasses} ${className}`.trim(),
        children: children
    }, void 0, false, {
        fileName: "[project]/components/Card.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
_c = Card;
var _c;
__turbopack_context__.k.register(_c, "Card");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Select.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Select
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function Select({ children, className = "", value, onChange, ...props }) {
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const selectRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const hiddenSelectRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const options = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Children.toArray(children);
    // Get the selected option's display text
    const selectedOption = options.find((opt)=>String(opt.props.value) === String(value));
    const displayValue = selectedOption?.props.children || (value === "" ? "Select..." : String(value));
    // Close dropdown when clicking outside
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Select.useEffect": ()=>{
            const handleClickOutside = {
                "Select.useEffect.handleClickOutside": (event)=>{
                    if (selectRef.current && !selectRef.current.contains(event.target)) {
                        setIsOpen(false);
                    }
                }
            }["Select.useEffect.handleClickOutside"];
            if (isOpen) {
                document.addEventListener("mousedown", handleClickOutside);
                return ({
                    "Select.useEffect": ()=>document.removeEventListener("mousedown", handleClickOutside)
                })["Select.useEffect"];
            }
        }
    }["Select.useEffect"], [
        isOpen
    ]);
    const handleOptionClick = (optionValue)=>{
        if (onChange && hiddenSelectRef.current) {
            // Update the hidden select value
            hiddenSelectRef.current.value = String(optionValue ?? "");
            // Create a synthetic event
            const syntheticEvent = {
                target: hiddenSelectRef.current,
                currentTarget: hiddenSelectRef.current
            };
            onChange(syntheticEvent);
        }
        setIsOpen(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        ref: selectRef,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                ...props,
                ref: hiddenSelectRef,
                value: value,
                onChange: onChange,
                className: "sr-only",
                "aria-hidden": "true",
                tabIndex: -1,
                children: children
            }, void 0, false, {
                fileName: "[project]/components/Select.tsx",
                lineNumber: 56,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: ()=>setIsOpen(!isOpen),
                className: `w-full px-4 py-2 pr-3 border border-theme-darker rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-foreground text-left flex items-center justify-between ${className}`,
                "aria-haspopup": "listbox",
                "aria-expanded": isOpen,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: displayValue
                    }, void 0, false, {
                        fileName: "[project]/components/Select.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: `w-5 h-5 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`,
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M19 9l-7 7-7-7"
                        }, void 0, false, {
                            fileName: "[project]/components/Select.tsx",
                            lineNumber: 83,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/Select.tsx",
                        lineNumber: 77,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/Select.tsx",
                lineNumber: 69,
                columnNumber: 7
            }, this),
            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "fixed inset-0 z-10",
                        onClick: ()=>setIsOpen(false),
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/components/Select.tsx",
                        lineNumber: 95,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute z-20 w-full top-full mt-1 bg-selected-background border border-gray-200 rounded-sm shadow-lg max-h-60 overflow-y-auto",
                        role: "listbox",
                        children: options.map((option, index)=>{
                            const optionValue = option.props.value;
                            const isSelected = String(optionValue) === String(value);
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>handleOptionClick(optionValue),
                                className: `w-full text-left px-4 py-2 text-sm text-foreground rounded-sm hover:bg-selected-active transition-colors ${isSelected ? 'bg-selected-active text-selected-foreground font-bold' : ''}`,
                                role: "option",
                                "aria-selected": isSelected,
                                children: option.props.children
                            }, index, false, {
                                fileName: "[project]/components/Select.tsx",
                                lineNumber: 108,
                                columnNumber: 17
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/components/Select.tsx",
                        lineNumber: 100,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/components/Select.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
_s(Select, "dGDW9clFTE19wQVnSi6GFgyt8Ug=");
_c = Select;
var _c;
__turbopack_context__.k.register(_c, "Select");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
/**
 * Reusable Input component with consistent styling
 * Provides consistent styling across all text input elements in the application
 */ const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = ({ className = "", ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        ref: ref,
        ...props,
        className: `w-full px-4 py-2 border border-theme-darker placeholder:text-foreground rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 ${className}`
    }, void 0, false, {
        fileName: "[project]/components/Input.tsx",
        lineNumber: 10,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Input;
Input.displayName = "Input";
const __TURBOPACK__default__export__ = Input;
var _c, _c1;
__turbopack_context__.k.register(_c, "Input$React.forwardRef");
__turbopack_context__.k.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Checkbox.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Checkbox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Checkbox({ label, labelClassName = "", className = "", ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
        className: `flex items-center gap-3 cursor-pointer ${labelClassName}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "checkbox",
                ...props,
                className: `w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500 ${className}`
            }, void 0, false, {
                fileName: "[project]/components/Checkbox.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm text-theme-darker select-none",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/Checkbox.tsx",
                lineNumber: 24,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/Checkbox.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_c = Checkbox;
var _c;
__turbopack_context__.k.register(_c, "Checkbox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useFilterContacts.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useFilterContacts",
    ()=>useFilterContacts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
function useFilterContacts(contacts, initialUpcomingTouchpoints = false) {
    _s();
    // Filter states (immediate updates for UI responsiveness)
    const [selectedSegment, setSelectedSegment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedTags, setSelectedTags] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [emailSearch, setEmailSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [firstNameSearch, setFirstNameSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [lastNameSearch, setLastNameSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [companySearch, setCompanySearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [upcomingTouchpoints, setUpcomingTouchpoints] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialUpcomingTouchpoints);
    const [showArchived, setShowArchived] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [customFilter, setCustomFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Debounced search values (for filtering performance)
    const [debouncedEmailSearch, setDebouncedEmailSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [debouncedFirstNameSearch, setDebouncedFirstNameSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [debouncedLastNameSearch, setDebouncedLastNameSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [debouncedCompanySearch, setDebouncedCompanySearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // Debounce search inputs (300ms delay)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useFilterContacts.useEffect": ()=>{
            const timer = setTimeout({
                "useFilterContacts.useEffect.timer": ()=>{
                    setDebouncedEmailSearch(emailSearch);
                }
            }["useFilterContacts.useEffect.timer"], 300);
            return ({
                "useFilterContacts.useEffect": ()=>clearTimeout(timer)
            })["useFilterContacts.useEffect"];
        }
    }["useFilterContacts.useEffect"], [
        emailSearch
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useFilterContacts.useEffect": ()=>{
            const timer = setTimeout({
                "useFilterContacts.useEffect.timer": ()=>{
                    setDebouncedFirstNameSearch(firstNameSearch);
                }
            }["useFilterContacts.useEffect.timer"], 300);
            return ({
                "useFilterContacts.useEffect": ()=>clearTimeout(timer)
            })["useFilterContacts.useEffect"];
        }
    }["useFilterContacts.useEffect"], [
        firstNameSearch
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useFilterContacts.useEffect": ()=>{
            const timer = setTimeout({
                "useFilterContacts.useEffect.timer": ()=>{
                    setDebouncedLastNameSearch(lastNameSearch);
                }
            }["useFilterContacts.useEffect.timer"], 300);
            return ({
                "useFilterContacts.useEffect": ()=>clearTimeout(timer)
            })["useFilterContacts.useEffect"];
        }
    }["useFilterContacts.useEffect"], [
        lastNameSearch
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useFilterContacts.useEffect": ()=>{
            const timer = setTimeout({
                "useFilterContacts.useEffect.timer": ()=>{
                    setDebouncedCompanySearch(companySearch);
                }
            }["useFilterContacts.useEffect.timer"], 300);
            return ({
                "useFilterContacts.useEffect": ()=>clearTimeout(timer)
            })["useFilterContacts.useEffect"];
        }
    }["useFilterContacts.useEffect"], [
        companySearch
    ]);
    const filters = {
        selectedSegment,
        selectedTags,
        emailSearch: debouncedEmailSearch,
        firstNameSearch: debouncedFirstNameSearch,
        lastNameSearch: debouncedLastNameSearch,
        companySearch: debouncedCompanySearch,
        upcomingTouchpoints,
        showArchived,
        customFilter
    };
    const filteredContacts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useFilterContacts.useMemo[filteredContacts]": ()=>{
            let filtered = [
                ...contacts
            ];
            // Filter by archived status (default: hide archived, unless showArchived is true)
            if (!filters.showArchived) {
                filtered = filtered.filter({
                    "useFilterContacts.useMemo[filteredContacts]": (c)=>!c.archived
                }["useFilterContacts.useMemo[filteredContacts]"]);
            } else {
                // If showing archived, only show archived contacts
                filtered = filtered.filter({
                    "useFilterContacts.useMemo[filteredContacts]": (c)=>c.archived === true
                }["useFilterContacts.useMemo[filteredContacts]"]);
            }
            // Filter by segment
            if (filters.selectedSegment) {
                filtered = filtered.filter({
                    "useFilterContacts.useMemo[filteredContacts]": (c)=>c.segment === filters.selectedSegment
                }["useFilterContacts.useMemo[filteredContacts]"]);
            }
            // Filter by tags
            if (filters.selectedTags.length > 0) {
                filtered = filtered.filter({
                    "useFilterContacts.useMemo[filteredContacts]": (c)=>c.tags && filters.selectedTags.some({
                            "useFilterContacts.useMemo[filteredContacts]": (tag)=>c.tags.includes(tag)
                        }["useFilterContacts.useMemo[filteredContacts]"])
                }["useFilterContacts.useMemo[filteredContacts]"]);
            }
            // Search by email
            if (filters.emailSearch.trim()) {
                const searchLower = filters.emailSearch.toLowerCase().trim();
                filtered = filtered.filter({
                    "useFilterContacts.useMemo[filteredContacts]": (c)=>c.primaryEmail?.toLowerCase().includes(searchLower)
                }["useFilterContacts.useMemo[filteredContacts]"]);
            }
            // Search by first name
            if (filters.firstNameSearch.trim()) {
                const searchLower = filters.firstNameSearch.toLowerCase().trim();
                filtered = filtered.filter({
                    "useFilterContacts.useMemo[filteredContacts]": (c)=>c.firstName?.toLowerCase().includes(searchLower)
                }["useFilterContacts.useMemo[filteredContacts]"]);
            }
            // Search by last name
            if (filters.lastNameSearch.trim()) {
                const searchLower = filters.lastNameSearch.toLowerCase().trim();
                filtered = filtered.filter({
                    "useFilterContacts.useMemo[filteredContacts]": (c)=>c.lastName?.toLowerCase().includes(searchLower)
                }["useFilterContacts.useMemo[filteredContacts]"]);
            }
            // Search by company
            if (filters.companySearch.trim()) {
                const searchLower = filters.companySearch.toLowerCase().trim();
                filtered = filtered.filter({
                    "useFilterContacts.useMemo[filteredContacts]": (c)=>c.company?.toLowerCase().includes(searchLower)
                }["useFilterContacts.useMemo[filteredContacts]"]);
            }
            // Filter by upcoming touchpoints
            if (filters.upcomingTouchpoints) {
                const now = new Date();
                filtered = filtered.filter({
                    "useFilterContacts.useMemo[filteredContacts]": (contact)=>{
                        if (!contact.nextTouchpointDate) return false;
                        // Handle Firestore Timestamp or Date string
                        const touchpointDate = contact.nextTouchpointDate instanceof Date ? contact.nextTouchpointDate : typeof contact.nextTouchpointDate === "string" ? new Date(contact.nextTouchpointDate) : typeof contact.nextTouchpointDate === "object" && "toDate" in contact.nextTouchpointDate ? contact.nextTouchpointDate.toDate() : null;
                        return touchpointDate && touchpointDate > now;
                    }
                }["useFilterContacts.useMemo[filteredContacts]"]);
            }
            // Custom filters from AI Insights
            if (filters.customFilter === "at-risk") {
                const now = new Date();
                filtered = filtered.filter({
                    "useFilterContacts.useMemo[filteredContacts]": (contact)=>{
                        if (!contact.lastEmailDate) return true; // No email history is at-risk
                        // Handle Firestore Timestamp or Date string
                        const lastEmailDate = contact.lastEmailDate instanceof Date ? contact.lastEmailDate : typeof contact.lastEmailDate === "string" ? new Date(contact.lastEmailDate) : typeof contact.lastEmailDate === "object" && "toDate" in contact.lastEmailDate ? contact.lastEmailDate.toDate() : null;
                        if (!lastEmailDate) return true;
                        const daysSinceReply = (now.getTime() - lastEmailDate.getTime()) / (1000 * 60 * 60 * 24);
                        return daysSinceReply >= 14;
                    }
                }["useFilterContacts.useMemo[filteredContacts]"]);
            } else if (filters.customFilter === "warm") {
                filtered = filtered.filter({
                    "useFilterContacts.useMemo[filteredContacts]": (contact)=>{
                        const score = contact.engagementScore || 0;
                        return score >= 50 && score < 70; // Medium-high engagement
                    }
                }["useFilterContacts.useMemo[filteredContacts]"]);
            }
            return filtered;
        }
    }["useFilterContacts.useMemo[filteredContacts]"], [
        contacts,
        filters.selectedSegment,
        filters.selectedTags,
        filters.emailSearch,
        filters.firstNameSearch,
        filters.lastNameSearch,
        filters.companySearch,
        filters.upcomingTouchpoints,
        filters.showArchived,
        filters.customFilter
    ]);
    const clearFilters = ()=>{
        setSelectedSegment("");
        setSelectedTags([]);
        setEmailSearch("");
        setFirstNameSearch("");
        setLastNameSearch("");
        setCompanySearch("");
        setUpcomingTouchpoints(false);
        setShowArchived(false);
        setCustomFilter(null);
    };
    const hasActiveFilters = !!selectedSegment || selectedTags.length > 0 || !!emailSearch.trim() || !!firstNameSearch.trim() || !!lastNameSearch.trim() || !!companySearch.trim() || upcomingTouchpoints || showArchived || !!customFilter;
    return {
        filteredContacts,
        filters,
        selectedSegment,
        selectedTags,
        emailSearch,
        firstNameSearch,
        lastNameSearch,
        companySearch,
        upcomingTouchpoints,
        showArchived,
        customFilter,
        setSelectedSegment,
        setSelectedTags,
        setEmailSearch,
        setFirstNameSearch,
        setLastNameSearch,
        setCompanySearch,
        setUpcomingTouchpoints,
        setShowArchived,
        setCustomFilter,
        onSegmentChange: setSelectedSegment,
        onTagsChange: setSelectedTags,
        onEmailSearchChange: setEmailSearch,
        onFirstNameSearchChange: setFirstNameSearch,
        onLastNameSearchChange: setLastNameSearch,
        onCompanySearchChange: setCompanySearch,
        onClearFilters: clearFilters,
        hasActiveFilters
    };
}
_s(useFilterContacts, "XkyqPenNdB7v58tTIvJf/YtEfAE=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useContactsPageFilters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useContactsPageFilters",
    ()=>useContactsPageFilters
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useFilterContacts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useFilterContacts.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
const DEFAULT_ITEMS_PER_PAGE = 20;
function useContactsPageFilters({ contacts, itemsPerPage = DEFAULT_ITEMS_PER_PAGE }) {
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const urlParamsInitializedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    // Selection state
    const [selectedContactIds, setSelectedContactIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    // Use filtering hook
    const filterContacts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useFilterContacts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterContacts"])(contacts);
    const { filteredContacts, hasActiveFilters, onClearFilters, showArchived, setShowArchived, setSelectedSegment, setSelectedTags, setCustomFilter, selectedSegment, selectedTags, emailSearch, firstNameSearch, lastNameSearch, companySearch, customFilter } = filterContacts;
    // Initialize filters from URL search params on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useContactsPageFilters.useEffect": ()=>{
            if (urlParamsInitializedRef.current) return; // Only initialize once
            const segment = searchParams.get("segment");
            const tags = searchParams.get("tags");
            const filter = searchParams.get("filter");
            if (segment) {
                setSelectedSegment(decodeURIComponent(segment));
            }
            if (tags) {
                const tagArray = decodeURIComponent(tags).split(",").filter(Boolean);
                if (tagArray.length > 0) {
                    setSelectedTags(tagArray);
                }
            }
            // Handle custom filter types from AI Insights
            if (filter === "at-risk" || filter === "warm") {
                setCustomFilter(filter);
            }
            urlParamsInitializedRef.current = true;
        }
    }["useContactsPageFilters.useEffect"], [
        searchParams,
        setSelectedSegment,
        setSelectedTags,
        setCustomFilter
    ]);
    // Reset to page 1 when filters change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useContactsPageFilters.useEffect": ()=>{
            // Use setTimeout to defer the state update and avoid synchronous setState in effect
            setTimeout({
                "useContactsPageFilters.useEffect": ()=>{
                    setCurrentPage(1);
                }
            }["useContactsPageFilters.useEffect"], 0);
        }
    }["useContactsPageFilters.useEffect"], [
        selectedSegment,
        selectedTags,
        emailSearch,
        firstNameSearch,
        lastNameSearch,
        companySearch,
        customFilter,
        showArchived
    ]);
    // Paginate filtered contacts
    const totalPages = Math.ceil(filteredContacts.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedContacts = filteredContacts.slice(startIndex, endIndex);
    // Check if all filtered contacts are selected
    const allFilteredSelected = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useContactsPageFilters.useMemo[allFilteredSelected]": ()=>{
            if (filteredContacts.length === 0) return false;
            return filteredContacts.every({
                "useContactsPageFilters.useMemo[allFilteredSelected]": (contact)=>selectedContactIds.has(contact.id)
            }["useContactsPageFilters.useMemo[allFilteredSelected]"]);
        }
    }["useContactsPageFilters.useMemo[allFilteredSelected]"], [
        filteredContacts,
        selectedContactIds
    ]);
    // Clear selection when filters change
    const prevFiltersRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        selectedSegment,
        selectedTags,
        emailSearch,
        firstNameSearch,
        lastNameSearch,
        companySearch
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useContactsPageFilters.useEffect": ()=>{
            const currentFilters = {
                selectedSegment,
                selectedTags,
                emailSearch,
                firstNameSearch,
                lastNameSearch,
                companySearch
            };
            const filtersChanged = prevFiltersRef.current.selectedSegment !== currentFilters.selectedSegment || JSON.stringify(prevFiltersRef.current.selectedTags) !== JSON.stringify(currentFilters.selectedTags) || prevFiltersRef.current.emailSearch !== currentFilters.emailSearch || prevFiltersRef.current.firstNameSearch !== currentFilters.firstNameSearch || prevFiltersRef.current.lastNameSearch !== currentFilters.lastNameSearch || prevFiltersRef.current.companySearch !== currentFilters.companySearch;
            if (filtersChanged) {
                prevFiltersRef.current = currentFilters;
                // Use setTimeout to defer the state update and avoid synchronous setState in effect
                setTimeout({
                    "useContactsPageFilters.useEffect": ()=>{
                        setSelectedContactIds(new Set());
                    }
                }["useContactsPageFilters.useEffect"], 0);
            }
        }
    }["useContactsPageFilters.useEffect"], [
        selectedSegment,
        selectedTags,
        emailSearch,
        firstNameSearch,
        lastNameSearch,
        companySearch
    ]);
    const toggleContactSelection = (contactId)=>{
        setSelectedContactIds((prev)=>{
            const newSet = new Set(prev);
            if (newSet.has(contactId)) {
                newSet.delete(contactId);
            } else {
                newSet.add(contactId);
            }
            return newSet;
        });
    };
    const toggleSelectAll = ()=>{
        if (allFilteredSelected) {
            setSelectedContactIds(new Set());
        } else {
            setSelectedContactIds(new Set(filteredContacts.map((c)=>c.id)));
        }
    };
    return {
        // Filter state
        filteredContacts,
        hasActiveFilters,
        showArchived,
        setShowArchived,
        setSelectedSegment,
        setSelectedTags,
        setEmailSearch: filterContacts.setEmailSearch,
        setFirstNameSearch: filterContacts.setFirstNameSearch,
        setLastNameSearch: filterContacts.setLastNameSearch,
        setCompanySearch: filterContacts.setCompanySearch,
        setCustomFilter,
        onClearFilters,
        // Filter change handlers (for ContactsFilter component)
        onSegmentChange: setSelectedSegment,
        onTagsChange: setSelectedTags,
        onEmailSearchChange: filterContacts.setEmailSearch,
        onFirstNameSearchChange: filterContacts.setFirstNameSearch,
        onLastNameSearchChange: filterContacts.setLastNameSearch,
        onCompanySearchChange: filterContacts.setCompanySearch,
        onShowArchivedChange: setShowArchived,
        onCustomFilterChange: setCustomFilter,
        // Pagination
        currentPage,
        setCurrentPage,
        totalPages,
        paginatedContacts,
        startIndex,
        endIndex,
        // Selection management
        selectedContactIds,
        setSelectedContactIds,
        allFilteredSelected,
        toggleContactSelection,
        toggleSelectAll,
        // Filter values
        selectedSegment,
        selectedTags,
        emailSearch,
        firstNameSearch,
        lastNameSearch,
        companySearch,
        customFilter
    };
}
_s(useContactsPageFilters, "X+lLjIVaxZBYlzGzv6AFtml4uGA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useFilterContacts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterContacts"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/contacts/_components/ContactsFilterContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContactsFilterProvider",
    ()=>ContactsFilterProvider,
    "useContactsFilter",
    ()=>useContactsFilter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactsPageFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactsPageFilters.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
const ContactsFilterContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function ContactsFilterProvider({ children, contacts, itemsPerPage = 20, isLoading = false }) {
    _s();
    const filterState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactsPageFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactsPageFilters"])({
        contacts,
        itemsPerPage
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContactsFilterContext.Provider, {
        value: {
            ...filterState,
            totalContactsCount: contacts.length,
            isLoading
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/app/(crm)/contacts/_components/ContactsFilterContext.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
_s(ContactsFilterProvider, "tdwAipr1HEX+kVA3ylotBue1XFE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactsPageFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactsPageFilters"]
    ];
});
_c = ContactsFilterProvider;
function useContactsFilter() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ContactsFilterContext);
    if (context === undefined) {
        throw new Error("useContactsFilter must be used within a ContactsFilterProvider");
    }
    return context;
}
_s1(useContactsFilter, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "ContactsFilterProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ContactsFilter.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactsFilter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Checkbox.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/contacts/_components/ContactsFilterContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function ContactsFilter({ contacts }) {
    _s();
    const { selectedSegment, selectedTags, emailSearch, firstNameSearch, lastNameSearch, companySearch, showArchived, customFilter, onSegmentChange, onTagsChange, onEmailSearchChange, onFirstNameSearchChange, onLastNameSearchChange, onCompanySearchChange, onShowArchivedChange, onCustomFilterChange, onClearFilters } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactsFilter"])();
    const [tagSearch, setTagSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [showTagDropdown, setShowTagDropdown] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Get unique segments and tags from contacts
    const uniqueSegments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ContactsFilter.useMemo[uniqueSegments]": ()=>Array.from(new Set(contacts.map({
                "ContactsFilter.useMemo[uniqueSegments]": (c)=>c.segment
            }["ContactsFilter.useMemo[uniqueSegments]"]).filter(Boolean))).sort()
    }["ContactsFilter.useMemo[uniqueSegments]"], [
        contacts
    ]);
    const uniqueTags = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ContactsFilter.useMemo[uniqueTags]": ()=>{
            const allTags = contacts.flatMap({
                "ContactsFilter.useMemo[uniqueTags].allTags": (c)=>c.tags || []
            }["ContactsFilter.useMemo[uniqueTags].allTags"]);
            return Array.from(new Set(allTags)).sort();
        }
    }["ContactsFilter.useMemo[uniqueTags]"], [
        contacts
    ]);
    const toggleTag = (tag)=>{
        if (selectedTags.includes(tag)) {
            onTagsChange(selectedTags.filter((t)=>t !== tag));
        } else {
            onTagsChange([
                ...selectedTags,
                tag
            ]);
        }
    };
    const hasActiveFilters = selectedSegment || selectedTags.length > 0 || emailSearch.trim() || firstNameSearch.trim() || lastNameSearch.trim() || companySearch.trim() || !!customFilter;
    // Hide filter component when no contacts
    if (contacts.length === 0) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-lg font-semibold text-theme-darkest",
                        children: "Filters & Search"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                        lineNumber: 71,
                        columnNumber: 9
                    }, this),
                    hasActiveFilters && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: onClearFilters,
                        variant: "link",
                        size: "sm",
                        className: "text-sm",
                        children: "Clear all filters"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                        lineNumber: 73,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                lineNumber: 70,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "email-search",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Search by Email"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 88,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "email-search",
                                type: "text",
                                value: emailSearch,
                                onChange: (e)=>onEmailSearchChange(e.target.value),
                                placeholder: "Enter email address..."
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 91,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                        lineNumber: 87,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "last-name-search",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Search by Last Name"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 102,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "last-name-search",
                                type: "text",
                                value: lastNameSearch,
                                onChange: (e)=>onLastNameSearchChange(e.target.value),
                                placeholder: "Enter last name..."
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 105,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                        lineNumber: 101,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "first-name-search",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Search by First Name"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 116,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "first-name-search",
                                type: "text",
                                value: firstNameSearch,
                                onChange: (e)=>onFirstNameSearchChange(e.target.value),
                                placeholder: "Enter first name..."
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 119,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                        lineNumber: 115,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "company-search",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Search by Company"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 130,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "company-search",
                                type: "text",
                                value: companySearch,
                                onChange: (e)=>onCompanySearchChange(e.target.value),
                                placeholder: "Enter company name..."
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 133,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                        lineNumber: 129,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 md:grid-cols-3 gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "segment-filter",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Filter by Segment"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 147,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "segment-filter",
                                value: selectedSegment,
                                onChange: (e)=>onSegmentChange(e.target.value),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: "All Segments"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                        lineNumber: 155,
                                        columnNumber: 13
                                    }, this),
                                    uniqueSegments.map((segment)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: segment,
                                            children: segment
                                        }, segment, false, {
                                            fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                            lineNumber: 157,
                                            columnNumber: 15
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 150,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                        lineNumber: 146,
                        columnNumber: 9
                    }, this),
                    onCustomFilterChange && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "quick-filters",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Quick Filters"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 165,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "quick-filters",
                                value: customFilter || "",
                                onChange: (e)=>{
                                    const value = e.target.value;
                                    onCustomFilterChange(value === "" ? null : value);
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: "None"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                        lineNumber: 176,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "at-risk",
                                        children: "At-Risk (14+ days no reply)"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                        lineNumber: 177,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "warm",
                                        children: "Warm Leads (50-70 engagement)"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                        lineNumber: 178,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                lineNumber: 168,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                        lineNumber: 164,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: customFilter !== undefined ? "md:col-span-1" : "md:col-span-2",
                        children: uniqueTags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    htmlFor: "tag-search",
                                    className: "block text-sm font-medium text-theme-darker mb-2",
                                    children: "Filter by Tags"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                    lineNumber: 188,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            id: "tag-search",
                                            type: "text",
                                            value: tagSearch,
                                            onChange: (e)=>{
                                                setTagSearch(e.target.value);
                                                setShowTagDropdown(true);
                                            },
                                            onFocus: ()=>setShowTagDropdown(true),
                                            placeholder: "Search and select tags...",
                                            "aria-expanded": showTagDropdown,
                                            "aria-haspopup": "listbox"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                            lineNumber: 194,
                                            columnNumber: 17
                                        }, this),
                                        showTagDropdown && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "fixed inset-0 z-10",
                                                    onClick: ()=>setShowTagDropdown(false),
                                                    "aria-hidden": "true"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                                    lineNumber: 211,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute z-20 w-full top-full mt-1 bg-card-highlight-light border border-gray-200 rounded-sm shadow-lg max-h-60 overflow-y-auto",
                                                    role: "listbox",
                                                    children: [
                                                        uniqueTags.filter((tag)=>!selectedTags.includes(tag) && tag.toLowerCase().includes(tagSearch.toLowerCase())).slice(0, 20).map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                onClick: ()=>{
                                                                    toggleTag(tag);
                                                                    setTagSearch("");
                                                                },
                                                                variant: "outline",
                                                                size: "sm",
                                                                className: "w-full text-left px-4 py-2 hover:bg-theme-darker hover:text-theme-lightest text-sm text-theme-darker justify-start",
                                                                role: "option",
                                                                "aria-selected": "false",
                                                                children: tag
                                                            }, tag, false, {
                                                                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                                                lineNumber: 227,
                                                                columnNumber: 27
                                                            }, this)),
                                                        uniqueTags.filter((tag)=>!selectedTags.includes(tag) && tag.toLowerCase().includes(tagSearch.toLowerCase())).length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "px-4 py-2 text-sm text-gray-500",
                                                            children: "No tags found"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                                            lineNumber: 246,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                                    lineNumber: 216,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                    lineNumber: 193,
                                    columnNumber: 15
                                }, this),
                                selectedTags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-wrap gap-2 mt-3",
                                    children: selectedTags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-100 text-blue-700 rounded-sm text-sm font-medium",
                                            children: [
                                                tag,
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                    onClick: ()=>toggleTag(tag),
                                                    variant: "link",
                                                    size: "sm",
                                                    className: "p-0 w-auto h-auto hover:text-blue-900",
                                                    "aria-label": `Remove ${tag} tag`,
                                                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-3.5 h-3.5",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        "aria-hidden": "true",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: 2,
                                                            d: "M6 18L18 6M6 6l12 12"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                                            lineNumber: 272,
                                                            columnNumber: 29
                                                        }, void 0)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                                        lineNumber: 271,
                                                        columnNumber: 27
                                                    }, void 0),
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "sr-only",
                                                        children: [
                                                            "Remove ",
                                                            tag
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                                        lineNumber: 276,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                                    lineNumber: 264,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, tag, true, {
                                            fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                            lineNumber: 259,
                                            columnNumber: 21
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                    lineNumber: 257,
                                    columnNumber: 17
                                }, this),
                                selectedTags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-2 text-xs text-gray-500",
                                    children: [
                                        selectedTags.length,
                                        " ",
                                        selectedTags.length === 1 ? "tag" : "tags",
                                        " selected"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                                    lineNumber: 284,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                            lineNumber: 187,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                        lineNumber: 184,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                lineNumber: 144,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    checked: showArchived,
                    onChange: (e)=>onShowArchivedChange(e.target.checked),
                    label: showArchived ? "Showing archived contacts" : "Show archived contacts"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                    lineNumber: 295,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
                lineNumber: 294,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/ContactsFilter.tsx",
        lineNumber: 69,
        columnNumber: 5
    }, this);
}
_s(ContactsFilter, "9ICjvWS+wrJ6Y+Fk5zOUVkwCwVg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactsFilter"]
    ];
});
_c = ContactsFilter;
var _c;
__turbopack_context__.k.register(_c, "ContactsFilter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/ui-mode.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * UI Mode Configuration
 * 
 * Reads NEXT_PUBLIC_UI_MODE environment variable to control app-wide UI state
 * for visual regression testing.
 * 
 * Modes:
 * - "suspense": Force all pages to show loading/suspense states
 * - "empty": Force all pages to show empty states (no contacts)
 * - "normal": Use real data (default)
 * 
 * If the variable is missing, commented out, or empty, defaults to "normal"
 */ __turbopack_context__.s([
    "getUIMode",
    ()=>getUIMode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
function getUIMode() {
    const envValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_UI_MODE;
    // If undefined, empty string, or whitespace-only, default to "normal"
    if (!envValue || envValue.trim() === "") {
        return "normal";
    }
    const normalizedValue = envValue.trim().toLowerCase();
    // Validate and return the mode
    if (normalizedValue === "suspense" || normalizedValue === "empty" || normalizedValue === "normal") {
        return normalizedValue;
    }
    // Invalid value - warn and default to "normal"
    if ("TURBOPACK compile-time truthy", 1) {
        console.warn(`Invalid NEXT_PUBLIC_UI_MODE value: "${envValue}". ` + `Valid values are: "suspense", "empty", "normal". Defaulting to "normal".`);
    }
    return "normal";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useContacts.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useContacts",
    ()=>useContacts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ui$2d$mode$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ui-mode.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function useContacts(userId, initialData) {
    _s();
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "contacts",
            userId
        ],
        queryFn: {
            "useContacts.useQuery[query]": async ()=>{
                // Force no-store to ensure fresh data from API (which also uses no-store)
                const response = await fetch("/api/contacts", {
                    cache: "no-store"
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useContacts.useQuery[query]": ()=>({})
                    }["useContacts.useQuery[query]"]);
                    throw new Error(errorData.error || "Failed to fetch contacts");
                }
                const data = await response.json();
                return data.contacts;
            }
        }["useContacts.useQuery[query]"],
        enabled: !!userId,
        staleTime: 0,
        refetchOnMount: true,
        refetchOnWindowFocus: true,
        // ONLY use initialData for SSR - do NOT use placeholderData
        // placeholderData was preventing React Query from recognizing fresh data
        initialData
    });
    const uiMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ui$2d$mode$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUIMode"])();
    // Override query result based on UI mode
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useContacts.useMemo": ()=>{
            if (uiMode === "suspense") {
                return {
                    ...query,
                    data: undefined,
                    isLoading: true
                };
            }
            if (uiMode === "empty") {
                return {
                    ...query,
                    data: [],
                    isLoading: false
                };
            }
            return query;
        }
    }["useContacts.useMemo"], [
        query,
        uiMode
    ]);
}
_s(useContacts, "omorBNG7LLjf0qbKIPbzemu3vGA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/util/contact-utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatContactDate",
    ()=>formatContactDate,
    "getDisplayName",
    ()=>getDisplayName,
    "getInitials",
    ()=>getInitials
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [app-client] (ecmascript)");
;
function getInitials(contact) {
    if (contact.firstName && contact.lastName) {
        return `${contact.firstName[0]}${contact.lastName[0]}`.toUpperCase();
    }
    if (contact.firstName) {
        return contact.firstName[0].toUpperCase();
    }
    if (contact.primaryEmail) {
        return contact.primaryEmail[0].toUpperCase();
    }
    return "?";
}
function getDisplayName(contact) {
    if (contact.firstName || contact.lastName) {
        return `${contact.firstName || ""} ${contact.lastName || ""}`.trim();
    }
    if (contact.company) {
        return contact.company;
    }
    return contact.primaryEmail;
}
function formatContactDate(date, options) {
    if (!date) return "N/A";
    let dateObj = null;
    // Handle ISO date strings (from API - timestamps converted to ISO strings)
    if (typeof date === "string") {
        dateObj = new Date(date);
        if (isNaN(dateObj.getTime())) {
            return "N/A";
        }
    } else if (date instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"] || typeof date === "object" && date !== null && "toDate" in date) {
        dateObj = date.toDate();
    } else if (typeof date === "object" && date !== null && "seconds" in date && "nanoseconds" in date) {
        const timestamp = date;
        dateObj = new Date(timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000);
    } else if (typeof date === "object" && date !== null && "_seconds" in date && "_nanoseconds" in date) {
        const timestamp = date;
        dateObj = new Date(timestamp._seconds * 1000 + timestamp._nanoseconds / 1000000);
    } else if (date instanceof Date) {
        dateObj = date;
    } else if (typeof date === "number") {
        dateObj = new Date(date);
        if (isNaN(dateObj.getTime())) {
            return "N/A";
        }
    }
    if (!dateObj) return "N/A";
    // Relative time option (handles both past and future dates)
    if (options?.relative) {
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const dateToCompare = new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate());
        // Calculate difference in calendar days (positive = past, negative = future)
        const diffMs = today.getTime() - dateToCompare.getTime();
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        // Handle future dates (negative diffDays)
        if (diffDays < 0) {
            const absDays = Math.abs(diffDays);
            if (absDays === 0) {
                return "Today";
            } else if (absDays === 1) {
                return "Tomorrow";
            } else if (absDays < 7) {
                return `in ${absDays} days`;
            } else if (absDays < 30) {
                const weeks = Math.floor(absDays / 7);
                return `in ${weeks} ${weeks === 1 ? "week" : "weeks"}`;
            } else if (absDays < 365) {
                const months = Math.floor(absDays / 30);
                return `in ${months} ${months === 1 ? "month" : "months"}`;
            } else {
                const years = Math.floor(absDays / 365);
                return `in ${years} ${years === 1 ? "year" : "years"}`;
            }
        }
        // Handle past dates (positive diffDays)
        if (diffDays === 0) {
            return "Today";
        } else if (diffDays === 1) {
            return "Yesterday";
        } else if (diffDays < 7) {
            return `${diffDays} days ago`;
        } else if (diffDays < 30) {
            const weeks = Math.floor(diffDays / 7);
            return `${weeks} ${weeks === 1 ? "week" : "weeks"} ago`;
        } else if (diffDays < 365) {
            const months = Math.floor(diffDays / 30);
            return `${months} ${months === 1 ? "month" : "months"} ago`;
        } else {
            const years = Math.floor(diffDays / 365);
            return `${years} ${years === 1 ? "year" : "years"} ago`;
        }
    }
    // Standard formatting
    if (options?.includeTime) {
        return dateObj.toLocaleString("en-US", {
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: "numeric",
            minute: "2-digit"
        });
    }
    return dateObj.toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric"
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Modal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Modal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function Modal({ isOpen, onClose, children, title, showBackdrop = true, closeOnBackdropClick = true }) {
    _s();
    const modalRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const titleId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const previousActiveElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Get all focusable elements within the modal
    const getFocusableElements = ()=>{
        if (!modalRef.current) return [];
        const focusableSelectors = [
            'a[href]',
            'button:not([disabled])',
            'textarea:not([disabled])',
            'input:not([disabled])',
            'select:not([disabled])',
            '[tabindex]:not([tabindex="-1"])'
        ].join(', ');
        return Array.from(modalRef.current.querySelectorAll(focusableSelectors));
    };
    // Focus trap: keep focus within modal
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (!isOpen || !modalRef.current) return;
            const handleTabKey = {
                "Modal.useEffect.handleTabKey": (e)=>{
                    if (e.key !== 'Tab') return;
                    const focusableElements = getFocusableElements();
                    if (focusableElements.length === 0) return;
                    const firstElement = focusableElements[0];
                    const lastElement = focusableElements[focusableElements.length - 1];
                    if (e.shiftKey) {
                        // Shift + Tab
                        if (document.activeElement === firstElement) {
                            e.preventDefault();
                            lastElement.focus();
                        }
                    } else {
                        // Tab
                        if (document.activeElement === lastElement) {
                            e.preventDefault();
                            firstElement.focus();
                        }
                    }
                }
            }["Modal.useEffect.handleTabKey"];
            document.addEventListener('keydown', handleTabKey);
            return ({
                "Modal.useEffect": ()=>{
                    document.removeEventListener('keydown', handleTabKey);
                }
            })["Modal.useEffect"];
        }
    }["Modal.useEffect"], [
        isOpen
    ]);
    // Handle escape key
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (!isOpen) return;
            const handleEscape = {
                "Modal.useEffect.handleEscape": (e)=>{
                    if (e.key === "Escape") {
                        onClose();
                    }
                }
            }["Modal.useEffect.handleEscape"];
            document.addEventListener("keydown", handleEscape);
            return ({
                "Modal.useEffect": ()=>{
                    document.removeEventListener("keydown", handleEscape);
                }
            })["Modal.useEffect"];
        }
    }["Modal.useEffect"], [
        isOpen,
        onClose
    ]);
    // Focus management: move focus to modal on open, return on close
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (isOpen) {
                // Store the previously focused element
                previousActiveElementRef.current = document.activeElement;
                // Move focus to modal after a brief delay to ensure it's rendered
                // Skip inputs that have data-no-autofocus attribute
                setTimeout({
                    "Modal.useEffect": ()=>{
                        const focusableElements = getFocusableElements().filter({
                            "Modal.useEffect.focusableElements": (el)=>!el.hasAttribute('data-no-autofocus')
                        }["Modal.useEffect.focusableElements"]);
                        if (focusableElements.length > 0) {
                            focusableElements[0].focus();
                        } else if (modalRef.current) {
                            modalRef.current.focus();
                        }
                    }
                }["Modal.useEffect"], 0);
            } else {
                // Return focus to the previously focused element
                if (previousActiveElementRef.current) {
                    previousActiveElementRef.current.focus();
                    previousActiveElementRef.current = null;
                }
            }
        }
    }["Modal.useEffect"], [
        isOpen
    ]);
    // Prevent body scroll when modal is open
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (isOpen) {
                document.body.style.overflow = "hidden";
            } else {
                document.body.style.overflow = "";
            }
            return ({
                "Modal.useEffect": ()=>{
                    document.body.style.overflow = "";
                }
            })["Modal.useEffect"];
        }
    }["Modal.useEffect"], [
        isOpen
    ]);
    if (!isOpen) return null;
    const handleBackdropClick = (e)=>{
        if (closeOnBackdropClick && e.target === e.currentTarget) {
            onClose();
        }
    };
    const modalContent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-200 flex items-center justify-center",
        onClick: handleBackdropClick,
        role: "presentation",
        children: [
            showBackdrop && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-black/20",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/components/Modal.tsx",
                lineNumber: 148,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: modalRef,
                role: "dialog",
                "aria-modal": "true",
                "aria-labelledby": title ? titleId : undefined,
                tabIndex: -1,
                className: "relative bg-background rounded-xl shadow-xl p-6 max-w-md w-full mx-4 z-10 border border-theme-light focus:outline-none",
                onClick: (e)=>e.stopPropagation(),
                children: [
                    title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        id: titleId,
                        className: "text-lg font-semibold text-foreground mb-4",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/components/Modal.tsx",
                        lineNumber: 160,
                        columnNumber: 11
                    }, this),
                    children
                ]
            }, void 0, true, {
                fileName: "[project]/components/Modal.tsx",
                lineNumber: 150,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/Modal.tsx",
        lineNumber: 142,
        columnNumber: 5
    }, this);
    // Use portal to render modal at document body level
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(modalContent, document.body);
}
_s(Modal, "Al4JN5XtBcZZvMhrMN2+23NTASM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = Modal;
var _c;
__turbopack_context__.k.register(_c, "Modal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Textarea.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Textarea
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Textarea({ className = "", ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
        ...props,
        className: `w-full px-4 py-3 border text-foreground placeholder:text-foreground border-gray-300 rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 resize-none ${className}`
    }, void 0, false, {
        fileName: "[project]/components/Textarea.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_c = Textarea;
var _c;
__turbopack_context__.k.register(_c, "Textarea");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useContactMutations.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useArchiveContact",
    ()=>useArchiveContact,
    "useBulkArchiveContacts",
    ()=>useBulkArchiveContacts,
    "useBulkUpdateCompanies",
    ()=>useBulkUpdateCompanies,
    "useBulkUpdateSegments",
    ()=>useBulkUpdateSegments,
    "useBulkUpdateTags",
    ()=>useBulkUpdateTags,
    "useCreateContact",
    ()=>useCreateContact,
    "useDeleteContact",
    ()=>useDeleteContact,
    "useUpdateContact",
    ()=>useUpdateContact,
    "useUpdateTouchpointStatus",
    ()=>useUpdateTouchpointStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature();
"use client";
;
;
function useCreateContact() {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useCreateContact.useMutation": async (contactData)=>{
                const response = await fetch("/api/contacts", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(contactData)
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useCreateContact.useMutation": ()=>({})
                    }["useCreateContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to create contact");
                }
                const data = await response.json();
                return data.contactId;
            }
        }["useCreateContact.useMutation"],
        onSuccess: {
            "useCreateContact.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useCreateContact.useMutation"],
        onError: {
            "useCreateContact.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Creating contact",
                    tags: {
                        component: "useCreateContact"
                    }
                });
            }
        }["useCreateContact.useMutation"]
    });
}
_s(useCreateContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useUpdateContact(userId) {
    _s1();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    // Defensive contact matcher - handles contactId, id, or _id fields
    const isSameContact = (c, contactId)=>{
        return c.contactId === contactId || c.id === contactId || c._id === contactId;
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useUpdateContact.useMutation": async ({ contactId, updates })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(updates)
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useUpdateContact.useMutation": ()=>({})
                    }["useUpdateContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to update contact");
                }
                const data = await response.json();
                return data.contact; // API now returns { contact: Contact }
            }
        }["useUpdateContact.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update both detail and ALL list caches so UI feels instant
     */ onMutate: {
            "useUpdateContact.useMutation": async ({ contactId, updates })=>{
                // Cancel all related queries
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact"
                    ],
                    exact: false
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                });
                // Snapshot previous detail state (for this specific user+contact, if such a query exists)
                const prevDetail = userId ? queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]) : undefined;
                // Snapshot ALL contacts lists (regardless of key shape)
                const prevLists = {};
                queryClient.getQueryCache().findAll({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                }).forEach({
                    "useUpdateContact.useMutation": (q)=>{
                        const key = JSON.stringify(q.queryKey);
                        const data = q.state.data;
                        if (data) prevLists[key] = data;
                    }
                }["useUpdateContact.useMutation"]);
                // Optimistically update detail (if userId provided)
                if (userId) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        contactId
                    ], {
                        "useUpdateContact.useMutation": (old)=>old ? {
                                ...old,
                                ...updates
                            } : old
                    }["useUpdateContact.useMutation"]);
                }
                // Optimistically update ALL contacts lists (regardless of key shape)
                queryClient.setQueriesData({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                }, {
                    "useUpdateContact.useMutation": (old)=>{
                        if (!old || !Array.isArray(old)) return old;
                        return old.map({
                            "useUpdateContact.useMutation": (c)=>isSameContact(c, contactId) ? {
                                    ...c,
                                    ...updates
                                } : c
                        }["useUpdateContact.useMutation"]);
                    }
                }["useUpdateContact.useMutation"]);
                return {
                    prevDetail,
                    prevLists
                };
            }
        }["useUpdateContact.useMutation"],
        /**
     * SUCCESS — update detail only & delay list invalidation
     * Firestore eventual consistency means list queries might not see the update immediately
     * So we invalidate after a delay to let Firestore propagate the change
     */ onSuccess: {
            "useUpdateContact.useMutation": (updatedContact, variables)=>{
                const { contactId } = variables;
                // Update detail cache with actual server result
                if (userId) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        contactId
                    ], updatedContact);
                }
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                });
                // Invalidate dashboard stats to ensure consistency
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ],
                    exact: false
                });
            }
        }["useUpdateContact.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useUpdateContact.useMutation": (error, variables, context)=>{
                // Restore detail (if userId provided)
                if (userId && context?.prevDetail) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prevDetail);
                }
                // Restore ALL contacts lists
                if (context?.prevLists) {
                    for (const [key, data] of Object.entries(context.prevLists)){
                        queryClient.setQueryData(JSON.parse(key), data);
                    }
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating contact",
                    tags: {
                        component: "useUpdateContact"
                    }
                });
            }
        }["useUpdateContact.useMutation"]
    });
}
_s1(useUpdateContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useDeleteContact() {
    _s2();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useDeleteContact.useMutation": async (contactId)=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}`, {
                    method: "DELETE"
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useDeleteContact.useMutation": ()=>({})
                    }["useDeleteContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to delete contact");
                }
                return response.json();
            }
        }["useDeleteContact.useMutation"],
        onSuccess: {
            "useDeleteContact.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "action-items"
                    ]
                });
            }
        }["useDeleteContact.useMutation"],
        onError: {
            "useDeleteContact.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Deleting contact",
                    tags: {
                        component: "useDeleteContact"
                    }
                });
            }
        }["useDeleteContact.useMutation"]
    });
}
_s2(useDeleteContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useArchiveContact(userId) {
    _s3();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useArchiveContact.useMutation": async ({ contactId, archived })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}/archive`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        archived
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useArchiveContact.useMutation": ()=>({})
                    }["useArchiveContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to archive contact");
                }
                return response.json();
            }
        }["useArchiveContact.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update the cache so UI feels instant
     */ onMutate: {
            "useArchiveContact.useMutation": async ({ contactId, archived })=>{
                if (!userId) return;
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                // Snapshot previous value for rollback
                const prev = queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]);
                // Update cache immediately - UI updates instantly
                queryClient.setQueryData([
                    "contact",
                    userId,
                    contactId
                ], {
                    "useArchiveContact.useMutation": (old)=>{
                        if (!old) return old;
                        return {
                            ...old,
                            archived
                        };
                    }
                }["useArchiveContact.useMutation"]);
                // Also update in contacts list
                queryClient.setQueryData([
                    "contacts",
                    userId
                ], {
                    "useArchiveContact.useMutation": (old)=>{
                        if (!old) return old;
                        return old.map({
                            "useArchiveContact.useMutation": (c)=>c.contactId === contactId ? {
                                    ...c,
                                    archived
                                } : c
                        }["useArchiveContact.useMutation"]);
                    }
                }["useArchiveContact.useMutation"]);
                return {
                    prev
                };
            }
        }["useArchiveContact.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useArchiveContact.useMutation": (error, variables, context)=>{
                if (userId && context?.prev) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prev);
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Archiving contact",
                    tags: {
                        component: "useArchiveContact"
                    }
                });
            }
        }["useArchiveContact.useMutation"],
        onSettled: {
            "useArchiveContact.useMutation": ()=>{
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useArchiveContact.useMutation"]
    });
}
_s3(useArchiveContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useUpdateTouchpointStatus(userId) {
    _s4();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useUpdateTouchpointStatus.useMutation": async ({ contactId, status, reason })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}/touchpoint-status`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        status,
                        reason
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useUpdateTouchpointStatus.useMutation": ()=>({})
                    }["useUpdateTouchpointStatus.useMutation"]);
                    // Throw user-friendly error message - will be extracted by component
                    const errorMessage = errorData.error || "Failed to update touchpoint status. Please try again.";
                    throw new Error(errorMessage);
                }
                const data = await response.json();
                return {
                    ...data,
                    contactId,
                    status,
                    reason
                };
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update the cache so UI feels instant
     */ onMutate: {
            "useUpdateTouchpointStatus.useMutation": async ({ contactId, status, reason })=>{
                if (!userId) return;
                // Cancel outgoing refetches to avoid overwriting optimistic update
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact",
                        userId,
                        contactId
                    ]
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts",
                        userId
                    ]
                });
                // Snapshot previous value for rollback
                const prev = queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]);
                // Update cache immediately - UI updates instantly
                queryClient.setQueryData([
                    "contact",
                    userId,
                    contactId
                ], {
                    "useUpdateTouchpointStatus.useMutation": (old)=>{
                        if (!old) return old;
                        return {
                            ...old,
                            touchpointStatus: status,
                            touchpointStatusUpdatedAt: status !== null ? new Date().toISOString() : null,
                            touchpointStatusReason: reason !== undefined ? reason : old.touchpointStatusReason
                        };
                    }
                }["useUpdateTouchpointStatus.useMutation"]);
                // Also update in contacts list
                queryClient.setQueryData([
                    "contacts",
                    userId
                ], {
                    "useUpdateTouchpointStatus.useMutation": (old)=>{
                        if (!old) return old;
                        return old.map({
                            "useUpdateTouchpointStatus.useMutation": (contact)=>contact.contactId === contactId ? {
                                    ...contact,
                                    touchpointStatus: status,
                                    touchpointStatusUpdatedAt: status !== null ? new Date().toISOString() : null,
                                    touchpointStatusReason: reason !== undefined ? reason : contact.touchpointStatusReason
                                } : contact
                        }["useUpdateTouchpointStatus.useMutation"]);
                    }
                }["useUpdateTouchpointStatus.useMutation"]);
                return {
                    prev
                };
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useUpdateTouchpointStatus.useMutation": (error, variables, context)=>{
                if (userId && context?.prev) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prev);
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating touchpoint status",
                    tags: {
                        component: "useUpdateTouchpointStatus"
                    }
                });
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * Invalidate after success to ensure server consistency
     */ onSettled: {
            "useUpdateTouchpointStatus.useMutation": (_data, _error, vars)=>{
                if (!userId) return;
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact",
                        userId,
                        vars.contactId
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts",
                        userId
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useUpdateTouchpointStatus.useMutation"]
    });
}
_s4(useUpdateTouchpointStatus, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkArchiveContacts() {
    _s5();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkArchiveContacts.useMutation": async ({ contactIds, archived })=>{
                const response = await fetch("/api/contacts/bulk-archive", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        archived
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkArchiveContacts.useMutation": ()=>({})
                    }["useBulkArchiveContacts.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk archive contacts");
                }
                return response.json();
            }
        }["useBulkArchiveContacts.useMutation"],
        onSuccess: {
            "useBulkArchiveContacts.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkArchiveContacts.useMutation"],
        onError: {
            "useBulkArchiveContacts.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk archiving contacts",
                    tags: {
                        component: "useBulkArchiveContacts"
                    }
                });
            }
        }["useBulkArchiveContacts.useMutation"]
    });
}
_s5(useBulkArchiveContacts, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateSegments() {
    _s6();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateSegments.useMutation": async ({ contactIds, segment })=>{
                const response = await fetch("/api/contacts/bulk-segment", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        segment
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateSegments.useMutation": ()=>({})
                    }["useBulkUpdateSegments.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update segments");
                }
                return response.json();
            }
        }["useBulkUpdateSegments.useMutation"],
        onSuccess: {
            "useBulkUpdateSegments.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateSegments.useMutation"],
        onError: {
            "useBulkUpdateSegments.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact segments",
                    tags: {
                        component: "useBulkUpdateSegments"
                    }
                });
            }
        }["useBulkUpdateSegments.useMutation"]
    });
}
_s6(useBulkUpdateSegments, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateTags() {
    _s7();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateTags.useMutation": async ({ contactIds, tags })=>{
                const response = await fetch("/api/contacts/bulk-tags", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        tags
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateTags.useMutation": ()=>({})
                    }["useBulkUpdateTags.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update tags");
                }
                return response.json();
            }
        }["useBulkUpdateTags.useMutation"],
        onSuccess: {
            "useBulkUpdateTags.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateTags.useMutation"],
        onError: {
            "useBulkUpdateTags.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact tags",
                    tags: {
                        component: "useBulkUpdateTags"
                    }
                });
            }
        }["useBulkUpdateTags.useMutation"]
    });
}
_s7(useBulkUpdateTags, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateCompanies() {
    _s8();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateCompanies.useMutation": async ({ contactIds, company })=>{
                const response = await fetch("/api/contacts/bulk-company", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        company
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateCompanies.useMutation": ()=>({})
                    }["useBulkUpdateCompanies.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update companies");
                }
                return response.json();
            }
        }["useBulkUpdateCompanies.useMutation"],
        onSuccess: {
            "useBulkUpdateCompanies.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateCompanies.useMutation"],
        onError: {
            "useBulkUpdateCompanies.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact companies",
                    tags: {
                        component: "useBulkUpdateCompanies"
                    }
                });
            }
        }["useBulkUpdateCompanies.useMutation"]
    });
}
_s8(useBulkUpdateCompanies, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useContact.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useContact",
    ()=>useContact
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ui$2d$mode$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ui-mode.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function useContact(userId, contactId) {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "contact",
            userId,
            contactId
        ],
        queryFn: {
            "useContact.useQuery[query]": async ()=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}`);
                if (!response.ok) {
                    if (response.status === 404) {
                        return null;
                    }
                    const errorData = await response.json().catch({
                        "useContact.useQuery[query]": ()=>({})
                    }["useContact.useQuery[query]"]);
                    throw new Error(errorData.error || "Failed to fetch contact");
                }
                const data = await response.json();
                return data.contact;
            }
        }["useContact.useQuery[query]"],
        staleTime: 0,
        enabled: !!userId && !!contactId,
        // ⭐ ONLY placeholderData — NO initialData
        // This ensures optimistic updates persist during refetches
        placeholderData: {
            "useContact.useQuery[query]": ()=>{
                // First check if we have the individual contact query data (includes optimistic updates)
                const detail = queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]);
                if (detail) return detail;
                // Otherwise fall back to contacts list
                const list = queryClient.getQueryData([
                    "contacts",
                    userId
                ]);
                return list?.find({
                    "useContact.useQuery[query]": (c)=>c.contactId === contactId
                }["useContact.useQuery[query]"]);
            }
        }["useContact.useQuery[query]"]
    });
    const uiMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ui$2d$mode$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUIMode"])();
    // Override query result based on UI mode
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useContact.useMemo": ()=>{
            if (uiMode === "suspense") {
                return {
                    ...query,
                    data: undefined,
                    isLoading: true
                };
            }
            if (uiMode === "empty") {
                return {
                    ...query,
                    data: undefined,
                    isLoading: false
                };
            }
            return query;
        }
    }["useContact.useMemo"], [
        query,
        uiMode
    ]);
}
_s(useContact, "wZf+12UpbbP5RRtCZ5pP5uR42PI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/TouchpointStatusActions.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TouchpointStatusActions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useAuth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function TouchpointStatusActions({ contactId, contactName, userId, onStatusUpdate, compact = false, currentStatus: fallbackStatus }) {
    _s();
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    // Use userId prop if provided, otherwise fall back to user?.uid
    const effectiveUserId = userId || user?.uid || "";
    // Read contact directly from React Query cache for optimistic updates
    // Fall back to prop if contact isn't in cache (e.g., in ContactCard list view)
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(effectiveUserId, contactId);
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [currentStatus, setCurrentStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(contact?.touchpointStatus ?? fallbackStatus ?? null);
    const [showCancelModal, setShowCancelModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showCompleteModal, setShowCompleteModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reason, setReason] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const mutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateTouchpointStatus"])(effectiveUserId);
    // Reset state ONLY when contactId changes (switching to a different contact)
    // We don't update when updatedAt changes because that would reset our local state
    // during optimistic updates and refetches. The local state is the source of truth
    // until we switch to a different contact.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TouchpointStatusActions.useEffect": ()=>{
            if (!contact && !fallbackStatus) return;
            // Only update if we're switching to a different contact
            if (prevContactIdRef.current !== contactId) {
                prevContactIdRef.current = contactId;
                const statusToUse = contact?.touchpointStatus ?? fallbackStatus ?? null;
                // Batch state updates to avoid cascading renders
                setCurrentStatus(statusToUse);
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["TouchpointStatusActions.useEffect"], [
        contactId,
        fallbackStatus
    ]);
    const handleUpdateStatus = async (status, reason)=>{
        setError(null);
        setCurrentStatus(status);
        mutation.mutate({
            contactId,
            status,
            reason: reason || null
        }, {
            onSuccess: ()=>{
                setShowCancelModal(false);
                setShowCompleteModal(false);
                setReason("");
                onStatusUpdate?.();
            },
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating touchpoint status in TouchpointStatusActions",
                    tags: {
                        component: "TouchpointStatusActions",
                        contactId
                    }
                });
                setError((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
            }
        });
    };
    if (compact) {
        // Compact view for dashboard cards
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-2",
                    children: [
                        currentStatus !== "completed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "secondary",
                            onClick: ()=>setShowCompleteModal(true),
                            disabled: mutation.isPending,
                            className: "flex-1 cursor-pointer sm:flex-none px-3 py-2 sm:px-2 sm:py-1 text-xs disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 sm:gap-1",
                            title: "I've contacted this person",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-3.5 h-3.5 shrink-0",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M5 13l4 4L19 7"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 114,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 108,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "whitespace-nowrap",
                                    children: "Mark as Contacted"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 121,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 101,
                            columnNumber: 13
                        }, this),
                        currentStatus !== "cancelled" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "outline",
                            onClick: ()=>setShowCancelModal(true),
                            disabled: mutation.isPending,
                            className: "flex-1 sm:flex-none px-3 py-2 sm:px-2 sm:py-1 text-xs font-medium text-foreground border border-theme-medium rounded hover:bg-theme-medium cursor-pointer transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 sm:gap-1",
                            title: "Skip this touchpoint - no action needed",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-3.5 h-3.5 shrink-0",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M6 18L18 6M6 6l12 12"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 138,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 132,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "whitespace-nowrap",
                                    children: "Skip Touchpoint"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 145,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 125,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 99,
                    columnNumber: 9
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                    message: error,
                    dismissible: true,
                    onDismiss: ()=>setError(null)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 150,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    isOpen: showCompleteModal,
                    onClose: ()=>{
                        if (!mutation.isPending) {
                            setShowCompleteModal(false);
                            setReason("");
                            setError(null);
                        }
                    },
                    title: "Mark as Contacted",
                    closeOnBackdropClick: !mutation.isPending,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-theme-dark mb-4",
                            children: [
                                "Mark the touchpoint for ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: contactName
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 169,
                                    columnNumber: 37
                                }, this),
                                " as contacted? This indicates you've reached out to them."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 168,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    htmlFor: "touchpoint-complete-note-compact",
                                    className: "block text-sm font-medium text-theme-darker mb-2",
                                    children: [
                                        "Note (optional)",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs text-gray-500 font-normal ml-1",
                                            children: "— This will be saved and displayed on the contact page"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                            lineNumber: 174,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 172,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "touchpoint-complete-note-compact",
                                    name: "touchpoint-complete-note-compact",
                                    value: reason,
                                    onChange: (e)=>setReason(e.target.value),
                                    placeholder: "e.g., Discussed proposal, scheduled follow-up, sent quote...",
                                    className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                    rows: 3,
                                    disabled: mutation.isPending,
                                    autoComplete: "off",
                                    "data-form-type": "other",
                                    "data-lpignore": "true",
                                    "data-1p-ignore": "true"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 178,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 171,
                            columnNumber: 11
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                                message: error,
                                dismissible: true,
                                onDismiss: ()=>setError(null)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 195,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 194,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-3 justify-end",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>{
                                        setShowCompleteModal(false);
                                        setReason("");
                                        setError(null);
                                    },
                                    disabled: mutation.isPending,
                                    variant: "outline",
                                    size: "sm",
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 203,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>handleUpdateStatus("completed", reason),
                                    disabled: mutation.isPending,
                                    loading: mutation.isPending,
                                    variant: "secondary",
                                    size: "sm",
                                    children: "Mark as Contacted"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 215,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 202,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 156,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    isOpen: showCancelModal,
                    onClose: ()=>{
                        if (!mutation.isPending) {
                            setShowCancelModal(false);
                            setReason("");
                            setError(null);
                        }
                    },
                    title: "Skip Touchpoint",
                    closeOnBackdropClick: !mutation.isPending,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-theme-dark mb-4",
                            children: [
                                "Skip the touchpoint for ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: contactName
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 239,
                                    columnNumber: 37
                                }, this),
                                "? This indicates no action is needed at this time."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 238,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    htmlFor: "touchpoint-skip-reason-compact",
                                    className: "block text-sm font-medium text-theme-darker mb-2",
                                    children: [
                                        "Reason (optional)",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs text-gray-500 font-normal ml-1",
                                            children: "— This will be saved and displayed on the contact page"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                            lineNumber: 244,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 242,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "touchpoint-skip-reason-compact",
                                    name: "touchpoint-skip-reason-compact",
                                    value: reason,
                                    onChange: (e)=>setReason(e.target.value),
                                    placeholder: "e.g., Not relevant, contact inactive, wrong contact...",
                                    className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                    rows: 3,
                                    disabled: mutation.isPending,
                                    autoComplete: "off",
                                    "data-form-type": "other",
                                    "data-lpignore": "true",
                                    "data-1p-ignore": "true"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 248,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 241,
                            columnNumber: 11
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                                message: error,
                                dismissible: true,
                                onDismiss: ()=>setError(null)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 265,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 264,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-3 justify-end",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>{
                                        setShowCancelModal(false);
                                        setReason("");
                                        setError(null);
                                    },
                                    disabled: mutation.isPending,
                                    size: "sm",
                                    children: "Keep Touchpoint"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 273,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>handleUpdateStatus("cancelled", reason),
                                    disabled: mutation.isPending,
                                    loading: mutation.isPending,
                                    variant: "outline",
                                    size: "sm",
                                    children: "Skip Touchpoint"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 284,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 272,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 226,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
            lineNumber: 98,
            columnNumber: 7
        }, this);
    }
    // Full view for contact detail page
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    currentStatus === "completed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "px-3 py-1 text-sm font-medium text-green-700 bg-green-50 border border-green-200 rounded-full",
                        children: "✓ Contacted"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 304,
                        columnNumber: 11
                    }, this),
                    currentStatus === "cancelled" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "px-3 py-1 text-sm font-medium text-[#eeeeec] bg-theme-medium rounded-full",
                        children: "✕ Skipped"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 309,
                        columnNumber: 11
                    }, this),
                    (!currentStatus || currentStatus === "pending") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "px-3 py-1 text-sm font-medium text-blue-700 bg-blue-50 border border-blue-200 rounded-full",
                        children: "Pending"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 314,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 302,
                columnNumber: 7
            }, this),
            (!currentStatus || currentStatus === "pending") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>setShowCompleteModal(true),
                        disabled: mutation.isPending,
                        variant: "secondary",
                        size: "sm",
                        children: "Mark as Contacted"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 322,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>setShowCancelModal(true),
                        disabled: mutation.isPending,
                        variant: "outline",
                        size: "sm",
                        children: "Skip Touchpoint"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 330,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 321,
                columnNumber: 9
            }, this),
            (currentStatus === "completed" || currentStatus === "cancelled") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                onClick: ()=>handleUpdateStatus(null),
                disabled: mutation.isPending,
                loading: mutation.isPending,
                variant: "outline",
                size: "sm",
                className: "text-blue-700 bg-blue-50 hover:bg-blue-100",
                children: "Restore to Pending"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 342,
                columnNumber: 9
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                message: error,
                dismissible: true,
                onDismiss: ()=>setError(null)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 355,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showCompleteModal,
                onClose: ()=>{
                    if (!mutation.isPending) {
                        setShowCompleteModal(false);
                        setReason("");
                        setError(null);
                    }
                },
                title: "Mark as Contacted",
                closeOnBackdropClick: !mutation.isPending,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-theme-dark mb-4",
                        children: [
                            "Mark the touchpoint for ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: contactName
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 376,
                                columnNumber: 35
                            }, this),
                            " as contacted? This indicates you've reached out to them."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 375,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "touchpoint-complete-note",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: [
                                    "Note (optional)",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-500 font-normal ml-1",
                                        children: "— This will be saved and displayed on the contact page"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 381,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 379,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "touchpoint-complete-note",
                                name: "touchpoint-complete-note",
                                value: reason,
                                onChange: (e)=>setReason(e.target.value),
                                placeholder: "e.g., Discussed proposal, scheduled follow-up, sent quote...",
                                className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                rows: 3,
                                disabled: mutation.isPending,
                                autoComplete: "off",
                                "data-form-type": "other",
                                "data-lpignore": "true",
                                "data-1p-ignore": "true"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 385,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 378,
                        columnNumber: 9
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                            message: error,
                            dismissible: true,
                            onDismiss: ()=>setError(null)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 402,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 401,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>{
                                    setShowCompleteModal(false);
                                    setReason("");
                                    setError(null);
                                },
                                disabled: mutation.isPending,
                                variant: "outline",
                                size: "sm",
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 410,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>handleUpdateStatus("completed", reason),
                                disabled: mutation.isPending,
                                loading: mutation.isPending,
                                variant: "secondary",
                                size: "sm",
                                children: "Mark Completed"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 422,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 409,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 363,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showCancelModal,
                onClose: ()=>{
                    if (!mutation.isPending) {
                        setShowCancelModal(false);
                        setReason("");
                        setError(null);
                    }
                },
                title: "Skip Touchpoint",
                closeOnBackdropClick: !mutation.isPending,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-theme-dark mb-4",
                        children: [
                            "Skip the touchpoint for ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: contactName
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 447,
                                columnNumber: 35
                            }, this),
                            "? This indicates no action is needed at this time."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 446,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "touchpoint-skip-reason",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: [
                                    "Reason (optional)",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-500 font-normal ml-1",
                                        children: "— This will be saved and displayed on the contact page"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 452,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 450,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "touchpoint-skip-reason",
                                name: "touchpoint-skip-reason",
                                value: reason,
                                onChange: (e)=>setReason(e.target.value),
                                placeholder: "e.g., Not relevant, contact inactive, wrong contact...",
                                className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                rows: 3,
                                disabled: mutation.isPending,
                                autoComplete: "off",
                                "data-form-type": "other",
                                "data-lpignore": "true",
                                "data-1p-ignore": "true"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 456,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 449,
                        columnNumber: 9
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                            message: error,
                            dismissible: true,
                            onDismiss: ()=>setError(null)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 473,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 472,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>{
                                    setShowCancelModal(false);
                                    setReason("");
                                    setError(null);
                                },
                                disabled: mutation.isPending,
                                size: "sm",
                                children: "Keep Touchpoint"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 481,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>handleUpdateStatus("cancelled", reason),
                                disabled: mutation.isPending,
                                loading: mutation.isPending,
                                variant: "outline",
                                size: "sm",
                                children: "Skip Touchpoint"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 492,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 480,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 434,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
        lineNumber: 301,
        columnNumber: 5
    }, this);
}
_s(TouchpointStatusActions, "1Jh2UPZgvdtuvTUSRXwI+3BTGhA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateTouchpointStatus"]
    ];
});
_c = TouchpointStatusActions;
var _c;
__turbopack_context__.k.register(_c, "TouchpointStatusActions");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/QuickTag.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>QuickTag
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function QuickTag({ contactId, userId, existingTags = [], onTagAdded }) {
    _s();
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [tagValue, setTagValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const updateContact = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"])(userId);
    // Focus input when expanded
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "QuickTag.useEffect": ()=>{
            if (isExpanded && inputRef.current) {
                inputRef.current.focus();
            }
        }
    }["QuickTag.useEffect"], [
        isExpanded
    ]);
    const handlePlusClick = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setIsExpanded(true);
        setError(null);
    };
    const handleCancel = (e)=>{
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }
        setIsExpanded(false);
        setTagValue("");
        setError(null);
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        e.stopPropagation();
        const trimmedTag = tagValue.trim();
        // Validate: empty tag
        if (!trimmedTag) {
            setError("Tag cannot be empty");
            return;
        }
        // Validate: duplicate tag (case-insensitive)
        const normalizedExisting = existingTags.map((tag)=>tag.toLowerCase().trim());
        if (normalizedExisting.includes(trimmedTag.toLowerCase())) {
            setError("Tag already exists");
            return;
        }
        setError(null);
        // Prepare updated tags array - add new tag to the beginning
        const updatedTags = [
            trimmedTag,
            ...existingTags
        ];
        try {
            await updateContact.mutateAsync({
                contactId,
                updates: {
                    tags: updatedTags
                }
            });
            // Success - reset and close
            setTagValue("");
            setIsExpanded(false);
            onTagAdded?.();
        } catch (err) {
            setError(err instanceof Error ? err.message : "Failed to add tag");
        }
    };
    const handleKeyDown = (e)=>{
        if (e.key === "Escape") {
            handleCancel();
        }
    };
    if (!isExpanded) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: handlePlusClick,
            className: "cursor-pointer px-2 py-1 text-xs font-medium border border-card-tag text-card-tag-text rounded-sm hover:bg-card-tag/10 transition-colors flex items-center justify-center shrink-0",
            "aria-label": "Add tag",
            title: "Add tag",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: "w-3 h-3",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                strokeWidth: 2,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M12 4v16m8-8H4"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                    lineNumber: 113,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                lineNumber: 106,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
            lineNumber: 99,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleSubmit,
        className: "flex items-center gap-1 shrink-0",
        onClick: (e)=>e.stopPropagation(),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        ref: inputRef,
                        type: "text",
                        value: tagValue,
                        onChange: (e)=>{
                            setTagValue(e.target.value);
                            setError(null);
                        },
                        onKeyDown: handleKeyDown,
                        placeholder: "Tag name",
                        className: "w-24 h-7 px-2 py-1 text-xs",
                        disabled: updateContact.isPending
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                        lineNumber: 130,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        disabled: updateContact.isPending || !tagValue.trim(),
                        className: "cursor-pointer px-2 py-1 text-xs font-medium bg-blue-600 text-white rounded-sm hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                        "aria-label": "Add tag",
                        children: updateContact.isPending ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "animate-spin h-3 w-3",
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                    className: "opacity-25",
                                    cx: "12",
                                    cy: "12",
                                    r: "10",
                                    stroke: "currentColor",
                                    strokeWidth: "4"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                                    lineNumber: 156,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    className: "opacity-75",
                                    fill: "currentColor",
                                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                                    lineNumber: 164,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                            lineNumber: 150,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-3 h-3",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            strokeWidth: 2,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                d: "M5 13l4 4L19 7"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                                lineNumber: 178,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                            lineNumber: 171,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                        lineNumber: 143,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleCancel,
                        disabled: updateContact.isPending,
                        className: "cursor-pointer px-2 py-1 text-xs font-medium border border-gray-300 text-gray-200 rounded-sm hover:bg-gray-50/10 disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                        "aria-label": "Cancel",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-3 h-3",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            strokeWidth: 2,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                d: "M6 18L18 6M6 6l12 12"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                                lineNumber: 200,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                            lineNumber: 193,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                        lineNumber: 186,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                lineNumber: 129,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xs text-red-600 whitespace-nowrap",
                role: "alert",
                children: error
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
                lineNumber: 209,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/QuickTag.tsx",
        lineNumber: 124,
        columnNumber: 5
    }, this);
}
_s(QuickTag, "sUo0v2pnxVXdhnk347aH79yANkY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"]
    ];
});
_c = QuickTag;
var _c;
__turbopack_context__.k.register(_c, "QuickTag");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ContactCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$TouchpointStatusActions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/TouchpointStatusActions.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$QuickTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/QuickTag.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
function ContactCard({ contact, showCheckbox = false, isSelected = false, onSelectChange, variant = "default", showArrow = true, touchpointDate, daysUntil, needsReminder = false, showTouchpointActions = false, onTouchpointStatusUpdate, userId }) {
    const isTouchpointVariant = variant === "touchpoint-upcoming" || variant === "touchpoint-overdue";
    const getVariantStyles = ()=>{
        if (isSelected) return "ring-2 ring-blue-500 bg-card-active";
        switch(variant){
            case "selected":
                return "ring-2 ring-blue-500 bg-card-active";
            case "touchpoint-upcoming":
                return needsReminder ? "bg-card-upcoming border border-card-upcoming-dark" : "border border-theme-light";
            case "touchpoint-overdue":
                return "bg-card-overdue border border-card-overdue-dark";
            default:
                return "border border-theme-light";
        }
    };
    const formatTouchpointDate = ()=>{
        if (!touchpointDate || daysUntil === null || daysUntil === undefined) return null;
        if (variant === "touchpoint-overdue") {
            return daysUntil < 0 ? `Overdue ${Math.abs(daysUntil)} day${Math.abs(daysUntil) !== 1 ? "s" : ""}` : "Overdue";
        }
        if (daysUntil === 0) return "Today";
        if (daysUntil === 1) return "Tomorrow";
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(touchpointDate, {
            relative: true
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `rounded-sm p-4 transition-all duration-200 ${getVariantStyles()}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-start gap-3",
                children: [
                    showCheckbox && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "flex items-center pt-1 cursor-pointer",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "checkbox",
                            checked: isSelected,
                            onChange: ()=>onSelectChange?.(contact.id),
                            onClick: (e)=>e.stopPropagation(),
                            className: "w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                            lineNumber: 80,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                        lineNumber: 79,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 min-w-0 flex items-start xl:items-stretch gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: `/contacts/${contact.id}`,
                                className: "flex items-start gap-3 flex-1 min-w-0 xl:flex-[1_1_60%] xl:max-w-[60%] group",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "shrink-0",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold text-sm shadow-sm bg-linear-to-br from-blue-500 to-purple-600`,
                                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(contact)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                            lineNumber: 99,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                        lineNumber: 98,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1 min-w-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col xxl:flex-row items-start justify-between gap-2 mb-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: `text-sm font-semibold group-hover:text-theme-darker transition-colors text-theme-darkest wrap-break-word`,
                                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contact)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                        lineNumber: 107,
                                                        columnNumber: 17
                                                    }, this),
                                                    isTouchpointVariant && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-1.5 sm:gap-2 shrink-0 flex-wrap",
                                                        children: [
                                                            variant === "touchpoint-upcoming" && needsReminder && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "px-2 py-1 text-xs font-medium text-theme-darker border border-theme-medium rounded-sm whitespace-nowrap",
                                                                children: "Due Soon"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                                lineNumber: 114,
                                                                columnNumber: 23
                                                            }, this),
                                                            variant === "touchpoint-overdue" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "px-2 py-1 text-xs font-medium text-theme-darker border border-theme-medium rounded-sm whitespace-nowrap",
                                                                children: "Overdue"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                                lineNumber: 119,
                                                                columnNumber: 23
                                                            }, this),
                                                            formatTouchpointDate() && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: `text-xs font-medium px-2 py-1 rounded-sm whitespace-nowrap ${variant === "touchpoint-overdue" ? "text-theme-darker border border-theme-medium" : daysUntil !== null && daysUntil !== undefined && daysUntil <= 3 ? "text-theme-darker border border-theme-medium" : "text-theme-darker border border-theme-medium"}`,
                                                                children: formatTouchpointDate()
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                                lineNumber: 124,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                        lineNumber: 112,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                lineNumber: 106,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: `text-xs truncate mb-2 text-theme-dark`,
                                                children: contact.primaryEmail
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                lineNumber: 137,
                                                columnNumber: 15
                                            }, this),
                                            !isTouchpointVariant && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col gap-0.5 mb-2",
                                                children: [
                                                    contact.lastEmailDate != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-gray-400 flex items-center gap-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "w-3 h-3 shrink-0",
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    strokeWidth: 2,
                                                                    d: "M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                                    lineNumber: 152,
                                                                    columnNumber: 25
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                                lineNumber: 146,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "truncate",
                                                                children: [
                                                                    "Last email: ",
                                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(contact.lastEmailDate, {
                                                                        relative: true
                                                                    })
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                                lineNumber: 159,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                        lineNumber: 145,
                                                        columnNumber: 21
                                                    }, this),
                                                    contact.updatedAt != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-gray-400 flex items-center gap-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "w-3 h-3 shrink-0",
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    strokeWidth: 2,
                                                                    d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                                    lineNumber: 170,
                                                                    columnNumber: 25
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                                lineNumber: 164,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "truncate",
                                                                children: [
                                                                    "Updated: ",
                                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(contact.updatedAt, {
                                                                        relative: true
                                                                    })
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                                lineNumber: 177,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                        lineNumber: 163,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                lineNumber: 143,
                                                columnNumber: 17
                                            }, this),
                                            !isTouchpointVariant && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-wrap items-center gap-1.5 mt-1.5 xl:hidden",
                                                children: [
                                                    contact.segment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "px-2 py-1 text-xs font-medium text-theme-darkest rounded whitespace-nowrap border border-theme-dark",
                                                        children: contact.segment
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                        lineNumber: 187,
                                                        columnNumber: 21
                                                    }, this),
                                                    contact.tags && contact.tags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                        children: [
                                                            contact.tags.slice(0, 3).map((tag, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "px-2 py-1 text-xs font-medium border border-card-tag text-card-tag-text rounded-sm",
                                                                    children: tag
                                                                }, idx, false, {
                                                                    fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                                    lineNumber: 195,
                                                                    columnNumber: 25
                                                                }, this)),
                                                            contact.tags.length > 3 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "px-2 py-1 text-xs font-medium text-theme-dark",
                                                                children: [
                                                                    "+",
                                                                    contact.tags.length - 3
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                                lineNumber: 203,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                lineNumber: 185,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                        lineNumber: 105,
                                        columnNumber: 13
                                    }, this),
                                    showArrow && !isTouchpointVariant && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "hidden xl:block shrink-0 opacity-0 group-hover:opacity-100 transition-opacity",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-5 h-5 text-gray-400",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M9 5l7 7-7 7"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                lineNumber: 222,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                            lineNumber: 216,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                        lineNumber: 215,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                lineNumber: 93,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "hidden xl:flex items-stretch shrink-0 px-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-px bg-theme-light/30 my-2"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                    lineNumber: 235,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                lineNumber: 234,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `hidden xl:flex ${isTouchpointVariant ? 'items-center' : 'flex-col items-end'} gap-2 shrink-0 ml-auto`,
                                children: [
                                    contact.segment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `px-2 py-1 text-xs font-medium text-theme-darkest rounded whitespace-nowrap border border-theme-dark`,
                                        children: contact.segment
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                        lineNumber: 241,
                                        columnNumber: 15
                                    }, this),
                                    !isTouchpointVariant && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap gap-1 justify-end items-center",
                                        children: [
                                            userId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$QuickTag$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                contactId: contact.id,
                                                userId: userId,
                                                existingTags: contact.tags
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                lineNumber: 250,
                                                columnNumber: 19
                                            }, this),
                                            contact.tags && contact.tags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    contact.tags.slice(0, 2).map((tag, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "px-2 py-1 text-xs font-medium border border-card-tag text-card-tag-text rounded-sm",
                                                            children: tag
                                                        }, idx, false, {
                                                            fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                            lineNumber: 260,
                                                            columnNumber: 23
                                                        }, this)),
                                                    contact.tags.length > 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "px-2 py-1 text-xs font-medium text-theme-dark",
                                                        children: [
                                                            "+",
                                                            contact.tags.length - 2
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                                        lineNumber: 268,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                        lineNumber: 247,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                lineNumber: 239,
                                columnNumber: 11
                            }, this),
                            isTouchpointVariant && contact.nextTouchpointMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-2 mb-3",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: `text-xs sm:text-sm rounded px-2.5 sm:px-3 py-2 sm:py-1.5 line-clamp-2 sm:line-clamp-none w-full block wrap-break-word`,
                                    children: contact.nextTouchpointMessage
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                    lineNumber: 281,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                                lineNumber: 280,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this),
            showTouchpointActions && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `pt-3 border-t ${variant === "touchpoint-overdue" ? "border-red-200" : needsReminder ? "border-amber-200" : "border-gray-200"}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$TouchpointStatusActions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    contactId: contact.id,
                    contactName: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contact),
                    userId: userId || "",
                    currentStatus: contact.touchpointStatus,
                    compact: true,
                    onStatusUpdate: onTouchpointStatusUpdate
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                    lineNumber: 298,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
                lineNumber: 291,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/ContactCard.tsx",
        lineNumber: 73,
        columnNumber: 5
    }, this);
}
_c = ContactCard;
var _c;
__turbopack_context__.k.register(_c, "ContactCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Pagination.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Pagination
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
"use client";
;
;
function Pagination({ currentPage, totalPages, totalItems, startIndex, endIndex, itemLabel, onPageChange, className = "", hideItemCount = false }) {
    // Don't render if there's only one page
    if (totalPages <= 1) return null;
    // Simple pluralization: add 's' to the end (works for most cases)
    const itemLabelPlural = `${itemLabel}s`;
    const itemText = totalItems === 1 ? itemLabel : itemLabelPlural;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex flex-col sm:flex-row items-center ${hideItemCount ? 'justify-end' : 'justify-between'} gap-4 ${hideItemCount ? 'pb-4 mb-4 border-b border-gray-200' : 'border-t border-gray-200 pt-4 mt-4'} ${className}`,
        children: [
            !hideItemCount && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-sm text-theme-darker",
                children: [
                    "Showing ",
                    startIndex + 1,
                    " to ",
                    Math.min(endIndex, totalItems),
                    " of",
                    " ",
                    totalItems,
                    " ",
                    itemText
                ]
            }, void 0, true, {
                fileName: "[project]/components/Pagination.tsx",
                lineNumber: 42,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>onPageChange(Math.max(1, currentPage - 1)),
                        disabled: currentPage === 1,
                        variant: "outline",
                        size: "sm",
                        children: "Previous"
                    }, void 0, false, {
                        fileName: "[project]/components/Pagination.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "flex items-center px-4 text-sm text-theme-darker",
                        children: [
                            "Page ",
                            currentPage,
                            " of ",
                            totalPages
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/Pagination.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>onPageChange(Math.min(totalPages, currentPage + 1)),
                        disabled: currentPage === totalPages,
                        variant: "outline",
                        size: "sm",
                        children: "Next"
                    }, void 0, false, {
                        fileName: "[project]/components/Pagination.tsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/Pagination.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/Pagination.tsx",
        lineNumber: 40,
        columnNumber: 5
    }, this);
}
_c = Pagination;
var _c;
__turbopack_context__.k.register(_c, "Pagination");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ThemedSuspense.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ThemedSuspense,
    "getThemedFallback",
    ()=>getThemedFallback
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
;
function getThemedFallback(variant = "default") {
    switch(variant){
        case "simple":
            // Simple bar skeleton for small content
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-8 w-16 bg-theme-light rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 20,
                columnNumber: 9
            }, this);
        case "card":
            // Single card skeleton
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-card-highlight-light rounded-xl shadow p-4 animate-pulse",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-12 h-12 bg-theme-light rounded-full shrink-0"
                        }, void 0, false, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 28,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 space-y-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-5 bg-theme-light rounded w-2/3"
                                }, void 0, false, {
                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                    lineNumber: 30,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-4 bg-theme-light rounded w-1/2"
                                }, void 0, false, {
                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                    lineNumber: 31,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 29,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ThemedSuspense.tsx",
                    lineNumber: 27,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 26,
                columnNumber: 9
            }, this);
        case "list":
            // List skeleton without card wrapper
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: Array.from({
                    length: 3
                }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4 p-4 bg-card-highlight-light rounded-sm animate-pulse",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-12 h-12 bg-theme-light rounded-full shrink-0"
                            }, void 0, false, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 43,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-5 bg-theme-light rounded w-2/3"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 45,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-4 bg-theme-light rounded w-1/2"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 46,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 44,
                                columnNumber: 15
                            }, this)
                        ]
                    }, i, true, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 42,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 40,
                columnNumber: 9
            }, this);
        case "dashboard":
            // Dashboard loading skeleton
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 xl:grid-cols-[1fr_340px] gap-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-6",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-6 bg-theme-light rounded w-40 mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 60,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-3",
                                        children: Array.from({
                                            length: 3
                                        }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "w-12 h-12 bg-theme-light rounded-full shrink-0"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                                        lineNumber: 64,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex-1 space-y-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "h-5 bg-theme-light rounded w-2/3"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/ThemedSuspense.tsx",
                                                                lineNumber: 66,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "h-4 bg-theme-light rounded w-1/2"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/ThemedSuspense.tsx",
                                                                lineNumber: 67,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                                        lineNumber: 65,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, i, true, {
                                                fileName: "[project]/components/ThemedSuspense.tsx",
                                                lineNumber: 63,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 61,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 59,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 58,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-6",
                            children: Array.from({
                                length: 4
                            }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-6 bg-theme-light rounded w-32 mb-4"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ThemedSuspense.tsx",
                                            lineNumber: 77,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-32 bg-theme-light rounded"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ThemedSuspense.tsx",
                                            lineNumber: 78,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, i, true, {
                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                    lineNumber: 76,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 74,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ThemedSuspense.tsx",
                    lineNumber: 57,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 56,
                columnNumber: 9
            }, this);
        case "page":
            // Full page loading skeleton
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-10 w-24 bg-theme-light rounded animate-pulse"
                        }, void 0, false, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 91,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 90,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-6 bg-theme-light rounded w-32 mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 95,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-32 bg-theme-light rounded"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 96,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 94,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-6 bg-theme-light rounded w-32 mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 99,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-64 bg-theme-light rounded"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 100,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 98,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 93,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 89,
                columnNumber: 9
            }, this);
        case "sync":
            // Sync page loading skeleton
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-10 w-24 bg-theme-light rounded animate-pulse"
                        }, void 0, false, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 111,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 110,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-6 bg-theme-light rounded w-32 mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 115,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-32 bg-theme-light rounded"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 116,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 114,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-6 bg-theme-light rounded w-32 mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 119,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-64 bg-theme-light rounded"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 120,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 118,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 113,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 109,
                columnNumber: 9
            }, this);
        case "default":
        default:
            // Card-based list skeleton (default)
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-6 bg-card-highlight-light rounded w-32 mb-2 animate-pulse"
                    }, void 0, false, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 131,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 gap-3",
                        children: Array.from({
                            length: 5
                        }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-4 animate-pulse",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-12 h-12 bg-theme-light rounded-full shrink-0"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ThemedSuspense.tsx",
                                            lineNumber: 136,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1 space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "h-5 bg-theme-light rounded w-2/3"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                                    lineNumber: 138,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "h-4 bg-theme-light rounded w-1/2"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                                    lineNumber: 139,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/ThemedSuspense.tsx",
                                            lineNumber: 137,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                    lineNumber: 135,
                                    columnNumber: 17
                                }, this)
                            }, i, false, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 134,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 132,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 130,
                columnNumber: 9
            }, this);
    }
}
function ThemedSuspense({ children, fallback, variant = "default", isLoading = false }) {
    // If isLoading is true, show fallback immediately (for conditional rendering)
    if (isLoading) {
        if (fallback !== undefined) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: fallback
            }, void 0, false);
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: getThemedFallback(variant)
        }, void 0, false);
    }
    // For Suspense mode, children is required
    if (!children) {
        return null;
    }
    // If custom fallback provided, use it
    if (fallback !== undefined) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: fallback,
            children: children
        }, void 0, false, {
            fileName: "[project]/components/ThemedSuspense.tsx",
            lineNumber: 186,
            columnNumber: 12
        }, this);
    }
    // Use themed fallback based on variant
    const defaultFallback = getThemedFallback(variant);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: defaultFallback,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ThemedSuspense.tsx",
        lineNumber: 191,
        columnNumber: 10
    }, this);
}
_c = ThemedSuspense;
var _c;
__turbopack_context__.k.register(_c, "ThemedSuspense");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/dashboard/EmptyState.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EmptyState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
function EmptyState({ message = "No contacts yet", description = "Get started by importing your contacts or adding your first contact", showActions = true, wrapInCard = false, size = "sm", className = "" }) {
    const iconSize = size === "lg" ? "w-16 h-16" : "w-12 h-12";
    const headingSize = size === "lg" ? "text-lg font-semibold" : "text-sm font-medium";
    const padding = size === "lg" ? "xl" : "md";
    const iconMargin = size === "lg" ? "mb-4" : "mb-3";
    const textMargin = size === "lg" ? "mb-2" : "mb-1";
    const descriptionMargin = size === "lg" ? "mb-6" : "mb-4";
    const buttonGap = size === "lg" ? "gap-3" : "gap-2";
    const content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: `${iconSize} mx-auto ${iconMargin} text-gray-300`,
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                }, void 0, false, {
                    fileName: "[project]/components/dashboard/EmptyState.tsx",
                    lineNumber: 40,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/dashboard/EmptyState.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: `${headingSize} text-theme-darkest ${textMargin}`,
                children: message
            }, void 0, false, {
                fileName: "[project]/components/dashboard/EmptyState.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: `text-xs text-gray-500 ${descriptionMargin}`,
                children: description
            }, void 0, false, {
                fileName: "[project]/components/dashboard/EmptyState.tsx",
                lineNumber: 49,
                columnNumber: 9
            }, this),
            showActions && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `flex flex-col sm:flex-row ${buttonGap} justify-center`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/contacts/import",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            size: "sm",
                            children: [
                                size === "lg" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-4 h-4",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                                    }, void 0, false, {
                                        fileName: "[project]/components/dashboard/EmptyState.tsx",
                                        lineNumber: 57,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/dashboard/EmptyState.tsx",
                                    lineNumber: 56,
                                    columnNumber: 17
                                }, this),
                                "Import Contacts"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/dashboard/EmptyState.tsx",
                            lineNumber: 54,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/dashboard/EmptyState.tsx",
                        lineNumber: 53,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/contacts/new",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "outline",
                            size: "sm",
                            children: [
                                size === "lg" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-4 h-4",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M12 4v16m8-8H4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/dashboard/EmptyState.tsx",
                                        lineNumber: 72,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/dashboard/EmptyState.tsx",
                                    lineNumber: 71,
                                    columnNumber: 17
                                }, this),
                                "Add Contact"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/dashboard/EmptyState.tsx",
                            lineNumber: 69,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/dashboard/EmptyState.tsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/dashboard/EmptyState.tsx",
                lineNumber: 52,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
    if (wrapInCard) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: padding,
            className: `text-center ${className}`,
            children: content
        }, void 0, false, {
            fileName: "[project]/components/dashboard/EmptyState.tsx",
            lineNumber: 90,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `text-center ${size === "lg" ? "py-0" : "py-6"} ${className}`,
        children: content
    }, void 0, false, {
        fileName: "[project]/components/dashboard/EmptyState.tsx",
        lineNumber: 97,
        columnNumber: 5
    }, this);
}
_c = EmptyState;
var _c;
__turbopack_context__.k.register(_c, "EmptyState");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/contacts/_components/ContactsGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactsGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ContactCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Pagination$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Pagination.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ThemedSuspense$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ThemedSuspense.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/contacts/_components/ContactsFilterContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$dashboard$2f$EmptyState$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/dashboard/EmptyState.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function ContactsGrid({ userId }) {
    _s();
    const { filteredContacts, totalContactsCount, isLoading, onClearFilters, currentPage, setCurrentPage, totalPages, paginatedContacts, startIndex, endIndex, selectedContactIds, allFilteredSelected, toggleContactSelection, toggleSelectAll } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactsFilter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ThemedSuspense$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            isLoading: isLoading,
            children: filteredContacts.length === 0 && totalContactsCount > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                padding: "xl",
                className: "text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        className: "w-16 h-16 mx-auto mb-4 text-gray-300",
                        fill: "none",
                        stroke: "currentColor",
                        viewBox: "0 0 24 24",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: 2,
                            d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                            lineNumber: 44,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                        lineNumber: 38,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-lg font-medium text-theme-darkest mb-2",
                        children: "No contacts match your filters"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                        lineNumber: 51,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-gray-500 mb-6",
                        children: "Try adjusting your search criteria or clear filters to see all contacts"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                        lineNumber: 52,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: onClearFilters,
                        size: "sm",
                        children: "Clear Filters"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                        lineNumber: 55,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                lineNumber: 37,
                columnNumber: 11
            }, this) : filteredContacts.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$dashboard$2f$EmptyState$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                wrapInCard: false,
                size: "lg"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                lineNumber: 60,
                columnNumber: 11
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: [
                    filteredContacts.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3 pb-2 border-b border-gray-200",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "flex items-center gap-2 cursor-pointer",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "checkbox",
                                    checked: allFilteredSelected,
                                    onChange: toggleSelectAll,
                                    className: "w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                                    lineNumber: 67,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-sm font-medium text-theme-darker",
                                    children: [
                                        "Select all ",
                                        filteredContacts.length,
                                        " ",
                                        filteredContacts.length === 1 ? "contact" : "contacts"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                                    lineNumber: 73,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                            lineNumber: 66,
                            columnNumber: 17
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                        lineNumber: 65,
                        columnNumber: 15
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Pagination$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        currentPage: currentPage,
                        totalPages: totalPages,
                        totalItems: filteredContacts.length,
                        startIndex: startIndex,
                        endIndex: endIndex,
                        itemLabel: "contact",
                        onPageChange: setCurrentPage,
                        hideItemCount: true
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                        lineNumber: 82,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 gap-4",
                        children: paginatedContacts.map((contact)=>{
                            const isSelected = selectedContactIds.has(contact.id);
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                contact: contact,
                                showCheckbox: true,
                                isSelected: isSelected,
                                onSelectChange: toggleContactSelection,
                                variant: isSelected ? "selected" : "default",
                                userId: userId
                            }, contact.id, false, {
                                fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                                lineNumber: 97,
                                columnNumber: 19
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                        lineNumber: 93,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Pagination$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        currentPage: currentPage,
                        totalPages: totalPages,
                        totalItems: filteredContacts.length,
                        startIndex: startIndex,
                        endIndex: endIndex,
                        itemLabel: "contact",
                        onPageChange: setCurrentPage
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                        lineNumber: 111,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
                lineNumber: 62,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
            lineNumber: 35,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/contacts/_components/ContactsGrid.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_s(ContactsGrid, "C56tlakFWvaM5KzwRz+4YT+/uR8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactsFilter"]
    ];
});
_c = ContactsGrid;
var _c;
__turbopack_context__.k.register(_c, "ContactsGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/BulkActionsBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BulkActionsBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
"use client";
;
;
;
function BulkActionsBar({ selectedCount, itemLabel, actions, className = "" }) {
    if (selectedCount === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        className: `bg-blue-50 border-blue-200 mb-4 ${className}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-sm font-medium text-theme-darkest whitespace-nowrap",
                        children: [
                            selectedCount,
                            " ",
                            itemLabel,
                            selectedCount !== 1 ? "s" : "",
                            " selected"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/BulkActionsBar.tsx",
                        lineNumber: 37,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/BulkActionsBar.tsx",
                    lineNumber: 36,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col sm:flex-row gap-2 w-full xl:w-auto",
                    children: actions.map((action, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            onClick: action.onClick,
                            disabled: action.disabled,
                            loading: action.loading,
                            variant: action.variant,
                            size: "sm",
                            fullWidth: true,
                            className: "sm:w-auto whitespace-nowrap shrink-0",
                            icon: action.icon,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "hidden sm:inline",
                                    children: action.label
                                }, void 0, false, {
                                    fileName: "[project]/components/BulkActionsBar.tsx",
                                    lineNumber: 54,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "sm:hidden",
                                    children: action.labelMobile || action.label
                                }, void 0, false, {
                                    fileName: "[project]/components/BulkActionsBar.tsx",
                                    lineNumber: 55,
                                    columnNumber: 15
                                }, this),
                                action.showCount && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "ml-1 font-semibold",
                                    children: [
                                        "(",
                                        selectedCount,
                                        ")"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/BulkActionsBar.tsx",
                                    lineNumber: 56,
                                    columnNumber: 36
                                }, this)
                            ]
                        }, index, true, {
                            fileName: "[project]/components/BulkActionsBar.tsx",
                            lineNumber: 43,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/BulkActionsBar.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/BulkActionsBar.tsx",
            lineNumber: 35,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/BulkActionsBar.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_c = BulkActionsBar;
var _c;
__turbopack_context__.k.register(_c, "BulkActionsBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/SegmentSelect.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SegmentSelect
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function SegmentSelect({ value, onChange, existingSegments, placeholder = "Enter or select segment...", className = "" }) {
    _s();
    const [inputValue, setInputValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(value || "");
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [highlightedIndex, setHighlightedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const dropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const isUserTypingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const previousValueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(value);
    const inputValueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(inputValue);
    // Keep ref in sync with state
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SegmentSelect.useEffect": ()=>{
            inputValueRef.current = inputValue;
        }
    }["SegmentSelect.useEffect"], [
        inputValue
    ]);
    // Function to sync input value from prop changes (called from effect)
    // This follows React's recommendation to call a function instead of setState directly
    const syncInputFromProp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SegmentSelect.useCallback[syncInputFromProp]": (newValue)=>{
            const valueToSet = newValue || "";
            // Use ref to check current value without causing re-renders
            if (inputValueRef.current !== valueToSet) {
                setInputValue(valueToSet);
            }
        }
    }["SegmentSelect.useCallback[syncInputFromProp]"], []);
    // Update input value when prop value changes (only if changed externally, not from user input)
    // This is necessary to sync controlled input state with prop changes while allowing user typing
    // We defer the state update by calling the sync function asynchronously to avoid cascading renders
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SegmentSelect.useEffect": ()=>{
            if (previousValueRef.current !== value && !isUserTypingRef.current) {
                previousValueRef.current = value;
                // Defer the function call to avoid synchronous setState in effect
                queueMicrotask({
                    "SegmentSelect.useEffect": ()=>{
                        syncInputFromProp(value);
                    }
                }["SegmentSelect.useEffect"]);
            }
            // Reset typing flag after a short delay
            if (isUserTypingRef.current) {
                const timer = setTimeout({
                    "SegmentSelect.useEffect.timer": ()=>{
                        isUserTypingRef.current = false;
                    }
                }["SegmentSelect.useEffect.timer"], 100);
                return ({
                    "SegmentSelect.useEffect": ()=>clearTimeout(timer)
                })["SegmentSelect.useEffect"];
            }
        }
    }["SegmentSelect.useEffect"], [
        value,
        syncInputFromProp
    ]);
    // Filter segments based on input
    const filteredSegments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SegmentSelect.useMemo[filteredSegments]": ()=>{
            if (!inputValue.trim()) {
                return existingSegments;
            }
            const searchLower = inputValue.toLowerCase();
            return existingSegments.filter({
                "SegmentSelect.useMemo[filteredSegments]": (segment)=>segment.toLowerCase().includes(searchLower)
            }["SegmentSelect.useMemo[filteredSegments]"]);
        }
    }["SegmentSelect.useMemo[filteredSegments]"], [
        inputValue,
        existingSegments
    ]);
    // Check if current input matches an existing segment
    const isExistingSegment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SegmentSelect.useMemo[isExistingSegment]": ()=>{
            return existingSegments.includes(inputValue.trim());
        }
    }["SegmentSelect.useMemo[isExistingSegment]"], [
        inputValue,
        existingSegments
    ]);
    const handleInputChange = (e)=>{
        const newValue = e.target.value;
        isUserTypingRef.current = true;
        setInputValue(newValue);
        setHighlightedIndex(-1);
        setIsOpen(true);
        // Update parent immediately so user can type freely
        onChange(newValue.trim() || null);
    };
    const handleInputFocus = ()=>{
        setIsOpen(true);
    };
    const handleInputBlur = (e)=>{
        // Check if the newly focused element is within the dropdown
        const relatedTarget = e.relatedTarget;
        if (dropdownRef.current?.contains(relatedTarget)) {
            // User is clicking on dropdown item, don't close
            return;
        }
        // Delay closing to allow clicking on dropdown items
        setTimeout(()=>{
            if (!dropdownRef.current?.contains(document.activeElement)) {
                setIsOpen(false);
                setHighlightedIndex(-1);
                // If input doesn't match existing segment, keep it (allow new segments)
                // If input is empty, clear it
                if (!inputValue.trim()) {
                    onChange(null);
                }
            }
        }, 150);
    };
    const handleSelectSegment = (segment, e)=>{
        // Prevent blur from interfering with selection
        e?.preventDefault();
        e?.stopPropagation();
        setInputValue(segment);
        onChange(segment);
        setIsOpen(false);
        setHighlightedIndex(-1);
        // Use setTimeout to ensure the selection happens before blur
        setTimeout(()=>{
            inputRef.current?.blur();
        }, 0);
    };
    const handleClear = ()=>{
        setInputValue("");
        onChange(null);
        setIsOpen(false);
        inputRef.current?.focus();
    };
    const handleKeyDown = (e)=>{
        if (!isOpen && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
            setIsOpen(true);
            return;
        }
        if (e.key === "ArrowDown") {
            e.preventDefault();
            setHighlightedIndex((prev)=>prev < filteredSegments.length - 1 ? prev + 1 : prev);
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setHighlightedIndex((prev)=>prev > 0 ? prev - 1 : -1);
        } else if (e.key === "Enter" && highlightedIndex >= 0) {
            e.preventDefault();
            handleSelectSegment(filteredSegments[highlightedIndex]);
        } else if (e.key === "Escape") {
            setIsOpen(false);
            setHighlightedIndex(-1);
            inputRef.current?.blur();
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `relative ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: inputRef,
                        type: "text",
                        value: inputValue,
                        onChange: handleInputChange,
                        onFocus: handleInputFocus,
                        onBlur: handleInputBlur,
                        onKeyDown: handleKeyDown,
                        placeholder: placeholder,
                        "data-no-autofocus": true,
                        className: "w-full px-4 py-2 border border-gray-200 rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 pr-10 text-foreground placeholder:text-gray-400"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 167,
                        columnNumber: 9
                    }, this),
                    inputValue && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleClear,
                        className: "absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-theme-dark transition-colors",
                        tabIndex: -1,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-5 h-5",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M6 18L18 6M6 6l12 12"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 192,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                            lineNumber: 186,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 180,
                        columnNumber: 11
                    }, this),
                    !inputValue && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-5 h-5 text-gray-400",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M19 9l-7 7-7-7"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 209,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                            lineNumber: 203,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 202,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this),
            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "fixed inset-0 z-10",
                        onClick: ()=>setIsOpen(false)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 223,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: dropdownRef,
                        className: "absolute z-20 w-full mt-1 bg-card-highlight-light border border-gray-200 rounded-sm shadow-lg max-h-60 overflow-y-auto",
                        children: filteredSegments.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                filteredSegments.map((segment, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onMouseDown: (e)=>{
                                            e.preventDefault(); // Prevent input blur
                                            handleSelectSegment(segment, e);
                                        },
                                        className: `w-full text-left px-4 py-2 text-sm text-foreground rounded-sm hover:bg-theme-darker hover:text-theme-lightest transition-colors ${index === highlightedIndex ? "bg-theme-darker text-theme-lightest" : ""} ${segment === value ? "bg-theme-darker text-theme-lightest font-bold" : ""}`,
                                        children: segment
                                    }, segment, false, {
                                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                        lineNumber: 234,
                                        columnNumber: 19
                                    }, this)),
                                !isExistingSegment && inputValue.trim() && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-t border-gray-200",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onMouseDown: (e)=>{
                                            e.preventDefault(); // Prevent input blur
                                            handleSelectSegment(inputValue.trim(), e);
                                        },
                                        className: "w-full text-left px-4 py-2 text-sm text-foreground rounded-sm hover:bg-theme-darker hover:text-theme-lightest transition-colors",
                                        children: [
                                            '+ Create "',
                                            inputValue.trim(),
                                            '"'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                        lineNumber: 252,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                    lineNumber: 251,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: inputValue.trim() ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onMouseDown: (e)=>{
                                    e.preventDefault(); // Prevent input blur
                                    handleSelectSegment(inputValue.trim(), e);
                                },
                                className: "w-full text-left px-4 py-2 text-sm text-foreground rounded-sm hover:bg-theme-darker hover:text-theme-lightest transition-colors",
                                children: [
                                    '+ Create new segment: "',
                                    inputValue.trim(),
                                    '"'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 268,
                                columnNumber: 19
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "px-4 py-2 text-sm text-gray-500",
                                children: "No segments available"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 279,
                                columnNumber: 19
                            }, this)
                        }, void 0, false)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 227,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
        lineNumber: 165,
        columnNumber: 5
    }, this);
}
_s(SegmentSelect, "mXhLx9Yc2+h+4KO3C+zJadMZEPU=");
_c = SegmentSelect;
var _c;
__turbopack_context__.k.register(_c, "SegmentSelect");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/contacts/_components/BulkActionModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BulkActionModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$SegmentSelect$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/SegmentSelect.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
function BulkActionModal({ modalType, onClose, selectedCount, selectedNewSegment, setSelectedNewSegment, uniqueSegments, bulkSegmentMutation, onSegmentUpdate, selectedNewTags, setSelectedNewTags, bulkTagsMutation, onTagsUpdate, selectedNewCompany, setSelectedNewCompany, bulkCompanyMutation, onCompanyUpdate }) {
    if (!modalType) return null;
    const isLoading = modalType === "segment" && bulkSegmentMutation.isPending || modalType === "tags" && bulkTagsMutation.isPending || modalType === "company" && bulkCompanyMutation.isPending;
    const handleClose = ()=>{
        if (!isLoading) {
            onClose();
        }
    };
    const getTitle = ()=>{
        switch(modalType){
            case "segment":
                return "Reassign Segment";
            case "tags":
                return "Update Tags";
            case "company":
                return "Reassign Company";
            default:
                return "";
        }
    };
    const count = selectedCount;
    const contactText = count === 1 ? "contact" : "contacts";
    const handleUpdate = ()=>{
        if (modalType === "segment") {
            const newSegment = selectedNewSegment.trim() || null;
            onSegmentUpdate(newSegment);
            setSelectedNewSegment("");
        } else if (modalType === "tags") {
            onTagsUpdate(selectedNewTags);
            setSelectedNewTags("");
        } else if (modalType === "company") {
            const newCompany = selectedNewCompany.trim() || null;
            onCompanyUpdate(newCompany);
            setSelectedNewCompany("");
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        isOpen: modalType !== null,
        onClose: handleClose,
        title: getTitle(),
        closeOnBackdropClick: !isLoading,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-theme-darkest",
                    children: [
                        "Update the",
                        " ",
                        modalType === "segment" && "segment",
                        modalType === "tags" && "tags",
                        modalType === "company" && "company",
                        " ",
                        "for",
                        " ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                            className: "font-semibold text-theme-darkest",
                            children: count
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                            lineNumber: 128,
                            columnNumber: 11
                        }, this),
                        " ",
                        "selected ",
                        contactText,
                        "."
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                    lineNumber: 122,
                    columnNumber: 9
                }, this),
                isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-3",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "animate-spin h-5 w-5 text-blue-600",
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "none",
                                viewBox: "0 0 24 24",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                        className: "opacity-25",
                                        cx: "12",
                                        cy: "12",
                                        r: "10",
                                        stroke: "currentColor",
                                        strokeWidth: "4"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                        lineNumber: 141,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        className: "opacity-75",
                                        fill: "currentColor",
                                        d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                        lineNumber: 149,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                lineNumber: 135,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-sm font-medium text-theme-darkest",
                                children: "Updating contacts..."
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                lineNumber: 155,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                        lineNumber: 134,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                    lineNumber: 133,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        modalType === "segment" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-sm font-medium text-theme-darkest mb-2",
                                    children: "New Segment"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                    lineNumber: 164,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$SegmentSelect$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    value: selectedNewSegment || null,
                                    onChange: (value)=>setSelectedNewSegment(value || ""),
                                    existingSegments: uniqueSegments,
                                    placeholder: "Enter or select segment..."
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                    lineNumber: 167,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-2 text-xs text-theme-dark",
                                    children: 'Select an existing segment from the dropdown, or type a new segment name to create it. Choose "No Segment" to clear.'
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                    lineNumber: 173,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                            lineNumber: 163,
                            columnNumber: 15
                        }, this),
                        modalType === "tags" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-sm font-medium text-theme-darkest mb-2",
                                    children: "Tags (comma-separated)"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                    lineNumber: 182,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    type: "text",
                                    value: selectedNewTags,
                                    onChange: (e)=>setSelectedNewTags(e.target.value),
                                    placeholder: "tag1, tag2, tag3",
                                    className: "text-theme-darker"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                    lineNumber: 185,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-2 text-xs text-theme-dark",
                                    children: "Enter tags separated by commas. This will replace all existing tags on the selected contacts. Leave empty to remove all tags."
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                    lineNumber: 192,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                            lineNumber: 181,
                            columnNumber: 15
                        }, this),
                        modalType === "company" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-sm font-medium text-theme-darkest mb-2",
                                    children: "Company Name"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                    lineNumber: 201,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    type: "text",
                                    value: selectedNewCompany,
                                    onChange: (e)=>setSelectedNewCompany(e.target.value),
                                    placeholder: "Enter company name...",
                                    className: "text-theme-darker"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                    lineNumber: 204,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-2 text-xs text-theme-dark",
                                    children: "Enter a company name to assign to all selected contacts. Leave empty to clear the company field."
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                    lineNumber: 211,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                            lineNumber: 200,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-end gap-3 pt-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: handleClose,
                                    disabled: isLoading,
                                    variant: "outline",
                                    size: "sm",
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                    lineNumber: 218,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: handleUpdate,
                                    disabled: isLoading,
                                    loading: isLoading,
                                    size: "sm",
                                    children: [
                                        modalType === "segment" && "Update Segment",
                                        modalType === "tags" && "Update Tags",
                                        modalType === "company" && "Update Company"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                                    lineNumber: 226,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
                            lineNumber: 217,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
            lineNumber: 121,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/contacts/_components/BulkActionModal.tsx",
        lineNumber: 115,
        columnNumber: 5
    }, this);
}
_c = BulkActionModal;
var _c;
__turbopack_context__.k.register(_c, "BulkActionModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactsBulkActions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BulkActionsBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/BulkActionsBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$BulkActionModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/contacts/_components/BulkActionModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/contacts/_components/ContactsFilterContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/error-reporting/types.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function ContactsBulkActions({ userId, contacts }) {
    _s();
    const [modalType, setModalType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedNewSegment, setSelectedNewSegment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedNewTags, setSelectedNewTags] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedNewCompany, setSelectedNewCompany] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const { filteredContacts, selectedContactIds, setSelectedContactIds, showArchived } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactsFilter"])();
    // Use mutation hooks for bulk operations
    const bulkArchiveMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBulkArchiveContacts"])();
    const bulkSegmentMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBulkUpdateSegments"])();
    const bulkTagsMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBulkUpdateTags"])();
    const bulkCompanyMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBulkUpdateCompanies"])();
    // Get unique segments from all contacts for the bulk update dropdown
    const uniqueSegments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ContactsBulkActions.useMemo[uniqueSegments]": ()=>Array.from(new Set(contacts.map({
                "ContactsBulkActions.useMemo[uniqueSegments]": (c)=>c.segment
            }["ContactsBulkActions.useMemo[uniqueSegments]"]).filter(Boolean))).sort()
    }["ContactsBulkActions.useMemo[uniqueSegments]"], [
        contacts
    ]);
    const handleBulkSegmentUpdate = async (newSegment)=>{
        if (!userId || selectedContactIds.size === 0) return;
        const contactIdsArray = Array.from(selectedContactIds);
        bulkSegmentMutation.mutate({
            contactIds: contactIdsArray,
            segment: newSegment
        }, {
            onSuccess: (result)=>{
                if (result.errors > 0) {
                    alert(`Updated ${result.success} contact(s), but ${result.errors} failed. Check console for details.`);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportMessage"])("Bulk update errors occurred", __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorLevel"].WARNING, {
                        tags: {
                            component: "ContactsBulkActions"
                        },
                        extra: {
                            errorDetails: result.errorDetails
                        }
                    });
                } else {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportMessage"])(`Successfully updated ${result.success} contact(s)`, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorLevel"].INFO, {
                        tags: {
                            component: "ContactsBulkActions"
                        }
                    });
                }
                setSelectedContactIds(new Set());
                setModalType(null);
                setSelectedNewSegment("");
            },
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk segment update",
                    tags: {
                        component: "ContactsBulkActions"
                    }
                });
                alert("Failed to update contacts. Please try again.");
            }
        });
    };
    const handleBulkTagsUpdate = async (tagsString)=>{
        if (!userId || selectedContactIds.size === 0) return;
        // Parse comma-separated tags
        const tags = tagsString.split(",").map((tag)=>tag.trim()).filter((tag)=>tag.length > 0);
        const contactIdsArray = Array.from(selectedContactIds);
        bulkTagsMutation.mutate({
            contactIds: contactIdsArray,
            tags
        }, {
            onSuccess: (result)=>{
                if (result.errors > 0) {
                    alert(`Updated ${result.success} contact(s), but ${result.errors} failed. Check console for details.`);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportMessage"])("Bulk tag update errors occurred", __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorLevel"].WARNING, {
                        tags: {
                            component: "ContactsBulkActions"
                        },
                        extra: {
                            errorDetails: result.errorDetails
                        }
                    });
                } else {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportMessage"])(`Successfully updated ${result.success} contact(s)`, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorLevel"].INFO, {
                        tags: {
                            component: "ContactsBulkActions"
                        }
                    });
                }
                setSelectedContactIds(new Set());
                setModalType(null);
                setSelectedNewTags("");
            },
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk tag update",
                    tags: {
                        component: "ContactsBulkActions"
                    }
                });
                alert("Failed to update contacts. Please try again.");
            }
        });
    };
    const handleBulkCompanyUpdate = async (newCompany)=>{
        if (!userId || selectedContactIds.size === 0) return;
        const contactIdsArray = Array.from(selectedContactIds);
        bulkCompanyMutation.mutate({
            contactIds: contactIdsArray,
            company: newCompany
        }, {
            onSuccess: (result)=>{
                if (result.errors > 0) {
                    alert(`Updated ${result.success} contact(s), but ${result.errors} failed. Check console for details.`);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportMessage"])("Bulk company update errors occurred", __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorLevel"].WARNING, {
                        tags: {
                            component: "ContactsBulkActions"
                        },
                        extra: {
                            errorDetails: result.errorDetails
                        }
                    });
                } else {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportMessage"])(`Successfully updated ${result.success} contact(s)`, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorLevel"].INFO, {
                        tags: {
                            component: "ContactsBulkActions"
                        }
                    });
                }
                setSelectedContactIds(new Set());
                setModalType(null);
                setSelectedNewCompany("");
            },
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk company update",
                    tags: {
                        component: "ContactsBulkActions"
                    }
                });
                alert("Failed to update contacts. Please try again.");
            }
        });
    };
    const handleBulkArchive = async (archived)=>{
        if (!userId || selectedContactIds.size === 0) return;
        const contactIdsArray = Array.from(selectedContactIds);
        bulkArchiveMutation.mutate({
            contactIds: contactIdsArray,
            archived
        }, {
            onSuccess: (result)=>{
                if (result.errors > 0) {
                    alert(`${archived ? "Archived" : "Unarchived"} ${result.success} contact(s), but ${result.errors} failed. Check console for details.`);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportMessage"])("Bulk archive errors occurred", __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorLevel"].WARNING, {
                        tags: {
                            component: "ContactsBulkActions"
                        },
                        extra: {
                            errorDetails: result.errorDetails
                        }
                    });
                } else {
                    // Success - clear selection
                    setSelectedContactIds(new Set());
                }
            },
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk archiving contacts",
                    tags: {
                        component: "ContactsBulkActions"
                    },
                    extra: {
                        archived
                    }
                });
                alert(`Failed to ${archived ? "archive" : "unarchive"} contacts. Please try again.`);
            }
        });
    };
    const handleModalClose = ()=>{
        setModalType(null);
        if (modalType === "segment") setSelectedNewSegment("");
        if (modalType === "tags") setSelectedNewTags("");
        if (modalType === "company") setSelectedNewCompany("");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            selectedContactIds.size > 0 && filteredContacts.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$BulkActionsBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                selectedCount: selectedContactIds.size,
                itemLabel: "contact",
                actions: [
                    {
                        label: "Reassign Segment",
                        onClick: ()=>setModalType("segment"),
                        variant: "primary",
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                                lineNumber: 221,
                                columnNumber: 19
                            }, void 0)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                            lineNumber: 220,
                            columnNumber: 17
                        }, void 0)
                    },
                    {
                        label: "Reassign Company",
                        onClick: ()=>setModalType("company"),
                        variant: "primary",
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                                lineNumber: 236,
                                columnNumber: 19
                            }, void 0)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                            lineNumber: 235,
                            columnNumber: 17
                        }, void 0)
                    },
                    {
                        label: "Update Tags",
                        onClick: ()=>setModalType("tags"),
                        variant: "primary",
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                                lineNumber: 251,
                                columnNumber: 19
                            }, void 0)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                            lineNumber: 250,
                            columnNumber: 17
                        }, void 0)
                    },
                    ...!showArchived ? [
                        {
                            label: "Archive",
                            onClick: ()=>handleBulkArchive(true),
                            variant: "outline",
                            disabled: bulkArchiveMutation.isPending,
                            loading: bulkArchiveMutation.isPending,
                            showCount: true,
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-4 h-4",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                                    lineNumber: 271,
                                    columnNumber: 25
                                }, void 0)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                                lineNumber: 270,
                                columnNumber: 23
                            }, void 0)
                        }
                    ] : [
                        {
                            label: "Unarchive",
                            onClick: ()=>handleBulkArchive(false),
                            variant: "secondary",
                            disabled: bulkArchiveMutation.isPending,
                            loading: bulkArchiveMutation.isPending,
                            showCount: true,
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-4 h-4",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                                    lineNumber: 291,
                                    columnNumber: 25
                                }, void 0)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                                lineNumber: 290,
                                columnNumber: 23
                            }, void 0)
                        }
                    ]
                ]
            }, void 0, false, {
                fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                lineNumber: 211,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$BulkActionModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                modalType: modalType,
                onClose: handleModalClose,
                selectedCount: selectedContactIds.size,
                selectedNewSegment: selectedNewSegment,
                setSelectedNewSegment: setSelectedNewSegment,
                uniqueSegments: uniqueSegments,
                bulkSegmentMutation: bulkSegmentMutation,
                onSegmentUpdate: handleBulkSegmentUpdate,
                selectedNewTags: selectedNewTags,
                setSelectedNewTags: setSelectedNewTags,
                bulkTagsMutation: bulkTagsMutation,
                onTagsUpdate: handleBulkTagsUpdate,
                selectedNewCompany: selectedNewCompany,
                setSelectedNewCompany: setSelectedNewCompany,
                bulkCompanyMutation: bulkCompanyMutation,
                onCompanyUpdate: handleBulkCompanyUpdate
            }, void 0, false, {
                fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
                lineNumber: 306,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx",
        lineNumber: 208,
        columnNumber: 5
    }, this);
}
_s(ContactsBulkActions, "hZK6IFv1wGwx8QIg8GEXmDF9YyU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactsFilter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBulkArchiveContacts"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBulkUpdateSegments"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBulkUpdateTags"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBulkUpdateCompanies"]
    ];
});
_c = ContactsBulkActions;
var _c;
__turbopack_context__.k.register(_c, "ContactsBulkActions");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/contacts/ContactsPageClient.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactsPageClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ExportContactsButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ExportContactsButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactsFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ContactsFilter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContacts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContacts.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/contacts/_components/ContactsFilterContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/contacts/_components/ContactsGrid.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsBulkActions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/contacts/_components/ContactsBulkActions.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
const ITEMS_PER_PAGE = 20;
function ContactsPageHeader({ contacts }) {
    _s();
    const { filteredContacts, hasActiveFilters } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactsFilter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-4xl font-bold text-theme-darkest mb-2",
                        children: "Contacts"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                        lineNumber: 34,
                        columnNumber: 9
                    }, this),
                    contacts.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-theme-dark text-lg",
                        children: "No contacts yet"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                        lineNumber: 36,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-theme-dark text-lg",
                        children: [
                            filteredContacts.length,
                            " of ",
                            contacts.length,
                            " ",
                            contacts.length === 1 ? "contact" : "contacts",
                            hasActiveFilters && " (filtered)"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                        lineNumber: 38,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-3 xl:shrink-0 w-full sm:w-auto",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ExportContactsButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        contacts: filteredContacts
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/contacts/new",
                        className: "w-full sm:w-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            size: "sm",
                            fullWidth: true,
                            className: "whitespace-nowrap shadow-[rgba(34,32,29,0.1)_0px_2px_4px] ",
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-5 h-5",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M12 4v16m8-8H4"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                                    lineNumber: 56,
                                    columnNumber: 17
                                }, void 0)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                                lineNumber: 55,
                                columnNumber: 15
                            }, void 0),
                            children: "Add Contact"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                            lineNumber: 49,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_s(ContactsPageHeader, "ouQ6kaZgl4/SDnVNtEmk4FUGriM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactsFilter"]
    ];
});
_c = ContactsPageHeader;
function ContactsPageClient({ userId }) {
    _s1();
    const { data: contactsData = [], isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContacts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContacts"])(userId);
    const contacts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ContactsPageClient.useMemo[contacts]": ()=>{
            return contactsData.map({
                "ContactsPageClient.useMemo[contacts]": (contact)=>({
                        ...contact,
                        id: contact.contactId,
                        displayName: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contact),
                        initials: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(contact)
                    })
            }["ContactsPageClient.useMemo[contacts]"]);
        }
    }["ContactsPageClient.useMemo[contacts]"], [
        contactsData
    ]);
    // When loading (suspense mode), render structure but let ThemedSuspense show loading
    // We need to provide context even when loading so components don't crash
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsFilterContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContactsFilterProvider"], {
        contacts: contacts,
        itemsPerPage: ITEMS_PER_PAGE,
        isLoading: isLoading,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContactsPageHeader, {
                    contacts: contacts
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                    lineNumber: 91,
                    columnNumber: 9
                }, this),
                !isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactsFilter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    contacts: contacts
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                    lineNumber: 92,
                    columnNumber: 24
                }, this),
                !isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsBulkActions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    userId: userId,
                    contacts: contacts
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                    lineNumber: 93,
                    columnNumber: 24
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$_components$2f$ContactsGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    userId: userId
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
            lineNumber: 90,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/contacts/ContactsPageClient.tsx",
        lineNumber: 89,
        columnNumber: 5
    }, this);
}
_s1(ContactsPageClient, "DwD5YYTMa7du7SNQCxeJalxgSzg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContacts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContacts"]
    ];
});
_c1 = ContactsPageClient;
var _c, _c1;
__turbopack_context__.k.register(_c, "ContactsPageHeader");
__turbopack_context__.k.register(_c1, "ContactsPageClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/contacts/_components/ContactsPageClientWrapper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactsPageClientWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useAuth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$ContactsPageClient$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/contacts/ContactsPageClient.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ContactsPageClientWrapper({ userId }) {
    _s();
    const { user, loading: authLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    // Determine effective userId with stable cache key:
    // 1. If userId prop is provided and non-empty (from SSR), use it immediately
    // 2. If userId is empty/missing, wait for auth to finish loading, then use user?.uid
    //    (Don't use empty string as cache key - it will change when auth loads)
    // This ensures cache keys don't change mid-render
    const effectiveUserId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ContactsPageClientWrapper.useMemo[effectiveUserId]": ()=>{
            // If SSR provided a userId, use it (even if empty string - that's intentional)
            if (userId && userId.trim() !== "") {
                return userId;
            }
            // If no userId from SSR, wait for auth to load, then use user?.uid
            // Don't use empty string as intermediate value - it causes cache key changes
            if (authLoading) {
                // Still loading - return empty string temporarily (query will be disabled)
                return "";
            }
            // Auth loaded - use user?.uid or empty string if no user
            return user?.uid || "";
        }
    }["ContactsPageClientWrapper.useMemo[effectiveUserId]"], [
        userId,
        authLoading,
        user?.uid
    ]);
    // Pass userId directly - child component handles all data fetching
    // This ensures consistent cache keys and avoids stale initialContacts
    // useContacts hook will be disabled if userId is empty (enabled: !!userId)
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f$ContactsPageClient$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        userId: effectiveUserId
    }, void 0, false, {
        fileName: "[project]/app/(crm)/contacts/_components/ContactsPageClientWrapper.tsx",
        lineNumber: 32,
        columnNumber: 10
    }, this);
}
_s(ContactsPageClientWrapper, "pcRtBF8JqZJ3x8DpUdVcwaizk7c=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
_c = ContactsPageClientWrapper;
var _c;
__turbopack_context__.k.register(_c, "ContactsPageClientWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=bb2253e9-db81-86a6-8fcd-e4e744dd3c2c
//# sourceMappingURL=_1176f57d._.js.map