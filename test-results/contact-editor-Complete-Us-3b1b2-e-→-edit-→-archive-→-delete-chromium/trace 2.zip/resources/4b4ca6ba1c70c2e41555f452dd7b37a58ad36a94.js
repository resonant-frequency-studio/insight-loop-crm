;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="96b6be41-26b1-2cca-9836-02e5b5f16575")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/hooks/useContactMutations.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useArchiveContact",
    ()=>useArchiveContact,
    "useBulkArchiveContacts",
    ()=>useBulkArchiveContacts,
    "useBulkUpdateCompanies",
    ()=>useBulkUpdateCompanies,
    "useBulkUpdateSegments",
    ()=>useBulkUpdateSegments,
    "useBulkUpdateTags",
    ()=>useBulkUpdateTags,
    "useCreateContact",
    ()=>useCreateContact,
    "useDeleteContact",
    ()=>useDeleteContact,
    "useUpdateContact",
    ()=>useUpdateContact,
    "useUpdateTouchpointStatus",
    ()=>useUpdateTouchpointStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature();
"use client";
;
;
function useCreateContact() {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useCreateContact.useMutation": async (contactData)=>{
                const response = await fetch("/api/contacts", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(contactData)
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useCreateContact.useMutation": ()=>({})
                    }["useCreateContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to create contact");
                }
                const data = await response.json();
                return data.contactId;
            }
        }["useCreateContact.useMutation"],
        onSuccess: {
            "useCreateContact.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useCreateContact.useMutation"],
        onError: {
            "useCreateContact.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Creating contact",
                    tags: {
                        component: "useCreateContact"
                    }
                });
            }
        }["useCreateContact.useMutation"]
    });
}
_s(useCreateContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useUpdateContact(userId) {
    _s1();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    // Defensive contact matcher - handles contactId, id, or _id fields
    const isSameContact = (c, contactId)=>{
        return c.contactId === contactId || c.id === contactId || c._id === contactId;
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useUpdateContact.useMutation": async ({ contactId, updates })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(updates)
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useUpdateContact.useMutation": ()=>({})
                    }["useUpdateContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to update contact");
                }
                const data = await response.json();
                return data.contact; // API now returns { contact: Contact }
            }
        }["useUpdateContact.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update both detail and ALL list caches so UI feels instant
     */ onMutate: {
            "useUpdateContact.useMutation": async ({ contactId, updates })=>{
                // Cancel all related queries
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact"
                    ],
                    exact: false
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                });
                // Snapshot previous detail state (for this specific user+contact, if such a query exists)
                const prevDetail = userId ? queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]) : undefined;
                // Snapshot ALL contacts lists (regardless of key shape)
                const prevLists = {};
                queryClient.getQueryCache().findAll({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                }).forEach({
                    "useUpdateContact.useMutation": (q)=>{
                        const key = JSON.stringify(q.queryKey);
                        const data = q.state.data;
                        if (data) prevLists[key] = data;
                    }
                }["useUpdateContact.useMutation"]);
                // Optimistically update detail (if userId provided)
                if (userId) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        contactId
                    ], {
                        "useUpdateContact.useMutation": (old)=>old ? {
                                ...old,
                                ...updates
                            } : old
                    }["useUpdateContact.useMutation"]);
                }
                // Optimistically update ALL contacts lists (regardless of key shape)
                queryClient.setQueriesData({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                }, {
                    "useUpdateContact.useMutation": (old)=>{
                        if (!old || !Array.isArray(old)) return old;
                        return old.map({
                            "useUpdateContact.useMutation": (c)=>isSameContact(c, contactId) ? {
                                    ...c,
                                    ...updates
                                } : c
                        }["useUpdateContact.useMutation"]);
                    }
                }["useUpdateContact.useMutation"]);
                return {
                    prevDetail,
                    prevLists
                };
            }
        }["useUpdateContact.useMutation"],
        /**
     * SUCCESS — update detail only & delay list invalidation
     * Firestore eventual consistency means list queries might not see the update immediately
     * So we invalidate after a delay to let Firestore propagate the change
     */ onSuccess: {
            "useUpdateContact.useMutation": (updatedContact, variables)=>{
                const { contactId } = variables;
                // Update detail cache with actual server result
                if (userId) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        contactId
                    ], updatedContact);
                }
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                });
                // Invalidate dashboard stats to ensure consistency
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ],
                    exact: false
                });
            }
        }["useUpdateContact.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useUpdateContact.useMutation": (error, variables, context)=>{
                // Restore detail (if userId provided)
                if (userId && context?.prevDetail) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prevDetail);
                }
                // Restore ALL contacts lists
                if (context?.prevLists) {
                    for (const [key, data] of Object.entries(context.prevLists)){
                        queryClient.setQueryData(JSON.parse(key), data);
                    }
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating contact",
                    tags: {
                        component: "useUpdateContact"
                    }
                });
            }
        }["useUpdateContact.useMutation"]
    });
}
_s1(useUpdateContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useDeleteContact() {
    _s2();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useDeleteContact.useMutation": async (contactId)=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}`, {
                    method: "DELETE"
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useDeleteContact.useMutation": ()=>({})
                    }["useDeleteContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to delete contact");
                }
                return response.json();
            }
        }["useDeleteContact.useMutation"],
        onSuccess: {
            "useDeleteContact.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "action-items"
                    ]
                });
            }
        }["useDeleteContact.useMutation"],
        onError: {
            "useDeleteContact.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Deleting contact",
                    tags: {
                        component: "useDeleteContact"
                    }
                });
            }
        }["useDeleteContact.useMutation"]
    });
}
_s2(useDeleteContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useArchiveContact(userId) {
    _s3();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useArchiveContact.useMutation": async ({ contactId, archived })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}/archive`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        archived
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useArchiveContact.useMutation": ()=>({})
                    }["useArchiveContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to archive contact");
                }
                return response.json();
            }
        }["useArchiveContact.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update the cache so UI feels instant
     */ onMutate: {
            "useArchiveContact.useMutation": async ({ contactId, archived })=>{
                if (!userId) return;
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                // Snapshot previous value for rollback
                const prev = queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]);
                // Update cache immediately - UI updates instantly
                queryClient.setQueryData([
                    "contact",
                    userId,
                    contactId
                ], {
                    "useArchiveContact.useMutation": (old)=>{
                        if (!old) return old;
                        return {
                            ...old,
                            archived
                        };
                    }
                }["useArchiveContact.useMutation"]);
                // Also update in contacts list
                queryClient.setQueryData([
                    "contacts",
                    userId
                ], {
                    "useArchiveContact.useMutation": (old)=>{
                        if (!old) return old;
                        return old.map({
                            "useArchiveContact.useMutation": (c)=>c.contactId === contactId ? {
                                    ...c,
                                    archived
                                } : c
                        }["useArchiveContact.useMutation"]);
                    }
                }["useArchiveContact.useMutation"]);
                return {
                    prev
                };
            }
        }["useArchiveContact.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useArchiveContact.useMutation": (error, variables, context)=>{
                if (userId && context?.prev) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prev);
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Archiving contact",
                    tags: {
                        component: "useArchiveContact"
                    }
                });
            }
        }["useArchiveContact.useMutation"],
        onSettled: {
            "useArchiveContact.useMutation": ()=>{
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useArchiveContact.useMutation"]
    });
}
_s3(useArchiveContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useUpdateTouchpointStatus(userId) {
    _s4();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useUpdateTouchpointStatus.useMutation": async ({ contactId, status, reason })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}/touchpoint-status`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        status,
                        reason
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useUpdateTouchpointStatus.useMutation": ()=>({})
                    }["useUpdateTouchpointStatus.useMutation"]);
                    // Throw user-friendly error message - will be extracted by component
                    const errorMessage = errorData.error || "Failed to update touchpoint status. Please try again.";
                    throw new Error(errorMessage);
                }
                const data = await response.json();
                return {
                    ...data,
                    contactId,
                    status,
                    reason
                };
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update the cache so UI feels instant
     */ onMutate: {
            "useUpdateTouchpointStatus.useMutation": async ({ contactId, status, reason })=>{
                if (!userId) return;
                // Cancel outgoing refetches to avoid overwriting optimistic update
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact",
                        userId,
                        contactId
                    ]
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts",
                        userId
                    ]
                });
                // Snapshot previous value for rollback
                const prev = queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]);
                // Update cache immediately - UI updates instantly
                queryClient.setQueryData([
                    "contact",
                    userId,
                    contactId
                ], {
                    "useUpdateTouchpointStatus.useMutation": (old)=>{
                        if (!old) return old;
                        return {
                            ...old,
                            touchpointStatus: status,
                            touchpointStatusUpdatedAt: status !== null ? new Date().toISOString() : null,
                            touchpointStatusReason: reason !== undefined ? reason : old.touchpointStatusReason
                        };
                    }
                }["useUpdateTouchpointStatus.useMutation"]);
                // Also update in contacts list
                queryClient.setQueryData([
                    "contacts",
                    userId
                ], {
                    "useUpdateTouchpointStatus.useMutation": (old)=>{
                        if (!old) return old;
                        return old.map({
                            "useUpdateTouchpointStatus.useMutation": (contact)=>contact.contactId === contactId ? {
                                    ...contact,
                                    touchpointStatus: status,
                                    touchpointStatusUpdatedAt: status !== null ? new Date().toISOString() : null,
                                    touchpointStatusReason: reason !== undefined ? reason : contact.touchpointStatusReason
                                } : contact
                        }["useUpdateTouchpointStatus.useMutation"]);
                    }
                }["useUpdateTouchpointStatus.useMutation"]);
                return {
                    prev
                };
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useUpdateTouchpointStatus.useMutation": (error, variables, context)=>{
                if (userId && context?.prev) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prev);
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating touchpoint status",
                    tags: {
                        component: "useUpdateTouchpointStatus"
                    }
                });
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * Invalidate after success to ensure server consistency
     */ onSettled: {
            "useUpdateTouchpointStatus.useMutation": (_data, _error, vars)=>{
                if (!userId) return;
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact",
                        userId,
                        vars.contactId
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts",
                        userId
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useUpdateTouchpointStatus.useMutation"]
    });
}
_s4(useUpdateTouchpointStatus, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkArchiveContacts() {
    _s5();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkArchiveContacts.useMutation": async ({ contactIds, archived })=>{
                const response = await fetch("/api/contacts/bulk-archive", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        archived
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkArchiveContacts.useMutation": ()=>({})
                    }["useBulkArchiveContacts.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk archive contacts");
                }
                return response.json();
            }
        }["useBulkArchiveContacts.useMutation"],
        onSuccess: {
            "useBulkArchiveContacts.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkArchiveContacts.useMutation"],
        onError: {
            "useBulkArchiveContacts.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk archiving contacts",
                    tags: {
                        component: "useBulkArchiveContacts"
                    }
                });
            }
        }["useBulkArchiveContacts.useMutation"]
    });
}
_s5(useBulkArchiveContacts, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateSegments() {
    _s6();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateSegments.useMutation": async ({ contactIds, segment })=>{
                const response = await fetch("/api/contacts/bulk-segment", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        segment
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateSegments.useMutation": ()=>({})
                    }["useBulkUpdateSegments.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update segments");
                }
                return response.json();
            }
        }["useBulkUpdateSegments.useMutation"],
        onSuccess: {
            "useBulkUpdateSegments.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateSegments.useMutation"],
        onError: {
            "useBulkUpdateSegments.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact segments",
                    tags: {
                        component: "useBulkUpdateSegments"
                    }
                });
            }
        }["useBulkUpdateSegments.useMutation"]
    });
}
_s6(useBulkUpdateSegments, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateTags() {
    _s7();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateTags.useMutation": async ({ contactIds, tags })=>{
                const response = await fetch("/api/contacts/bulk-tags", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        tags
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateTags.useMutation": ()=>({})
                    }["useBulkUpdateTags.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update tags");
                }
                return response.json();
            }
        }["useBulkUpdateTags.useMutation"],
        onSuccess: {
            "useBulkUpdateTags.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateTags.useMutation"],
        onError: {
            "useBulkUpdateTags.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact tags",
                    tags: {
                        component: "useBulkUpdateTags"
                    }
                });
            }
        }["useBulkUpdateTags.useMutation"]
    });
}
_s7(useBulkUpdateTags, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateCompanies() {
    _s8();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateCompanies.useMutation": async ({ contactIds, company })=>{
                const response = await fetch("/api/contacts/bulk-company", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        company
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateCompanies.useMutation": ()=>({})
                    }["useBulkUpdateCompanies.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update companies");
                }
                return response.json();
            }
        }["useBulkUpdateCompanies.useMutation"],
        onSuccess: {
            "useBulkUpdateCompanies.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateCompanies.useMutation"],
        onError: {
            "useBulkUpdateCompanies.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact companies",
                    tags: {
                        component: "useBulkUpdateCompanies"
                    }
                });
            }
        }["useBulkUpdateCompanies.useMutation"]
    });
}
_s8(useBulkUpdateCompanies, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useNewContactPage.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useNewContactPage",
    ()=>useNewContactPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useAuth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const initialFormState = {
    primaryEmail: "",
    firstName: "",
    lastName: "",
    company: "",
    notes: "",
    tags: [],
    segment: "",
    leadSource: "",
    engagementScore: null,
    summary: "",
    nextTouchpointDate: null,
    nextTouchpointMessage: ""
};
function useNewContactPage() {
    _s();
    const { user, loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const createContactMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCreateContact"])();
    const [form, setForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialFormState);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [checkingSession, setCheckingSession] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [hasValidSession, setHasValidSession] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const sessionCheckRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Handle auth redirect
    // In test mode (E2E tests), allow rendering without Firebase client auth if session cookie exists
    // Check for session cookie asynchronously - don't redirect immediately to give tests time
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useNewContactPage.useEffect": ()=>{
            // Clear any existing timeout
            if (sessionCheckRef.current) {
                clearTimeout(sessionCheckRef.current);
                sessionCheckRef.current = null;
            }
            if (!loading && !user) {
                // Start checking session - use setTimeout to defer setState call
                sessionCheckRef.current = setTimeout({
                    "useNewContactPage.useEffect": ()=>{
                        setCheckingSession(true);
                        // Give a small delay to allow session cookie check to complete in test mode
                        setTimeout({
                            "useNewContactPage.useEffect": async ()=>{
                                // Check for session cookie before redirecting (for E2E tests)
                                try {
                                    const response = await fetch("/api/auth/check", {
                                        credentials: "include"
                                    });
                                    // If session check succeeds, allow rendering (test mode with session cookie)
                                    if (response.ok) {
                                        setHasValidSession(true);
                                        setCheckingSession(false);
                                        return;
                                    }
                                } catch  {
                                // If check fails, continue with redirect
                                }
                                // No valid session, redirect to login
                                setHasValidSession(false);
                                setCheckingSession(false);
                                router.push("/login");
                            }
                        }["useNewContactPage.useEffect"], 1000); // 1 second delay to allow test session cookie to be recognized
                    }
                }["useNewContactPage.useEffect"], 0);
                return ({
                    "useNewContactPage.useEffect": ()=>{
                        if (sessionCheckRef.current) {
                            clearTimeout(sessionCheckRef.current);
                            sessionCheckRef.current = null;
                        }
                    }
                })["useNewContactPage.useEffect"];
            } else if (user) {
                // User is set, no need to check session
                // This setState is intentional cleanup when user changes - safe to do synchronously
                // eslint-disable-next-line react-hooks/set-state-in-effect
                setHasValidSession(null);
                setCheckingSession(false);
            }
        }
    }["useNewContactPage.useEffect"], [
        user,
        loading,
        router
    ]);
    const updateField = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useNewContactPage.useCallback[updateField]": (field, value)=>{
            setForm({
                "useNewContactPage.useCallback[updateField]": (prev)=>({
                        ...prev,
                        [field]: value
                    })
            }["useNewContactPage.useCallback[updateField]"]);
            // Clear error when user starts typing
            if (error) setError(null);
        }
    }["useNewContactPage.useCallback[updateField]"], [
        error
    ]);
    const validateForm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useNewContactPage.useCallback[validateForm]": ()=>{
            if (!form.primaryEmail?.trim()) {
                setError("Email is required");
                return false;
            }
            return true;
        }
    }["useNewContactPage.useCallback[validateForm]"], [
        form.primaryEmail
    ]);
    const prepareContactData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useNewContactPage.useCallback[prepareContactData]": ()=>{
            const email = form.primaryEmail.trim().toLowerCase();
            return {
                primaryEmail: email,
                firstName: form.firstName?.trim() || null,
                lastName: form.lastName?.trim() || null,
                company: form.company?.trim() || null,
                notes: form.notes?.trim() || null,
                tags: form.tags || [],
                segment: form.segment?.trim() || null,
                leadSource: form.leadSource?.trim() || null,
                engagementScore: form.engagementScore || null,
                summary: form.summary?.trim() || null,
                nextTouchpointDate: form.nextTouchpointDate && typeof form.nextTouchpointDate === "string" ? form.nextTouchpointDate.trim() || null : null,
                nextTouchpointMessage: form.nextTouchpointMessage?.trim() || null
            };
        }
    }["useNewContactPage.useCallback[prepareContactData]"], [
        form
    ]);
    const handleSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useNewContactPage.useCallback[handleSave]": ()=>{
            // Remove the user check - let the API handle authentication
            // In test mode, the session cookie should work even if Firebase client auth isn't initialized
            // If auth fails, the API will return an error and we'll display it
            if (!validateForm()) {
                return;
            }
            setError(null);
            const contactData = prepareContactData();
            createContactMutation.mutate(contactData, {
                onSuccess: {
                    "useNewContactPage.useCallback[handleSave]": ()=>{
                        router.push("/contacts");
                    }
                }["useNewContactPage.useCallback[handleSave]"],
                onError: {
                    "useNewContactPage.useCallback[handleSave]": (err)=>{
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(err, {
                            context: "Creating new contact in useNewContactPage",
                            tags: {
                                component: "useNewContactPage",
                                email: form.primaryEmail
                            }
                        });
                        const errorMessage = err instanceof Error ? err.message : "Failed to create contact. Please try again.";
                        // If the error is auth-related, show a clearer message
                        if (errorMessage.includes("401") || errorMessage.includes("Unauthorized") || errorMessage.includes("must be logged in")) {
                            setError("You must be logged in to create a contact");
                        } else {
                            setError(errorMessage);
                        }
                    }
                }["useNewContactPage.useCallback[handleSave]"]
            });
        }
    }["useNewContactPage.useCallback[handleSave]"], [
        form,
        validateForm,
        prepareContactData,
        router,
        createContactMutation
    ]);
    const resetForm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useNewContactPage.useCallback[resetForm]": ()=>{
            setForm(initialFormState);
            setError(null);
        }
    }["useNewContactPage.useCallback[resetForm]"], []);
    return {
        // Auth state
        user,
        loading: loading || checkingSession,
        // Form state
        form,
        updateField,
        // Save state
        saving: createContactMutation.isPending,
        error,
        handleSave,
        // Actions
        resetForm,
        // Session check state (for test mode)
        hasValidSession
    };
}
_s(useNewContactPage, "BUa7/GZSdg5si46TuVyvJasQi3I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCreateContact"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Loading.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loading
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Loading() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center justify-center h-screen bg-neutral-200",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-gray-800",
            children: "Loading..."
        }, void 0, false, {
            fileName: "[project]/components/Loading.tsx",
            lineNumber: 4,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/Loading.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, this);
}
_c = Loading;
var _c;
__turbopack_context__.k.register(_c, "Loading");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Card
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Card({ children, className = "", padding = "md", hover = false }) {
    const paddingClasses = {
        none: "",
        sm: "p-3",
        md: "p-6",
        lg: "p-8",
        xl: "p-12",
        responsive: "p-3 xl:p-6"
    };
    const baseClasses = "bg-card-light rounded-sm shadow-[rgba(34,32,29,0.1)_0px_2px_4px] border border-theme-lighter";
    const paddingClass = padding === "none" || className.includes("p-") ? "" : paddingClasses[padding];
    const hoverClasses = hover ? "hover:shadow-[0px_6px_16px_rgba(0,0,0,0.15)] transition-shadow duration-200" : "";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${baseClasses} ${paddingClass} ${hoverClasses} ${className}`.trim(),
        children: children
    }, void 0, false, {
        fileName: "[project]/components/Card.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
_c = Card;
var _c;
__turbopack_context__.k.register(_c, "Card");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ContactsLink.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactsLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
function ContactsLink({ variant = "default", className = "", children = "Back to Contacts" }) {
    const baseClasses = "transition-colors duration-200 font-medium cursor-pointer";
    const variantClasses = {
        default: "flex items-center gap-2 px-4 py-2 text-theme-darkest hover:text-theme-medium rounded-sm",
        error: "inline-block px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-sm"
    };
    const iconSvg = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        className: "w-5 h-5",
        fill: "none",
        stroke: "currentColor",
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 2,
            d: "M10 19l-7-7m0 0l7-7m-7 7h18"
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/ContactsLink.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/_components/ContactsLink.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: "/contacts",
        className: `${baseClasses} ${variantClasses[variant]} ${className}`,
        children: [
            variant !== "error" && iconSvg,
            children
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/ContactsLink.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
}
_c = ContactsLink;
var _c;
__turbopack_context__.k.register(_c, "ContactsLink");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
/**
 * Reusable Input component with consistent styling
 * Provides consistent styling across all text input elements in the application
 */ const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = ({ className = "", ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        ref: ref,
        ...props,
        className: `w-full px-4 py-2 border border-theme-darker placeholder:text-foreground rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 ${className}`
    }, void 0, false, {
        fileName: "[project]/components/Input.tsx",
        lineNumber: 10,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Input;
Input.displayName = "Input";
const __TURBOPACK__default__export__ = Input;
var _c, _c1;
__turbopack_context__.k.register(_c, "Input$React.forwardRef");
__turbopack_context__.k.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Textarea.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Textarea
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Textarea({ className = "", ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
        ...props,
        className: `w-full px-4 py-3 border text-foreground placeholder:text-foreground border-gray-300 rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 resize-none ${className}`
    }, void 0, false, {
        fileName: "[project]/components/Textarea.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_c = Textarea;
var _c;
__turbopack_context__.k.register(_c, "Textarea");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/contacts/new/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NewContactPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useNewContactPage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useNewContactPage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Loading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Loading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactsLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ContactsLink.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function NewContactPage() {
    _s();
    const { user, loading, form, updateField, saving, error, handleSave, hasValidSession } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useNewContactPage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNewContactPage"])();
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Loading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/app/(crm)/contacts/new/page.tsx",
            lineNumber: 15,
            columnNumber: 12
        }, this);
    }
    // In production, require Firebase user (normal flow)
    // In test mode, allow rendering if session cookie check succeeded (hasValidSession === true)
    // Otherwise, don't render the form (prevents showing form to unauthenticated users)
    if (!user && hasValidSession !== true) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "xl:hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactsLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "default"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-4xl font-bold text-theme-darkest mb-2",
                                children: "Add New Contact"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                lineNumber: 35,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-theme-dark text-lg",
                                children: "Create a new contact in your CRM"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                lineNumber: 36,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                        lineNumber: 34,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hidden xl:block",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactsLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "default"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                            lineNumber: 39,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-50 border border-red-200 rounded-sm p-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-5 h-5 text-red-600",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                lineNumber: 53,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                            lineNumber: 47,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-red-800 font-medium",
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                            lineNumber: 60,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                    lineNumber: 46,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                lineNumber: 45,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 xl:grid-cols-3 gap-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "xl:col-span-1 space-y-6 order-1 xl:order-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            padding: "md",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-semibold text-theme-darkest mb-4",
                                    children: "Contact Details"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                    lineNumber: 70,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4 text-sm text-theme-dark",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            children: "Fill in the form fields to create a new contact. Email is required."
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                            lineNumber: 72,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            children: "Once saved, the contact will be added to your CRM and you can view and edit it from the contacts list."
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                            lineNumber: 73,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                    lineNumber: 71,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                        lineNumber: 67,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "xl:col-span-2 space-y-6 order-2 xl:order-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                padding: "md",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-lg font-semibold text-theme-darkest mb-4 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-5 h-5 text-gray-400",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                    lineNumber: 92,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 86,
                                                columnNumber: 15
                                            }, this),
                                            "Basic Information"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                        lineNumber: 85,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "new-contact-email",
                                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                                        children: [
                                                            "Email ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-red-500",
                                                                children: "*"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                                lineNumber: 104,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 103,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        id: "new-contact-email",
                                                        name: "new-contact-email",
                                                        type: "email",
                                                        value: form.primaryEmail || "",
                                                        onChange: (e)=>updateField("primaryEmail", e.target.value),
                                                        placeholder: "email@example.com",
                                                        required: true
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 106,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 102,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-2 gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                htmlFor: "new-contact-first-name",
                                                                className: "block text-sm font-medium text-theme-darker mb-2",
                                                                children: "First Name"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                                lineNumber: 118,
                                                                columnNumber: 19
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                id: "new-contact-first-name",
                                                                name: "new-contact-first-name",
                                                                value: form.firstName || "",
                                                                onChange: (e)=>updateField("firstName", e.target.value),
                                                                placeholder: "First Name"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                                lineNumber: 121,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 117,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                htmlFor: "new-contact-last-name",
                                                                className: "block text-sm font-medium text-theme-darker mb-2",
                                                                children: "Last Name"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                                lineNumber: 130,
                                                                columnNumber: 19
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                id: "new-contact-last-name",
                                                                name: "new-contact-last-name",
                                                                value: form.lastName || "",
                                                                onChange: (e)=>updateField("lastName", e.target.value),
                                                                placeholder: "Last Name"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                                lineNumber: 133,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 129,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 116,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "new-contact-company",
                                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                                        children: "Company"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 143,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        id: "new-contact-company",
                                                        name: "new-contact-company",
                                                        value: form.company || "",
                                                        onChange: (e)=>updateField("company", e.target.value),
                                                        placeholder: "Company"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 146,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 142,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                        lineNumber: 101,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                lineNumber: 84,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                padding: "md",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-lg font-semibold text-theme-darkest mb-4 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-5 h-5 text-gray-400",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                    lineNumber: 166,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 160,
                                                columnNumber: 15
                                            }, this),
                                            "CRM Information"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                        lineNumber: 159,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "new-contact-segment",
                                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                                        children: "Segment"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 177,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        id: "new-contact-segment",
                                                        value: form.segment || "",
                                                        onChange: (e)=>updateField("segment", e.target.value),
                                                        placeholder: "e.g., Enterprise, SMB, Individual"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 178,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 176,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "new-contact-lead-source",
                                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                                        children: "Lead Source"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 186,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        id: "new-contact-lead-source",
                                                        value: form.leadSource || "",
                                                        onChange: (e)=>updateField("leadSource", e.target.value),
                                                        placeholder: "e.g., Website, Referral, Event"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 189,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 185,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "new-contact-engagement-score",
                                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                                        children: "Engagement Score"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 197,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        id: "new-contact-engagement-score",
                                                        type: "number",
                                                        min: "0",
                                                        max: "100",
                                                        value: form.engagementScore || "",
                                                        onChange: (e)=>updateField("engagementScore", e.target.value ? Number(e.target.value) : null),
                                                        placeholder: "0-100"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 200,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 196,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "new-contact-tags",
                                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                                        children: "Tags"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 213,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        id: "new-contact-tags",
                                                        name: "new-contact-tags",
                                                        value: Array.isArray(form.tags) ? form.tags.join(", ") : "",
                                                        onChange: (e)=>updateField("tags", e.target.value.split(",").map((s)=>s.trim()).filter(Boolean)),
                                                        placeholder: "tag1, tag2, tag3"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 214,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-2 text-xs text-theme-dark",
                                                        children: 'Enter tags separated by commas. Spaces within tags are allowed (e.g., "Project Manager, Marketing Lead,Referral, VIP").'
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 226,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 212,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                        lineNumber: 175,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                lineNumber: 158,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                padding: "md",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-lg font-semibold text-theme-darkest mb-4 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-5 h-5 text-gray-400",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                "aria-hidden": "true",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                    lineNumber: 243,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 236,
                                                columnNumber: 15
                                            }, this),
                                            "Notes"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                        lineNumber: 235,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "new-contact-notes",
                                        className: "sr-only",
                                        children: "Notes"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                        lineNumber: 252,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        id: "new-contact-notes",
                                        name: "new-contact-notes",
                                        rows: 6,
                                        value: form.notes || "",
                                        onChange: (e)=>updateField("notes", e.target.value),
                                        placeholder: "Add notes about this contact..."
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                        lineNumber: 253,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                lineNumber: 234,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                padding: "md",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-lg font-semibold text-theme-darkest mb-4 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-5 h-5 text-gray-400",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                    lineNumber: 272,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 266,
                                                columnNumber: 15
                                            }, this),
                                            "Next Touchpoint"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                        lineNumber: 265,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "new-contact-next-touchpoint-date",
                                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                                        children: "Date"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 283,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        id: "new-contact-next-touchpoint-date",
                                                        type: "date",
                                                        value: form.nextTouchpointDate && typeof form.nextTouchpointDate === "string" ? form.nextTouchpointDate : "",
                                                        onChange: (e)=>updateField("nextTouchpointDate", e.target.value || null)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 284,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 282,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "new-contact-next-touchpoint-message",
                                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                                        children: "Message"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 296,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        id: "new-contact-next-touchpoint-message",
                                                        name: "new-contact-next-touchpoint-message",
                                                        rows: 4,
                                                        value: form.nextTouchpointMessage || "",
                                                        onChange: (e)=>updateField("nextTouchpointMessage", e.target.value),
                                                        placeholder: "What should you discuss in the next touchpoint?"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                        lineNumber: 297,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                                lineNumber: 295,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                        lineNumber: 281,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                lineNumber: 264,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-start",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: handleSave,
                                    disabled: saving,
                                    loading: saving,
                                    variant: "secondary",
                                    size: "md",
                                    className: "shadow-[rgba(34,32,29,0.1)_0px_2px_4px] ",
                                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M5 13l4 4L19 7"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                            lineNumber: 326,
                                            columnNumber: 19
                                        }, void 0)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                        lineNumber: 320,
                                        columnNumber: 17
                                    }, void 0),
                                    error: error,
                                    children: "Save Contact"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                    lineNumber: 311,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                                lineNumber: 310,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                        lineNumber: 82,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/contacts/new/page.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/contacts/new/page.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
_s(NewContactPage, "dZb7rFH4rogV+TzHSMrk33HP9cU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useNewContactPage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNewContactPage"]
    ];
});
_c = NewContactPage;
var _c;
__turbopack_context__.k.register(_c, "NewContactPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=96b6be41-26b1-2cca-9836-02e5b5f16575
//# sourceMappingURL=_ae37e258._.js.map